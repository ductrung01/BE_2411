package org.example.Exercises.Lesson3.Task2;

import java.util.ArrayList;
import java.util.List;

public class QuanLySach {
    private List<Book> bookList;

    public QuanLySach() {
        this.bookList = new ArrayList<>();
    }

    public QuanLySach(List<Book> bookList) {
        this.bookList = bookList;
    }

    public List<Book> getBookList() {
        return bookList;
    }

    public void bookListDefault(){
        bookList.add(new Book("MS001", "Nhà xuất bản A", 100, "Tác giả 1", 200, 1, 100, 1));
        bookList.add(new Book("MS002", "Nhà xuất bản B", 200, "Tác giả 2", 300, 2, 200, 2));
        bookList.add(new Book("MS003", "Nhà xuất bản C", 300, "Tác giả 3", 400, 3, 300, 3));
    }

    public void setBookList(List<Book> bookList) {
        this.bookList = bookList;
    }

    public void addBook(Book book){
        this.bookList.add(book);
    }

    public void deleteBookByBookCode(String bookCode){
        this.bookList.removeIf(book -> book.getMaSach().equals(bookCode));
    }



}
