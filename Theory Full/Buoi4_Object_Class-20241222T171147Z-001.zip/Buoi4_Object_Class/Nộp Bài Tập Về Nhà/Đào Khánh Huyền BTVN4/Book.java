package org.example.Exercises.Lesson3.Task2;

//
//Bài 1
//Một thư viện cần quản lý các Sách
//Mỗi cuốn Sách gồm có các thuộc tính sau:
//Mã sách (Mã tài liệu là duy nhất),
//Tên nhà xuất bản,
//số bản phát hành.
//tên tác giả
//số trang.
//Ngày phát hành.
//Số phát hành,
//tháng phát hành.
//Yêu cầu 1: Xây dựng lớp Sách để quản lý tài liệu cho thư viện một cách hiệu quả.
//Yêu cầu 2: Xây dựng lớp QuanLySach có mảng các cuốn sách và đáp ứng các chức năng sau
//a) Cho phép nhập vào 3 cuốn sách mặc định hoặc khởi tạo ra giá mặc định cho 3 cuốn sách của mảng
//b) Thêm sách vào cuối mảng
//c) Xóa sách theo mã sách
//Xây dựng chương trình như một vòng lặp với các chức năng trên và thêm chức năng exist.
// Khi chỉ chọn chức năng exist thì mới thoát khỏi chương trình
// //, nếu không chương trình sẽ có thể lặp lại cho user chọn các chức năng

public class Book {
    private String maSach;
    private String tenNhaXuatBan;
    private int soBanPhatHanh;
    private String authorName;
    private int soTrang;
    private long ngayPhatHanh;
    private long soPhatHanh;
    private long thangPhatHanh;

    public Book() {
    }

    public Book(String maSach, String tenNhaXuatBan, int soBanPhatHanh, String authorName, int soTrang, long ngayPhatHanh, long soPhatHanh, long thangPhatHanh) {
        this.maSach = maSach;
        this.tenNhaXuatBan = tenNhaXuatBan;
        this.soBanPhatHanh = soBanPhatHanh;
        this.authorName = authorName;
        this.soTrang = soTrang;
        this.ngayPhatHanh = ngayPhatHanh;
        this.soPhatHanh = soPhatHanh;
        this.thangPhatHanh = thangPhatHanh;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getTenNhaXuatBan() {
        return tenNhaXuatBan;
    }

    public void setTenNhaXuatBan(String tenNhaXuatBan) {
        this.tenNhaXuatBan = tenNhaXuatBan;
    }

    public int getSoBanPhatHanh() {
        return soBanPhatHanh;
    }

    public void setSoBanPhatHanh(int soBanPhatHanh) {
        this.soBanPhatHanh = soBanPhatHanh;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    public long getNgayPhatHanh() {
        return ngayPhatHanh;
    }

    public void setNgayPhatHanh(long ngayPhatHanh) {
        this.ngayPhatHanh = ngayPhatHanh;
    }

    public long getSoPhatHanh() {
        return soPhatHanh;
    }

    public void setSoPhatHanh(long soPhatHanh) {
        this.soPhatHanh = soPhatHanh;
    }

    public long getThangPhatHanh() {
        return thangPhatHanh;
    }

    public void setThangPhatHanh(long thangPhatHanh) {
        this.thangPhatHanh = thangPhatHanh;
    }

    @Override
    public String toString() {
        return "Book{" +
                "maSach='" + maSach + '\'' +
                ", tenNhaXuatBan='" + tenNhaXuatBan + '\'' +
                ", soBanPhatHanh=" + soBanPhatHanh +
                ", authorName='" + authorName + '\'' +
                ", soTrang=" + soTrang +
                ", ngayPhatHanh=" + ngayPhatHanh +
                ", soPhatHanh=" + soPhatHanh +
                ", thangPhatHanh=" + thangPhatHanh +
                '}';
    }
}
