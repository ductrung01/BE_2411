package org.example.Exercises.Lesson3.Task2;


//
//BÀI TẬP JAVA CƠ BẢN VỚI MẢNG
//I : Viết chương trình cho phép nhập vào n, sau đó nhập vào n phần tử số nguyên
//Xây dựng chương trình dưới dạng một dứng dụng với các chức năng
//Thoát khỏi ứng dụng, khi đó chương trình mới dừng. Nếu không vẫn có thể nhập các chức năng và thực hiện lại các chưc năng
//

import java.util.Arrays;
import java.util.Scanner;

public class Exercise1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n, sum = 0;
        do{
            System.out.print("Enter a random n: ");
            n = scanner.nextInt();
        }while (n <= 0);

        int[] array = new int[n];
        System.out.println("Enter random numbers of the array: ");
        for(int i = 0; i < n; i++){
            System.out.print("Phần tử thứ " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
        }

//Hiển thị phần tử có giá trị lớn nhất
        int max = Integer.MIN_VALUE, min = Integer.MAX_VALUE;
        for (int j : array) {
            if (j < min) {
                min = j;
            }
            if (j > max) {
                max = j;
            }
        }

        System.out.println("Minimum number of the array is: "+min);
        System.out.println("Maximum number of the array is: "+max);

        for(int num : array){
            sum += num;
        }

//Hiển trị giá trị trung bình của dãy

        double average = (double) sum / n;
        System.out.print("Average of the array is: "+average +"\n");

//Sắp xếp mảng theo thứ tự tăng dần

        Arrays.sort(array);
        System.out.print("Sort up ascending: ");
        System.out.println(Arrays.toString(array));

        //Sắp xếp mảng theo thứ tự giảm dần
        int temp;
        for(int i = 0; i < n - 1; i++){
            for(int j = i + 1; j < n; j++){
                if (array[j] > array[i]) {
                    temp = array[j];
                    array[j] = array[i];
                    array[i] = temp;
                }
            }
        }

        System.out.print("Reversed array: " +Arrays.toString(array) +"\n");


//Tìm kiếm phần tử lớn thứ 3 trong mảng nếu có

        if(array.length < 3){
            System.out.print("The array does not have enough elements to find the largest third element");
        }else {
            int thirdElement = array[array.length - 3];
            System.out.println("The largest third element is:  " +thirdElement);
        }

        // Tìm kiếm xem phần tử nào trong mảng xuất hiện 2 lần


// Cho phép người dùng nhập vào một số và tìm kiếm số đó trong mảng
        System.out.print("Enter the number to search for in the array: ");
        int newNumber = scanner.nextInt();
        boolean found = false;
        for (int num : array) {
            if (num == newNumber) {
                found = true;
                break;
            }
        }
        if (found) {
            System.out.println("The number " + newNumber + " already exists in the array");
        } else {
            System.out.println("The number " + newNumber + "was not found in the array");
        }



        //Cho phép người dùng nhập vào một số, xóa đi số đó tại mảng
//Cho phép người dùng thêm mới một số vào mảng, validate nếu mảng đã đầy thì không cho thêm



        scanner.close();


    }
}
