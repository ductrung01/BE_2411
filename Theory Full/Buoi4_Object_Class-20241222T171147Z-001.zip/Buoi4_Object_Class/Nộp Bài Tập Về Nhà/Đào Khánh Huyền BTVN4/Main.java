package org.example.Exercises.Lesson3.Task2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        QuanLySach quanLySach = new QuanLySach();



        boolean exit = false;
        while (!exit){
            System.out.println("Vui lòng chọn các chức năng:");
            System.out.println("1. Thêm sách");
            System.out.println("2. Xóa sách theo mã sách");
            System.out.println("3. Hiện thị danh sách");
            System.out.println("4. Exit");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option){
                case 1:
                    System.out.println("Nhập thông tin sách mới:");
                    System.out.print("Mã sách: ");
                    String maSach = scanner.nextLine();
                    System.out.print("Tên nhà xuất bản: ");
                    String tenNhaXuatBan = scanner.nextLine();
                    System.out.print("Số bản phát hành: ");
                    int soBanPhatHanh = scanner.nextInt();
                    scanner.nextLine(); // Đọc bỏ dòng newline sau nextInt()
                    System.out.print("Tên tác giả: ");
                    String tenTacGia = scanner.nextLine();
                    System.out.print("Số trang: ");
                    int soTrang = scanner.nextInt();
                    scanner.nextLine(); // Đọc bỏ dòng newline sau nextInt()
                    System.out.print("Ngày phát hành: ");
                    long ngayPhatHanh = scanner.nextLong();
                    scanner.nextLine();
                    long soPhatHanh = scanner.nextLong();
                    System.out.print("Tháng phát hành: ");
                    long thangPhatHanh = scanner.nextLong();
                    scanner.nextLine(); // Đọc bỏ dòng newline sau nextInt()
                    // Tạo sách mới và thêm vào danh sách quản lý sách
                    quanLySach.addBook(new Book(maSach, tenNhaXuatBan, soBanPhatHanh, tenTacGia, soTrang, ngayPhatHanh, soPhatHanh, thangPhatHanh));
                    System.out.println("Sách đã được thêm vào thư viện.");
                    break;

                case 2:
                    System.out.print("Nhập mã sách cần xóa: ");
                    String maSachCanXoa = scanner.nextLine();
                    quanLySach.deleteBookByBookCode(maSachCanXoa);
                    break;
                case 3:
                    quanLySach.bookListDefault();
                    break;
                case 4:
                    exit = true;
                    System.out.println("Chương trình kết thúc.");
                    break;
                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
            }
        }
    }
}
