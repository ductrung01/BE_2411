package VuVanThang;

import java.util.ArrayList;

class QuanLySach {
    ArrayList<Sach> dsSach = new ArrayList<>();

    public void nhapSachMacDinh() {
        Sach sach1 = new Sach(01, "thăng", 100, "thăng", 200, 11, 1, 10);
        Sach sach2 = new Sach(02, "thăng", 150, "thăng", 250, 24, 2, 5);
        Sach sach3 = new Sach(03, "thăng", 200, "thăng", 300, 30, 3, 3);

        dsSach.add(sach1);
        dsSach.add(sach2);
        dsSach.add(sach3);
    }

    public void themSach(Sach sach) {
        dsSach.add(sach);
    }

    public void xoaSach(int maSach) {
        for (int i = 0; i < dsSach.size(); i++) {
            if (dsSach.get(i).getMaSach()==(maSach)) {
                dsSach.remove(i);
                break;
            }
        }
    }

}
