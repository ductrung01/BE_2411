package VuVanThang;

public class Sach {

       private int maSach;
       private String tenNhaXuatBan;
       private  int soBanPhatHanh;
       private  String tenTacGia;
       private  long soTrang;
       private  int ngayPhatHanh;
       private long soPhatHanh;
       private  int thangPhatHanh;

        public Sach(int maSach, String tenNhaXuatBan, int soBanPhatHanh, String tenTacGia, long soTrang, int ngayPhatHanh, long soPhatHanh, int thangPhatHanh) {
            this.maSach = maSach;
            this.tenNhaXuatBan = tenNhaXuatBan;
            this.soBanPhatHanh = soBanPhatHanh;
            this.tenTacGia = tenTacGia;
            this.soTrang = soTrang;
            this.ngayPhatHanh = ngayPhatHanh;
            this.soPhatHanh = soPhatHanh;
            this.thangPhatHanh = thangPhatHanh;
        }

    public int getMaSach() {
        return maSach;
    }

    @Override
    public String toString() {
        return
                "Mã Sách ='" + maSach + '\'' +
                ", Tên Nhà Xuất Bản ='" + tenNhaXuatBan + '\'' +
                ", Số bản phát hành =" + soBanPhatHanh +
                ", Tên tác giả ='" + tenTacGia + '\'' +
                ", Số trang =" + soTrang +
                ", Ngày phát hành =" + ngayPhatHanh +
                ", Số phát hành =" + soPhatHanh +
                ", Tháng phát hành =" + thangPhatHanh +".";
    }
}
