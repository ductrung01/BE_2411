package VuVanThang;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        QuanLySach quanLySach = new QuanLySach();
        quanLySach.nhapSachMacDinh();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== MENU =====");
            System.out.println("1. Hiển thị danh sách");
            System.out.println("2. Thêm sách");
            System.out.println("3. Xóa sách");
            System.out.println("4. Thoát");
            System.out.print("Nhập lựa chọn của bạn: ");
            int luaChon = scanner.nextInt();
            scanner.nextLine();

            switch (luaChon) {
                case 1:
                    hienThiDanhSach(quanLySach);
                    break;
                case 2:
                    them(scanner, quanLySach);
                    break;
                case 3:
                    xoa(scanner, quanLySach);
                    break;
                case 4:
                    System.out.println("Đã thoát chương trình.");
                    System.exit(0);
                default:
                    System.out.println("Lựa chọn không hợp lệ, vui lòng chọn lại.");
            }
        }
    }

    public static void hienThiDanhSach(QuanLySach quanLySach) {
        System.out.println("\n===== DANH SÁCH =====");
        for (Sach sach : quanLySach.dsSach) {
            System.out.println(sach.toString());
        }
    }

    public static void them(Scanner scanner, QuanLySach quanLySach) {
        System.out.println("\n===== THÊM SÁCH =====");
        System.out.print("Nhập mã sách: ");
        int maSach = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nhập tên nhà xuất bản: ");
        String tenNhaXuatBan = scanner.nextLine();
        System.out.print("Nhập số bản phát hành: ");
        int soBanPhatHanh = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nhập tên tác giả: ");
        String tenTacGia = scanner.nextLine();
        System.out.print("Nhập số trang: ");
        long soTrang = scanner.nextLong();
        System.out.print("Nhập ngày phát hành: ");
        int ngayPhatHanh = scanner.nextInt();
        System.out.print("Nhập số phát hành: ");
        long soPhatHanh = scanner.nextLong();
        System.out.print("Nhập tháng phát hành: ");
        int thangPhatHanh = scanner.nextInt();

        Sach sach = new Sach(maSach, tenNhaXuatBan, soBanPhatHanh, tenTacGia, soTrang, ngayPhatHanh, soPhatHanh, thangPhatHanh);
        quanLySach.themSach(sach);
        System.out.println("Sách đã được thêm vào danh sách.");
    }

    public static void xoa(Scanner scanner, QuanLySach quanLySach) {
        System.out.println("\n===== XÓA SÁCH =====");
        System.out.print("Nhập mã sách cần xóa: ");
        int maSach = scanner.nextInt();
        quanLySach.xoaSach(maSach);
        System.out.println("Sách có mã " + maSach + " đã được xóa khỏi danh sách.");
    }
}

