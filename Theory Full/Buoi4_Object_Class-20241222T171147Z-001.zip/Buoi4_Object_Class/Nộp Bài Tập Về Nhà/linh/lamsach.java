package com.linh;

import java.util.ArrayList;
import java.util.List;

class LibraryManager {
    private List<Book> books = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully!");
    }

    public void updateBook(int id, String title, String author) {
        books.stream()
                .filter(book -> book.getId() == id)
                .findFirst()
                .ifPresent(book -> {
                    book.setTitle(title);
                    book.setAuthor(author);
                    System.out.println("Book updated successfully!");
                });
    }

    public void deleteBook(int id) {
        if (books.removeIf(book -> book.getId() == id)) {
            System.out.println("Book deleted successfully!");
        } else {
            System.out.println("Book not found!");
        }
    }

    public void listBooks() {
        books.forEach(System.out::println);
    }

    public void searchBooks(String query) {
        List<Book> foundBooks = books.stream()
                .filter(book -> book.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                        book.getAuthor().toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());

        if (foundBooks.isEmpty()) {
            System.out.println("No matching books found.");
        } else {
            foundBooks.forEach(System.out::println);
        }
    }
}
