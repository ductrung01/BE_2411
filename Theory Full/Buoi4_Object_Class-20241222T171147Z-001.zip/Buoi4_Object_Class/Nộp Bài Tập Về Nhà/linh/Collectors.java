package com.linh;

import java.util.List;
import java.util.stream.Collector;

public class Collectors {
    public static Collector<? super Book, Object, List<Book>> toList() {
        return null;
    }
}
