package quanLySach;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class quanLySach {
    ArrayList<sAch>  listSach = new ArrayList<>();
    public static void main(String[] args) {
        sAch sach1 = sAch.nhap();
        System.out.println("-------------");
        sach1.xuat();


        }


    public void addSach(sAch sach){
        listSach.add(sach);
    }

    public void xoaSachTheoMa(ArrayList<sAch> listSach){
        Scanner sc = new Scanner(System.in);
        System.out.println ("Nhap ma sach can xoa : ");
        String maSachCanXoa = sc.next();
        for (int i = listSach.size() - 1; i >= 0; i--) {
            sAch sach =listSach.get(i);
            if (sach.getMaSach().equals(maSachCanXoa)) {
                listSach.remove(i);
                System.out.println("Đã xóa sách có mã sách: " + maSachCanXoa);
                return;
            }
        }
    }
}
