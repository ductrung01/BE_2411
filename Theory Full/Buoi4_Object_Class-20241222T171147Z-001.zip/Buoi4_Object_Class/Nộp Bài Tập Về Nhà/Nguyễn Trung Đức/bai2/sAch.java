package quanLySach;

import java.util.Scanner;

public class sAch {
    public String maSach;
    public String tenNhaxuatban;
    public static int soXuatban;
    public String tenTacgia;
    public int soTrang;
    public long ngayPhathanh;
    public int soBanphathanh;
    public long thangPhathanh;


    public sAch(String maSach, String tenNhaxuatban, int soXuatban, String tentacgia, int soTrang, long ngayPhathanh, int soPhathanh, long thangPhathanh) {
        this.maSach = maSach;
        this.tenNhaxuatban = tenNhaxuatban;
        this.soXuatban = soXuatban;
        this.tenTacgia = tenTacgia;
        this.soTrang = soTrang;
        this.ngayPhathanh = ngayPhathanh;
        this.soBanphathanh = soBanphathanh;
        this.thangPhathanh = thangPhathanh;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getTenNhaxuatban() {
        return tenNhaxuatban;
    }

    public void setTenNhaxuatban(String tenNhaxuatban) {
        this.tenNhaxuatban = tenNhaxuatban;
    }

    public int getSoXuatban() {
        return soXuatban;
    }

    public void setSoXuatban(int soXuatban) {
        this.soXuatban = soXuatban;
    }

    public String getTentacgia() {
        return tenTacgia;
    }

    public void setTentacgia(String tentacgia) {
        this.tenTacgia = tentacgia;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    public long getNgayPhathanh() {
        return ngayPhathanh;
    }

    public void setNgayPhathanh(int ngayPhathanh) {
        this.ngayPhathanh = ngayPhathanh;
    }

    public int getSoPhathanh() {
        return soBanphathanh;
    }

    public void setSoPhathanh(int soPhathanh) {
        this.soBanphathanh = soPhathanh;
    }

    public long getThangPhathanh() {
        return thangPhathanh;
    }

    public void setThangPhathanh(int thangPhathanh) {
        this.thangPhathanh = thangPhathanh;
    }

    public static sAch nhap(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Nhập thông tin sách:");
        System.out.print("Mã sách: ");
        String maSach = scanner.nextLine();
        System.out.print("Tên nhà xuất bản: ");
        String tenNhaxuatban = scanner.nextLine();
        System.out.print("Số bản phát hành: ");
        int soBanphathanh = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ dòng trống sau khi nhập số
        System.out.print("Tên tác giả: ");
        String tenTacgia = scanner.nextLine();
        System.out.print("Số trang: ");
        int soTrang = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ dòng trống sau khi nhập số
        System.out.print("Ngày phát hành (vd: 1): ");
        long ngayPhathanh = scanner.nextLong();
        System.out.print("Tháng phát hành (vd: 2024): ");
        long thangPhathanh = scanner.nextLong();


        return new sAch(maSach,tenNhaxuatban,soBanphathanh,tenTacgia,soTrang,ngayPhathanh,soBanphathanh,thangPhathanh);

    }

    public void    xuat (){
        System.out.println("Thông tin sách:");
        System.out.println("Mã sách: " + maSach);
        System.out.println("Tên nhà xuất bản: " + tenNhaxuatban);
        System.out.println("Số bản phát hành: " + soBanphathanh);
        System.out.println("Tên tác giả: " + tenTacgia);
        System.out.println("Số trang: " + soTrang);
        System.out.println("Ngày phát hành: " + ngayPhathanh + "/" + thangPhathanh);
    }

}




