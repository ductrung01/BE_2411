package com.javaweb.Object;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class BookManagement {
    private static Book[] books = new Book[0];
    private static Book book;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String type = "";
        while (!type.equals("Exist")){
            System.out.printf("Nhập Vào 3 Cuốn Sách%n");
            for (int i = 0 ; i < 3 ; i++){
                infoBook(i);
                books = addBook(books,book);
                //books.add(book);
            }
            for (int i = 0 ; i < books.length; i++){
                books[i].getBook();
            }
            System.out.printf("Thêm Sách Vào Mảng:%n");
            infoBook(books.length);
            books = addBook(books,book);
            System.out.printf("Xóa Sách Khỏi Mảng:%n");
            System.out.printf("Nhập Mã Sách Bạn Muốn Xóa:");

            String input = sc.nextLine();
            int j = 0;
            Book[] arrayNew = new Book[books.length - 1];
            for (int i = 0; i < books.length; i++){
                if(!books[i].getReleaseCode().equals(input)){
                    arrayNew[j] = books[i];
                    j++;
                }
            }
            books = arrayNew.clone();
            System.out.printf("Đã Xóa Sách Có Mã Sách: "+input+"%n");
            for (int i = 0 ; i < books.length; i++){
                books[i].getBook();
            }
            System.out.printf("%nNhập Exist Để Thoát:");
            type = sc.nextLine();
        }

        System.out.printf("Đã Thoát Chương Trình");

    }
    private static void infoBook(int i){
        System.out.printf("Thông Tin Sách Thứ "+(i+1));
        Scanner scanner = new Scanner(System.in);
        System.out.printf("%nMã Sách:");
        String releaseCode = scanner.nextLine();
        System.out.printf("Tên Nhà Xuất Bản:");
        String issuerName = scanner.nextLine();
        System.out.printf("Số Năm Xuất Bản:");
        int releaseNumber = scanner.nextInt();
        scanner.nextLine();
        System.out.printf("Tên Tác Giả:");
        String authorName = scanner.nextLine();
        System.out.printf("Số Trang:");
        int numberPages = scanner.nextInt();
        scanner.nextLine();
        System.out.printf("Ngày Phát Hành:");
        long releaseDate = scanner.nextLong();
        System.out.printf("Số Phát Hành:");
        int issueNumber = scanner.nextInt();
        scanner.nextLine();
        System.out.printf("Tháng Phát Hành:");
        long releaseMonth = scanner.nextLong();
        book = new Book(releaseCode,issuerName,releaseNumber,authorName,numberPages,releaseDate,
                issueNumber,releaseMonth);
    }
    private static Book[] addBook(Book[] arr, Book number){
        List<Book> list = new ArrayList<>(Arrays.asList(arr));
        list.add(number);
        arr = list.toArray(arr);
        return arr;
    }
}
