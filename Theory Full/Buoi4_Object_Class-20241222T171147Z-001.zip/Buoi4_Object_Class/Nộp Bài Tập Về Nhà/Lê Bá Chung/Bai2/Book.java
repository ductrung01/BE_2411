package com.javaweb.Object;

public class Book {
    private String releaseCode;
    private String issuerName;
    private int releaseNumber;
    private String authorName;
    private int numberPages;
    private Long releaseDate;
    private int issueNumber;
    private Long releaseMonth;

    public Book(String _releaseCode ,String _issuerName,int _releaseNumber,String _authorName
    ,int _numberPages,Long _releaseDate,int _issueNumber,Long _releaseMonth) {
        this.releaseCode = _releaseCode;
        this.issuerName = _issuerName;
        this.releaseNumber = _releaseNumber;
        this.authorName = _authorName;
        this.numberPages = _numberPages;
        this.releaseDate = _releaseDate;
        this.issueNumber = _issueNumber;
        this.releaseMonth = _releaseMonth;
    }
    public Book(){

    }
    public void getBook(){
        System.out.printf("Thông Tin Cuốn Sách:");
        System.out.printf("%nMã Sách:" + this.releaseCode);
        System.out.printf("%nTên Nhà Xuất Bản:" + this.issuerName);
        System.out.printf("%nSố Năm Xuất Bản:" + this.releaseNumber);
        System.out.printf("%nTên Tác Giả:" + this.authorName);
        System.out.printf("%nSố Trang:" + this.numberPages);
        System.out.printf("%nNgày Phát Hành:" +this.releaseDate);
        System.out.printf("%nSố Phát Hành:" +this.issueNumber);
        System.out.printf("%nTháng Phát Hành:" +this.releaseMonth+"%n");
    }
    public String getReleaseCode(){
        return this.releaseCode;
    }
}
