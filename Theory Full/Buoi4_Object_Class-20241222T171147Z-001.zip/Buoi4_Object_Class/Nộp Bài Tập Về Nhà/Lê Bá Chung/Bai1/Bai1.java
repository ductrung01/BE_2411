package com.javaweb.Object;

import java.util.*;

public class Bai1 {

    public static void main(String[] args) {
        System.out.printf("Nhập Vào Số n:");
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        Integer[] array = new Integer[number];
        System.out.printf("Nhập Vào " + number + " Số Nguyên:%n");
        for (int i = 0; i < number; i++) {
            System.out.printf("Số "+ (i+1) +" :");
            array[i] = sc.nextInt();
        }
        String exist = "";
        while (!exist.equals("Exist")){
            //Giá Trị Trung Bình
            float averageValue =0;
            for (int i = 0; i < array.length; i++) {
                averageValue += array[i];
            }
            System.out.printf("%nGiá Trị Trung Bình Của Dãy:" + averageValue/array.length);
            // Phần Tử Lớn Nhất Trong Dãy
            int max = array[0];
            for (int i = 1; i < array.length; i++) {
                if(array[i] > max){
                    max = array[i];
                }
            }
            System.out.printf("%nPhần Tử Lớn Nhất Trong Dãy:" + max);
            // Sắp Xếp Giảm Dần
            decreaseSort(array);
            System.out.printf("%nMảng Giảm Dần: ");
            for (int value : array) {
                System.out.print(value + ", ");
            }
            // Sắp Xếp Tăng Dần
            ascendingSort(array);
            System.out.printf("%nMảng Tăng Dần: ");
            for (int value : array) {
                System.out.print(value + ", ");
            }
            //XUất Hiện 2 Lần
            Integer[] arr = new Integer[0];
            List<Integer> arrCovert = new ArrayList<>(Arrays.asList(arr));
            for (int i = 0; i < array.length; i++) {
                int count = appearsDouble(array,array[i]);
                if (count == 2){
                    if(!arrCovert.contains(array[i])){
                        arrCovert.add(array[i]);
                    }
                }
            }
            if(arrCovert.size() > 0){
                System.out.printf("%nPhần Tử Xuất Hiện 2 Lần Là :");
                for(int var : arrCovert){
                    System.out.print(var + " ");
                }
            }else {
                System.out.printf("%nKhông Có Phần Tử Xuất Hiện 2 Lần");
            }
            // TÌm Số Lớn Thứ 3
            if(array.length >= 3){
                System.out.printf("%nSố Lớn Thứ 3 Là: " + array[array.length - 3]);
            }else {
                System.out.printf("%nKhông Có Số Lớn Thứ 3");
            }
            //Cho Nhập Thêm 1 Số
            System.out.printf("%nNhập 1 Số: ");
            int numberNew = sc.nextInt();
            int stt = Arrays.binarySearch(array,numberNew);
            if(stt < 0){
                System.out.printf("Số Vừa Nhập Không Có Trong Mảng");
            }else {
                System.out.printf("Số Thứ Tự Trong Mảng :" + stt);
            }
            // Xóa 1 Số Trong Mảng
            System.out.printf("%nNhập Số Cần Xóa: ");
            int clear = sc.nextInt();
            int j = 0 ;
            Integer[] arrayNew = new Integer[array.length - 1];
            for (int i = 0 ; i < array.length;i++){
                if(array[i] != clear){
                    arrayNew[j] = array[i];
                    j++;
                }
            }
            array = arrayNew.clone();
            System.out.printf("Mảng Mới :");
            for (int var : array){
                System.out.printf(" "+var);
            }
            // Thêm 1 Số
            while (array.length < number){
                System.out.printf("%nNhập Thêm Số Vào Mảng:");
                int input = sc.nextInt();
                array = addNumber(array,input);
                System.out.printf("Mảng Khi Thêm "+input +":");
                for(int var : array){
                    System.out.printf(" "+ var);
                }
            }
            System.out.printf("%nMảng Đã Đầy Không Thể Thêm");
            System.out.printf("%Nhập Exist Để Kết Thúc Ứng Dụng:");
            sc.nextLine();
            exist = sc.nextLine();
        }
        System.out.printf("Ứng Dụng Kết Thuc");
    }
    public static void decreaseSort(Integer[] array){
        int min = array[0];
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if(array[j] > array[i]){
                    min = array[j];
                    array[j] = array[i];
                    array[i] = min;
                }
            }
        }
    }
    public static void ascendingSort(Integer[] array){
        int min = array[0];
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if(array[j] < array[i]){
                    min = array[j];
                    array[j] = array[i];
                    array[i] = min;
                }
            }
        }
    }
    public static int appearsDouble(Integer[] array,int count){
        int appears = 0;
        for (int i = 0; i < array.length ; i++) {
            if(count == array[i]){
                appears++;
            }
        }
        return appears;
    }
    private static Integer[] addNumber(Integer[] arr, int number){
        List<Integer> list = new ArrayList<>(Arrays.asList(arr));
        list.add(number);
        arr = list.toArray(arr);
        return arr;
    }
}
