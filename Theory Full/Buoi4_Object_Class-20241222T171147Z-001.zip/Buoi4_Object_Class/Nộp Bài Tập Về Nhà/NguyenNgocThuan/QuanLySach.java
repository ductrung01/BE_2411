package buoi4;

import java.util.Scanner;


public class QuanLySach {

    private Sach[] arrSach;
    private int soLuongSachHienTai;
    private int tongSoSachCuaThuVien;

    public QuanLySach(int tongSoSachCuaThuVien){
        this.tongSoSachCuaThuVien = tongSoSachCuaThuVien;
        this.arrSach = new Sach[tongSoSachCuaThuVien];
        this.soLuongSachHienTai = 0;
    }

    public void themSach(Sach sachThem){
        if (this.soLuongSachHienTai == this.tongSoSachCuaThuVien){
            System.out.println("Số lượng sách trong thư viện đã đầy, không thể thêm");
            return;
        }
        this.arrSach[this.soLuongSachHienTai] = sachThem;
        this.soLuongSachHienTai++;
    }
    public void hienThiDanhSach(){
        for (int i = 0; i < this.soLuongSachHienTai; i++) {
            System.out.println(this.arrSach[i].toString());
        }
    }
    public void xoaSach(){
        System.out.println("Nhập vào mã sách: ");
        String maSach = new Scanner(System.in).nextLine();
        boolean xoaThanhCong = false;
        for (int i = 0; i < this.soLuongSachHienTai; i++) {
            /**
             kiểm tra nếu mã sách nhập vào tồn tại trong thư viện
             */
            if (arrSach[i].getMaSach().equals(maSach)){
                // thực hiện xóa
                for (int j = i; j < this.soLuongSachHienTai; j++) {
                    this.arrSach[j] = this.arrSach[j + 1];
                }
                this.soLuongSachHienTai--;
                xoaThanhCong = true;
            }
        }
        if (xoaThanhCong){
            System.out.println("Đã xóa thành công sách với mã: " + maSach);
        }
    }

}

