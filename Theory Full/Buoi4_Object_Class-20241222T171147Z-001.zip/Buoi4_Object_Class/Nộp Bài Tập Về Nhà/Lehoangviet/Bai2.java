import java.util.Arrays;
import java.util.Scanner;

public class Bai2 {
    private static int[] array;
    private static int size;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập vào số lượng phần tử của mảng: ");
        size = scanner.nextInt();
        array = new int[size];

        System.out.println("Nhập vào các phần tử của mảng:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        while (true) {
            System.out.println("\nChọn chức năng:");
            System.out.println("1. Hiển thị giá trị trung bình của dãy");
            System.out.println("2. Hiển thị phần tử có giá trị lớn nhất");
            System.out.println("3. Sắp xếp mảng theo thứ tự giảm dần");
            System.out.println("4. Sắp xếp mảng theo thứ tự tăng dần");
            System.out.println("5. In ra các phần tử xuất hiện 2 lần của mảng");
            System.out.println("6. Tìm kiếm phần tử lớn thứ 3 trong mảng");
            System.out.println("7. Tìm kiếm một số trong mảng");
            System.out.println("8. Xóa một số khỏi mảng");
            System.out.println("9. Thêm mới một số vào mảng");
            System.out.println("10. Thoát");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    displayAverage();
                    break;
                case 2:
                    displayMax();
                    break;
                case 3:
                    sortDescending();
                    break;
                case 4:
                    sortAscending();
                    break;
                case 5:
                    displayDuplicates();
                    break;
                case 6:
                    findThirdLargest();
                    break;
                case 7:
                    searchNumber(scanner);
                    break;
                case 8:
                    deleteNumber(scanner);
                    break;
                case 9:
                    addNumber(scanner);
                    break;
                case 10:
                    System.out.println("Ứng dụng đã thoát.");
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
            }
        }
    }

    private static void displayAverage() {
        double sum = 0;
        for (int num : array) {
            sum += num;
        }
        System.out.println("Giá trị trung bình của dãy: " + (sum / size));
    }

    private static void displayMax() {
        int max = array[0];
        for (int i = 1; i < size; i++) {
            if (array[i] > max) {
                max = array[i];
            }
        }
        System.out.println("Phần tử lớn nhất của mảng: " + max);
    }

    private static void sortDescending() {
        Arrays.sort(array);
        System.out.println("Mảng sau khi sắp xếp giảm dần: " + Arrays.toString(array));
    }

    private static void sortAscending() {
        Arrays.sort(array);
        int[] reversedArray = new int[size];
        for (int i = 0; i < size; i++) {
            reversedArray[i] = array[size - i - 1];
        }
        System.out.println("Mảng sau khi sắp xếp tăng dần: " + Arrays.toString(reversedArray));
    }

    private static void displayDuplicates() {
        System.out.println("Các phần tử xuất hiện 2 lần trong mảng:");
        Arrays.sort(array);
        for (int i = 0; i < size - 1; i++) {
            if (array[i] == array[i + 1]) {
                System.out.println(array[i]);
                i++; // skip duplicates
            }
        }
    }

    private static void findThirdLargest() {
        if (size < 3) {
            System.out.println("Mảng không đủ phần tử để tìm kiếm phần tử lớn thứ 3.");
        } else {
            Arrays.sort(array);
            System.out.println("Phần tử lớn thứ 3 trong mảng: " + array[size - 3]);
        }
    }

    private static void searchNumber(Scanner scanner) {
        System.out.print("Nhập số cần tìm kiếm trong mảng: ");
        int number = scanner.nextInt();
        boolean found = false;
        for (int i = 0; i < size; i++) {
            if (array[i] == number) {
                System.out.println("Số " + number + " được tìm thấy tại vị trí " + i);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Không tìm thấy số " + number + " trong mảng.");
        }
    }

    private static void deleteNumber(Scanner scanner) {
        System.out.print("Nhập số cần xóa khỏi mảng: ");
        int number = scanner.nextInt();
        boolean deleted = false;
        for (int i = 0; i < size; i++) {
            if (array[i] == number) {
                for (int j = i; j < size - 1; j++) {
                    array[j] = array[j + 1];
                }
                size--;
                deleted = true;
                break;
            }
        }
        if (deleted) {
            System.out.println("Số " + number + " đã được xóa khỏi mảng.");
        } else {
            System.out.println("Không tìm thấy số " + number + " trong mảng.");
        }
    }

    private static void addNumber(Scanner scanner) {
        if (size >= array.length) {
            System.out.println("Mảng đã đầy, không thể thêm mới số.");
            return;
        }
        System.out.print("Nhập số cần thêm vào mảng: ");
        int number = scanner.nextInt();
        array[size++] = number;
        System.out.println("Số " + number + " đã được thêm vào mảng.");
    }
}
