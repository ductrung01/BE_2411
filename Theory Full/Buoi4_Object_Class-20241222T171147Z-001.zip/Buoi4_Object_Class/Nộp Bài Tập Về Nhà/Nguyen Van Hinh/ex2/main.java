package lesson5.ex2;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);
        System.out.println("Input total book of library : ");
        int n = sc.nextInt();
        quanLiSach qls = new quanLiSach(n);


        for (int i= 0; i<3; i++){
            Book  book = new Book(i+ "P",
                    "Nhà xuất bản " + i,
                    i + "soBanPhatHanh",
                    "Tên tác giả " + i,
                    i,
                    i + 1,
                    i + 1,
                    i + 1);
            qls.addBook(book);
        }
        int choice ;

        do{
    System.out.println("\n===== MENU =====");
    System.out.println("1. Hiển thị danh sách");
    System.out.println("2. Thêm sách");
    System.out.println("3. Xóa sách");
    System.out.println("4. Thoát");
    System.out.print("Nhập lựa chọn của bạn: ");
    choice= sc.nextInt();
            switch (choice) {
                case 1:
                    qls.printBook();
                    break;
                case 2:
                    System.out.println("Nhập vào thông tin sách");
                    Book book = new Book();
                    book.nhapDuLieu();
                    qls.addBook(book);
                    break;
                case 3:
                    qls.deleteBook();
                    break;
                case 4:
                    System.out.println("Đã thoát chương trình.");
                    System.exit(0);
                default:
                    System.out.println("Lựa chọn không hợp lệ, vui lòng chọn lại.");
        }

       }    while(choice >=0);
        sc.close();
    }
}
