package lesson5.ex2;

import java.util.Scanner;

public class Book {

    //Bài 1
    //     Một thư viện cần quản lý các Sách
    //     Mỗi cuốn Sách gồm có các thuộc tính sau:
    //         Mã sách (Mã tài liệu là duy nhất),
    //         Tên nhà xuất bản,
    //         số bản phát hành.
    //         tên tác giả
    //         số trang.
    //         Ngày phát hành.: long
    //         Số phát hành,
    //         tháng phát hành.: long
    //     Yêu cầu 1:
    //        Xây dựng lớp Sách để quản lý tài liệu cho thư viện một cách hiệu quả.
    //     Yêu cầu 2:
    //        Xây dựng chương trình cho phép người dùng nhập vào thông tin hai cuốn sách và hiển thị ra thông tin của các cuốn sách sau khi nhập
    private String masach;
    private String namePublisher;
    private String soBanPhatHanh;
    private String nameAuthor;
    private int numberPages;
    private long dates;
    private int numberPublish;
    private long months;


    public Book(){

    }



    public Book(String masach, String namePublisher, String soBanPhatHanh, String nameAuthor, int numberPages, long dates, int numberPublish, long months){
        this.masach = masach;
        this.namePublisher = namePublisher;
        this.soBanPhatHanh = soBanPhatHanh;
        this.nameAuthor = nameAuthor;
        this.numberPages = numberPages;
        this.dates = dates;
        this.numberPublish = numberPublish;

    }

    public void nhapDuLieu(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Masach : ");
        this.masach = sc.nextLine();
        System.out.println("namePublisher: ");
        this.namePublisher = sc.next();
        System.out.println("soBanPhatHanh: ");
        this.soBanPhatHanh = sc.nextLine();
        sc.nextLine();
        System.out.println("nameAuthor: ");
        this.nameAuthor = sc.next();
        System.out.println("numberPages: ");
        this.numberPages = sc.nextInt();
        System.out.println("dates: ");
        this.dates = sc.nextLong();
        System.out.println("numberPublish: ");
        this.numberPublish = sc.nextInt();



    }
    public void show(){
        System.out.println("Masach : " + masach   + ", namePublisher='" + namePublisher + ", soBanPhatHanh=" + soBanPhatHanh  + ", nameAuthor='" + nameAuthor + ", numberPages=" + numberPages
        + ", dates=" + dates + ", numberPublish=" + numberPublish + ", months=" + months);
    }


    public String getMasach() {
        return masach;
    }

    public void setMasach(String masach) {
        this.masach = masach;
    }

    public String getNamePublisher() {
        return namePublisher;
    }

    public void setNamePublisher(String namePublisher) {
        this.namePublisher = namePublisher;
    }

    public String getSoBanPhatHanh() {
        return soBanPhatHanh;
    }

    public void setSoBanPhatHanh(String soBanPhatHanh) {
        this.soBanPhatHanh = soBanPhatHanh;
    }

    public String getNameAuthor() {
        return nameAuthor;
    }

    public void setNameAuthor(String nameAuthor) {
        this.nameAuthor = nameAuthor;
    }

    public int getNumberPages() {
        return numberPages;
    }

    public void setNumberPages(int numberPages) {
        this.numberPages = numberPages;
    }

    public long getDates() {
        return dates;
    }

    public void setDates(long dates) {
        this.dates = dates;
    }

    public int getNumberPublish() {
        return numberPublish;
    }

    public void setNumberPublish(int numberPublish) {
        this.numberPublish = numberPublish;
    }

    public long getMonths() {
        return months;
    }

    public void setMonths(long months) {
        this.months = months;
    }

    @Override
    public String toString() {
        return "book{" +
                "masach=" + masach +
                ", namePublisher='" + namePublisher + '\'' +
                ", soBanPhatHanh=" + soBanPhatHanh +
                ", nameAuthor='" + nameAuthor + '\'' +
                ", numberPages=" + numberPages +
                ", dates=" + dates +
                ", numberPublish=" + numberPublish +
                ", months=" + months +
                '}';
    }
}
