package lesson5.ex2;

import java.util.Scanner;

public class quanLiSach {
    private Book[] arrBook;
    private int currentBook;
    private int totalBook;

//constructor: dùng để khởi tạo đối tượng; để jvm cấp phát đối tượng ô nhớ trong vùng heap
    public quanLiSach(int totalBook) {
        this.totalBook = totalBook;
        this.arrBook = new Book[totalBook];
        this.currentBook = 0;
    }

    public void addBook(Book newBook) {
        if(this.currentBook == this.totalBook){
            System.out.println("The library is full ; can't add ");
            return;
        }
        this.arrBook[this.currentBook] = newBook;
        this.currentBook++;
    }

    public void printBook(){
        for(int i = 0; i< this.currentBook; i++){
            System.out.println(arrBook[i].toString());
        }
    }

    public void deleteBook(){
        System.out.println(" Nhap vao ma sach: ");
        Scanner sc = new Scanner(System.in);
        String maSach = sc.nextLine();
        boolean deleteSuccess = false;
        for(int i = 0; i< this.currentBook; i++){
            if (arrBook[i].getMasach().equals(maSach)){
                for(int j = i; j< this.currentBook; j++){
                    this.arrBook[j] = this.arrBook[j+1];
                }
                this.currentBook--;
                deleteSuccess = true;
            }
            if(deleteSuccess){
                System.out.println("Book " + arrBook[i].getMasach() + " successfully deleted");
            }
        }
    }

}
