package lesson5.ex1;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of array elements: ");
        int n = sc.nextInt();
        if (n < 0) {
            System.out.println("the number must be greater than or equal to zero");
        }
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        int choice;
        do {
            System.out.println("\nMENU");
            System.out.println("1. Hien thi gia tri trung binh");
            System.out.println("2. Hien thi phan tu lon nhat");
            System.out.println("3. Sap xep mang theo thu tu giam dan");
            System.out.println("4. Sap xep mang theo thu tu tang dan");
            System.out.println("5. In cac phan tu xuat hien 2 lan");
            System.out.println("6. Tim kiem phan tu lon thu 3");
            System.out.println("7. Tim kiem mot so trong mang");
            System.out.println("8. Xoa mot so trong mang");
            System.out.println("9. Them mot so vao mang");
            System.out.println("0. Thoat");
            System.out.print("Nhap lua chon: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Display average : ");
                    System.out.println(tinhTrungBinh(arr));
                    break;
                case 2:
                    System.out.println("Display the largest element : ");
                    maxElement(arr);
                    break;
                case 3:
                    System.out.println("Sort array in descending: ");
                    descendingElement(arr);
                    break;
                case 4:
                    System.out.println("Sort array in ascending :");
                    ascendingElement(arr);
                    break;
                case 5:
                    System.out.println("Duplicate number in arrays: ");
                    duobleNumber(arr);
                    break;
                case 6:
                    System.out.println("the third largest number: ");
                    thirdNumberMax(arr);
                    break;
                case 7:
                    System.out.println("Input number which you need to search:");
                    search(arr);
                    break;
                case 8 :
                    System.out.println("Remove elements: ");
                    removeElement(arr);
                    printArray(arr);
                    break;
                case 9:
                    if (isFull(arr)){
                        System.out.println("The array is already full; can't add");
                    }else{
                        addNumber(arr);

                    }
                    break;
                default:
                    System.out.println("Invalid Input.");


            }
        } while (choice != 0);
        sc.close();


    }

    public static float tinhTrungBinh(int[] arr) {
        float sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        return (float)(sum / arr.length);
    }

    public static void maxElement(int[] arr) {
        int max = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        System.out.println("The largest number is: " + max);
    }

    public static void descendingElement(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] < arr[j]) {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        System.out.println("Descending element array:");
        main.printArray(arr);
    }

    public static void ascendingElement(int[] arr) {
        int temp, i, j;
        for (i = 0; i < arr.length; i++) {
            for (j = i + 1; j < arr.length; j++) {
                if (arr[i] < arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
            for (int num : arr) {
                System.out.println(num + " ");
            }
        }
    }
    public static void duplicateElement(int[] arr){
        int count = 0;
        for (int i = 0; i< arr.length; i++){
            for (int j  = i + 1; j <arr.length ; j++){
                if (arr[i] == arr[j]){
                    count++;
                    System.out.println("Cac phan tu xuat hien 2 la trong mang la:" + arr[i]);

                }
                }
            if (count == 0){
                System.out.println("No exist duplicat elements");
            }
        }
    }

    public static void search(int[] arr){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your number you want: ");
        int n = sc.nextInt();
        boolean found =false ;
        for (int i = 0 ; i< arr.length; i++){
            if (n == arr[i]){
                System.out.println("Number found at index: " + i);
                found = true;
                break;
            }
            }
        if (!found){
            System.out.println("dont exist");
        }
    }
    public static void removeElement(int [] arr){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number you want to remove: ");
        int n = sc.nextInt();
        for (int i = 0 ; i< arr.length; i++){
            if (n == arr[i]){
                for (int j = i ; j< arr.length -1 ; j++){
                    if(j == arr.length -1){
                        arr[j] = -1;
                    } else{
                        arr[j] = arr[j+1];
                    }
                }
                i-=1;
                System.out.println(" Element" + n + " was removed successfully");
            }
        }

    }
    public static boolean isFull(int[] arr){
        return arr[arr.length -1 ] != 0;
    }
    public static void addNumber(int[] arr) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number you want to add: ");
        int num = sc.nextInt();
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == 0) {
                arr[i] = num;
                System.out.println("Number " + num + " added to the array at index " + i);
                break;
            }
        }

    }
    public static void printArray(int[] arr){
        for (int i = 0; i < arr.length; i++) {
            if( i >=0){
                System.out.println(arr[i] + " ");
            }
        }
    }
    public static boolean findAnyNumber(int n, int[] arr){
        boolean timThay = false;
        for (int i = 0; i< arr.length; i++){
            if(arr[i] == n){
                timThay = true;
                break;
            }
        }
        return timThay;
    }
    // [] soDaTim
    //duyệt mảng; nếu biến đếm phần tử thứ j == i ==> đếm++
    //(nếu đếm ==2 && soDaTim không chứa j) { đếm ++; soDaTim.add(j);}
    public static void duobleNumber( int[] arr){
        int[] soDaTim = new int[arr.length];

        for (int i = 0; i< arr.length; i++){
            int dem = 1;
            for(int j = 0; j< arr.length; j++){
             // tránh trường hợp để kiểm tra lại tăng biến đếm lên 2
                if(i!=j && arr[i] == arr[j] && !main.findAnyNumber(arr[i],soDaTim )){
                    dem++;
//if(!main.findAnyNumber(arr[i],soDaTim))  {
//    soDaTim[i] = arr[i];
//}
                }
            }
            if(dem==2 ){
                soDaTim[i] = arr[i];
                System.out.println("duplicate number : " + arr[i]);
            }
        }
    }
    //lọc ra các số trùng lặp trong mảng để đảm bảo không trùng lặp
    // sắp xếp mảng = target
    // sắp xếp mảng target tìm số thứ 3

    public static void thirdNumberMax(int[] arr){
        int [] soKhongTrung = new int[arr.length];
        int soLuongKhongTrung = 0;
        for(int i = 0; i< arr.length; i++ ){
            if(!main.findAnyNumber(arr[i], soKhongTrung)){
                soKhongTrung[soLuongKhongTrung] = arr[i];
                soLuongKhongTrung++;
            }
        }


        //săp xep mang
        for(int i =0; i<soLuongKhongTrung; i++){
            for(int j = i+1; i<soLuongKhongTrung; i++){
                if(soKhongTrung[i] < soKhongTrung[j]){
                    int temp = soKhongTrung[i];
                    soKhongTrung[i] = soKhongTrung[j];
                    soKhongTrung[j] = temp;
                }

//            }
//        }

                //find the third-largest number
                if (soLuongKhongTrung < 3){
                    System.out.println("Không tồn tại số lớn thứ 3");
                }
                else{
                    System.out.println("số lớn thứ 3 là : " + soKhongTrung[2]);}
            }
            }
    }


    
    }
