package org.example.buoi4;

import java.util.*;

public class Array {
    public void testLap() {
        Scanner scanner = new Scanner(System.in);
        int[] aInts = {2, 4, 3, 5, 5,7,6};
        int a = 0;

        do {
            System.out.println("Mời Bạn Nhập Chức Năng:");
            System.out.println("Nhập 1 Hiển Thị Giá Trị Trung Bình Dãy");
            System.out.println("Nhập 2 Hiển thị phần tử có giá trị lớn nhất");
            System.out.println("Nhập 3 Sắp Sếp mảng theo thứ tự giảm dần");
            System.out.println("Nhập 4 Sắp Sếp mảng theo thứ tự tăng dần");
            System.out.println("Nhập 5 In ra Phần Tử Xuất Hiện 2 lần trong mảng");
            System.out.println("Nhập 6 Tìm Kiếm Phần tử lớn thứ 3 trong mảng nếu có");
            System.out.println("Nhập 7 Cho Người Dùng Nhập vào 1 số tìm số đó trong mảng");
            System.out.println("Nhập 8 Cho Người Dùng Nhập vào 1 xóa đi số đó trong mảng");
            System.out.println("Nhập 9 Cho Người Dùng Nhập vào 1 thêm số vào mảng");
            System.out.println("Nhập 10 Thoát");

            a = scanner.nextInt();
            switch (a) {
                case 1:
                    float tb = 0;
                    for (int i : aInts) {
                        tb += i;
                    }
                    tb /= aInts.length;
                    System.out.println("Tb Của mảng là :" + tb);
                    break;
                case 2:
                    int max = aInts[0];
                    for (int i = 0; i < aInts.length; i++) {
                        if (aInts[i] > max) {
                            max = aInts[i];
                        }
                    }
                    System.out.println("Số Lớn Nhất trong mảng: " + max);
                    break;
                case 3:
                    int tam; // Biến tạm để hoán đổi

                    // Sắp xếp mảng theo thứ tự giảm dần
                    for (int i = 0; i < aInts.length; i++) {
                        for (int j = i + 1; j < aInts.length; j++) {
                            // Nếu phần tử thứ i nhỏ hơn phần tử thứ j, đổi chỗ hai phần tử
                            if (aInts[i] < aInts[j]) {
                                // Đổi chỗ
                                tam = aInts[i];
                                aInts[i] = aInts[j];
                                aInts[j] = tam;
                            }
                        }
                    }
                    System.out.println("Mảng sau khi sắp xếp giảm dần là: ");
                    for (int num : aInts) {
                        System.out.println(num);
                    }

                    break;
                case 4:
                    int tam2;
                    for (int n = 0; n < aInts.length; n++) {
                        for (int j = a + 1; j < aInts.length; j++) {
                            if (aInts[n] > aInts[j]) {
                                // đổi chỗ
                                tam2 = aInts[n];
                                aInts[n] = aInts[j];
                                aInts[j] = tam2;
                            }
                        }
                    }
                    System.out.println("Mảng sau khi sắp xếp tăng dần là là: ");
                    for (int num : aInts) {
                        System.out.println(num);
                    }
                    break;
                case 5:
                    int maxRange = 100;

                    // Tìm các số xuất hiện đúng hai lần
                    findDuplicates(aInts, maxRange);
                    break;
                case 6:
                    // lọc ra các số trùng lặp trong mảng = target
                    int[] mangSoKhongTrung = new int[aInts.length];
                    int soLuongSoKhongTrung = 0;
                    for (int i = 0; i < aInts.length; i++) {
                        if (!Array.timSoBatKy(aInts[i],mangSoKhongTrung)){
                            mangSoKhongTrung[soLuongSoKhongTrung] = aInts[i];
                            soLuongSoKhongTrung++;
                        }
                    }
                    // sắp xếp mảng target
                    for (int i = 0; i < soLuongSoKhongTrung; i++) {
                        for (int j = i + 1; j < soLuongSoKhongTrung; j++) {
                            if (mangSoKhongTrung[i] < mangSoKhongTrung[j]){
                                int tamNho = mangSoKhongTrung[i];
                                mangSoKhongTrung[i] = mangSoKhongTrung[j];
                                mangSoKhongTrung[j] = tamNho;
                            }
                        }
                    }
                    // tìm ra số lớn thứ 3
                    if (soLuongSoKhongTrung < 3){
                        System.out.println("Không tồn tại số lớn thứ 3");
                    }else {
                        System.out.println("Số lớn thứ 3 là: " + mangSoKhongTrung[2]);
                    }
                    break;
                case 7:
                    System.out.println("Mời bạn nhập vào 1 số:");
                    int c = scanner.nextInt();
                    if(Array.timSoBatKy(c,aInts)){
                        System.out.println("số có tồn tại trong mảng :"+c);
                    }else {
                        System.out.println("số Ko tồn tại trong mảng :");
                    };
                    break;
                case 8:
                    System.out.println("Nhập vào số cần xóa: ");
                    int soCanXoa = new Scanner(System.in).nextInt();
                    for (int i=0;i<aInts.length;i++){
                        if (aInts[i] == soCanXoa){
                            for (int j = i; j < aInts.length; j++) {
                                if (j == aInts.length - 1){
                                    aInts[j] = -1;
                                }else {
                                    aInts[j] = aInts[j + 1];
                                }
                            }
                            i-=1;
                        }
                    }
                    System.out.println("mảng sau khi xóa");
                    for (int num :aInts){
                        System.out.println(num);
                    }
                    break;
                case 9:
                    System.out.println("Mời bạn nhập vào 1 số:");
                    int numberToAdd = scanner.nextInt();
                   aInts =  Array.themVaoMang(aInts,numberToAdd);
                    System.out.println("Mảng sau khi thêm là :");
                    for (int num : aInts){
                        System.out.println(num);
                    }
                    break;
                case 10:
//
                default:
                    System.out.println("Chức năng không hợp lệ.");
            }
        } while (a != 10);
    }
    public static void findDuplicates(int[] arr, int maxRange) {
        // Mảng bổ trợ để đếm số lần xuất hiện của mỗi phần tử
        int[] countArray = new int[maxRange + 1];

        // Đếm số lần xuất hiện của mỗi phần tử
        for (int num : arr) {
            countArray[num]++;
        }

        // In ra các số xuất hiện đúng hai lần
        System.out.println("Các số xuất hiện đúng hai lần là: ");
        for (int i = 0; i <= maxRange; i++) {
            if (countArray[i] == 2) {
                System.out.println(i);
            }
        }
    }
    public static boolean timSoBatKy(int n,int[] arr){
        boolean timThay = false;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == n){
                timThay=true;
                break;
            }
        }
        return timThay;
    }
    public static int[] themVaoMang(int[] arr, int soMoi) {
        // Tạo một mảng mới với kích thước lớn hơn mảng ban đầu một đơn vị
        int[] newArr = new int[arr.length + 1];

        // Sao chép các phần tử từ mảng ban đầu sang mảng mới
        for (int i = 0; i < arr.length; i++) {
            newArr[i] = arr[i];
        }

        // Thêm phần tử mới vào vị trí cuối cùng của mảng mới
        newArr[newArr.length - 1] = soMoi;

        // Trả về mảng mới
        return newArr;
    }

}
