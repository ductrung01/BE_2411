package org.example.buoi4;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class QuanLySach {
    Sach[] saches = new Sach[3];

    public QuanLySach() {
        Date date = new Date();
        saches[0] = new Sach("001", "Toán", "Quân", 25.36F, date);
        saches[1] = new Sach("002", "Văn", "Quang", 25.36F, date);
        saches[2] = new Sach("003", "Anh", "HÀ", 25.36F, date);

    }

    public void NhapSach() {
        Date date = new Date();
        int a = 0;
        do {
            System.out.println("Mời Bạn Nhập Chức Năng:");
            System.out.println("Nhập 1 Thêm Sách");
            System.out.println("Nhập 2 Xóa Sách ");
            a = new Scanner(System.in).nextInt();
            switch (a) {
                case 1:
                    Sach sachNhap = new Sach();
                    Scanner scanner = new Scanner(System.in);
                    System.out.println("Mời Bạn Nhập Mã Sach /n");
                    sachNhap.setMa(scanner.nextLine());
                    System.out.println("Mời Bạn Nhập Tên Sach /n");
                    sachNhap.setName(scanner.nextLine());
                    System.out.println("Mời Bạn Nhập Tác Giả /n");
                    sachNhap.setTacGia(scanner.nextLine());
                    System.out.println("Mời Bạn Nhập Giá Sach /n");
                    sachNhap.setGia(scanner.nextFloat());
                    sachNhap.setNgayPhatHanh(date);

                    saches = QuanLySach.addSach(saches, sachNhap);

                    System.out.println("------------Thông tin sách----------");
                    for (Sach sach : saches) {
                        System.out.println(sach);
                    }

                    break;
                case 2:
                    System.out.println("mời bạn Nhập Mã Sách");
                    String ma = new Scanner(System.in).nextLine();
                    saches=QuanLySach.removeSach(saches,ma);
                    System.out.println("------------Thông tin sách----------");
                    for (Sach sach : saches) {
                        System.out.println(sach);
                    }
                    break;
                case 3:
                    System.out.println("thoát")
                    ;
                    break;

            }
        } while (a != 3);

    }

    public static Sach[] addSach(Sach[] saches, Sach newSach) {
        // Tạo một mảng mới với kích thước lớn hơn mảng ban đầu một đơn vị
        Sach[] newBooks = new Sach[saches.length + 1];
        // Sao chép các phần tử từ mảng ban đầu sang mảng mới
        for (int i = 0; i < saches.length; i++) {
            newBooks[i] = saches[i];
        }
        // Thêm cuốn sách mới vào vị trí cuối cùng của mảng mới
        newBooks[newBooks.length - 1] = newSach;
        // Trả về mảng mới
        return newBooks;
    }
    public static Sach[] removeSach(Sach[] saches, String maSachXoa) {
        // Tạo một mảng mới có kích thước nhỏ hơn một đơn vị so với mảng ban đầu
        Sach[] newSaches = new Sach[saches.length - 1];

        int newIndex = 0;

        // Duyệt qua mảng ban đầu để sao chép các phần tử vào mảng mới, loại bỏ phần tử có mã sách cần xóa
        for (int i = 0; i < saches.length; i++) {
            // Nếu mã sách của cuốn sách hiện tại không trùng khớp với mã sách cần xóa
            if (!saches[i].getMa().equals(maSachXoa)) {
                // Sao chép cuốn sách hiện tại vào mảng mới
                newSaches[newIndex] = saches[i];
                // Tăng chỉ số của mảng mới
                newIndex++;
            }
        }

        // Trả về mảng mới sau khi xóa cuốn sách
        return newSaches;
    }


}






