package org.example.buoi4;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Sach {
  private String ma;
  private String name;
  private String tacGia;
  private float gia;
  private Date ngayPhatHanh;

    public Sach(String ma, String name, String tacGia, float gia, Date ngayPhatHanh) {
        this.ma = ma;
        this.name = name;
        this.tacGia = tacGia;
        this.gia = gia;
        this.ngayPhatHanh = ngayPhatHanh;
    }

    public Sach() {
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTacGia() {
        return tacGia;
    }

    public void setTacGia(String tacGia) {
        this.tacGia = tacGia;
    }

    public float getGia() {
        return gia;
    }

    public void setGia(float gia) {
        this.gia = gia;
    }

    public Date getNgayPhatHanh() {
        return ngayPhatHanh;
    }

    public void setNgayPhatHanh(Date ngayPhatHanh) {
        this.ngayPhatHanh = ngayPhatHanh;
    }
    @Override
    public String toString() {
        // Sử dụng SimpleDateFormat để định dạng ngày tháng
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String ngayPhatHanhStr = (ngayPhatHanh != null) ? sdf.format(ngayPhatHanh) : "N/A";

        return "Book{" +
                "ma='" + ma + '\'' +
                ", name='" + name + '\'' +
                ", tacGia='" + tacGia + '\'' +
                ", gia=" + gia +
                ", ngayPhatHanh=" + ngayPhatHanhStr +
                '}';
    }
}
