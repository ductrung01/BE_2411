package com.t3h.insurance_claim.mapper;

public class InsuranceMapper {

}
