create database quanli;

use quanli;


create table students(
    student_id int auto_increment primary key,
name varchar(50),
    age int,
    major varchar(50)
);

create table course(
    course_id int auto_increment primary key,
    course_name varchar(50),
    credits int
);

insert into students (name, age, major) VALUES
('NVA', 18, ' IT '),
('NVB', 19, 'Déigner'),
('NVC', 20, 'Lawer');

insert into course(course_name, credits) VALUES
('Web develop', 3),
('Graphic déign', 4),
('Law research' , 5);

alter table students add column email varchar(50);

-- thay đôie major thành department
alter table students change column major department varchar(50);


-- Chèn thêm một sinh viên mới vào bảng students
insert into students (name, age, department, email) values ('NVD', 21, 'Teacher', 'hhhhh@gmail.com');
update students set age = 22 where name = 'NVB';

-- b4: Sử dụng khóa ngoại
create table enrollments (
            enrollment_id int auto_increment primary key,
            student_id int,
            course_id int,
            enrollment_date date,
                foreign key (student_id) references students(student_id),
    foreign key (course_id) references course(course_id)
);

-- Truy vấn tất cả các sinh viên trong bảng students
select * from students;

-- Truy vấn danh sách các sinh viên đã đăng ký một khóa học cụ thể.
select * from students st inner join course c on st.student_id = c.course_id inner join enrollments e on c.course_id = e.course_id
where course_name ='Web develop ';

-- Truy vấn danh sách các khóa học mà một sinh viên cụ thể đã đăng ký.

select * from students st inner join course c on st.student_id = c.course_id inner join enrollments e on c.course_id = e.course_id
where name = 'NVA';
-- Đếm số lượng sinh viên trong mỗi ngành học (department) trong bảng students.
select department, count(*) as student_count from students group by department;



