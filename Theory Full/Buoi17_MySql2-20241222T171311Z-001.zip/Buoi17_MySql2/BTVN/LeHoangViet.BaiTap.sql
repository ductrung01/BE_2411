# Bài tập 1: Tạo bảng và chèn dữ liệu
# Tạo mới cở sở dữ liệu quanlyhocsinh và sử dụng câu lệnh use quanlyhocsinh để chỉ định sử dụng database quanlyhocsinh
# Đầu bài: Bạn cần tạo hai bảng students và courses trong cơ sở dữ liệu của bạn.
# Yêu cầu:
# Tạo bảng students với các cột:
# student_id: kiểu INT, khóa chính, tự động tăng.
# name: kiểu VARCHAR(50).
# age: kiểu INT.
# major: kiểu VARCHAR(50).
# Tạo bảng courses với các cột:
# course_id: kiểu INT, khóa chính, tự động tăng.
# course_name: kiểu VARCHAR(50).
# credits: kiểu INT.
# Chèn vào bảng students ít nhất 3 sinh viên với các thông tin như tên, tuổi và ngành học.
# Chèn vào bảng courses ít nhất 3 khóa học với các thông tin như tên khóa học và số tín chỉ.

create database quanlyhocsinh;
use quanlyhocsinh;
 create table students(
     student_id int primary key auto_increment,
     name varchar(50),
     age int,
     major varchar(50)
 );

 create table courses(
    courses_id int primary key auto_increment,
    courses_name varchar(50),
    credits int
 );

INSERT INTO students (name, age, major) value
('Lê Hoàng Việt',23,'It'),
('Vũ Thanh Tùng',24,'doctor'),
('Hà Mạnh Chiến',25,'police');
select *from students;

INSERT INTO courses (courses_name, credits) value
('Lập trình JAVA',3),
('Lập trình Python',5),
('Lập trình C++',6);
select * from courses;

#---------------------------------------------------------------#
# Bài tập 2: Sửa bảng
# Đầu bài: Bạn cần thêm cột mới và thay đổi cấu trúc của bảng students.
# Yêu cầu:
# Thêm một cột email vào bảng students với kiểu dữ liệu VARCHAR(100).
alter table students add column email varchar(100);
select *from students;

# Đổi tên cột major thành department.
alter table students rename column major to department;
select * from students;

#---------------------------------------------------------------#
# Bài tập 3: Chèn và cập nhật dữ liệu
# Đầu bài: Bạn cần chèn dữ liệu mới và cập nhật dữ liệu đã có trong bảng.
# Yêu cầu:
# Chèn thêm một sinh viên mới vào bảng students.
insert into students (name, age,department,email)
values ('Nguyễn Văn A',30,'CEO','nguyenvana@gmail.com');
select * from students;

# Cập nhật tuổi của một sinh viên cụ thể trong bảng students.
update students set age =25 where name= 'Lê Hoàng Việt';
select * from students;

#---------------------------------------------------------------#
# Bài tập 4: Sử dụng khóa ngoại
# Đầu bài: Bạn cần tạo một bảng mới enrollments để quản lý việc đăng ký khóa học của sinh viên.
# Yêu cầu:
# Tạo bảng enrollments với các cột:
# enrollment_id: kiểu INT, khóa chính, tự động tăng.
# student_id: kiểu INT.
# course_id: kiểu INT.
# enrollment_date: kiểu DATE.
# Thiết lập khóa ngoại student_id tham chiếu tới student_id của bảng students.
# Thiết lập khóa ngoại course_id tham chiếu tới course_id của bảng courses.

create table enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    course_id INT,
    enrollment_date DATE,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(courses_id)
);
select * from enrollments;


#---------------------------------------------------------------#
# Bài tập 5: Các loại truy vấn
# Đầu bài: Bạn cần thực hiện các truy vấn cơ bản để lấy thông tin từ các bảng đã tạo.
# Yêu cầu:
# Truy vấn tất cả các sinh viên trong bảng students.
SELECT * FROM students;

# Truy vấn tất cả các khóa học trong bảng courses.
SELECT * FROM courses;

# Truy vấn danh sách các sinh viên đã đăng ký một khóa học cụ thể.
SELECT s.student_id, s.name, s.age, s.department, s.email
FROM students s
         JOIN enrollments e ON s.student_id = e.student_id
WHERE e.course_id = 1;


# Truy vấn danh sách các khóa học mà một sinh viên cụ thể đã đăng ký.
# Đếm số lượng sinh viên trong mỗi ngành học (department) trong bảng students.
