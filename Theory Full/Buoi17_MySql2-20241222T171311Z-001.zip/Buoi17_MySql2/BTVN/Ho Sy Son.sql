-- 1)
create database quanlyhocsinh;
use quanlyhocsinh;
create table students(
    student_id int auto_increment primary key ,
    name varchar(50),
    age int,
    major varchar(50)
);
create table courses(
    course_id int auto_increment primary key ,
    course_name varchar(50),
    credist int
);
insert into students(name, age, major) VALUES ('Lê Văn Tuấn','19','IT');
insert into students(name, age, major) VALUES ('Lê Văn Thành','20','IT');
insert into students(name, age, major) VALUES ('Trần Anh Tuấn','21','IT');


insert into courses(course_name, credist) VALUES ('Lập trình C',4);
insert into courses(course_name, credist) VALUES ('Lập trình Java',5);
insert into courses(course_name, credist) VALUES ('Lập trình Python',3);

-- 2)
alter table students
add email varchar(100);
alter table students change major department varchar(50);

-- 3)
insert into students(name, age, department) values ('Hồ Sỹ Sơn','19','IT');
update students set age = '18' where name = 'Lê Văn Tuấn';

-- 4)
create table enrollments(
    enrollment_id int auto_increment primary key ,
    student_id int,
    course_id int,
    enrollment_date date,
    foreign key (student_id) references students(student_id),
    foreign key (course_id) references courses(course_id)
);

-- 5)
select * from students;
select * from courses;

-- 6)
select * from students where age = (select max(age) from students);
select * from courses where credist = (select max(credist) from courses);