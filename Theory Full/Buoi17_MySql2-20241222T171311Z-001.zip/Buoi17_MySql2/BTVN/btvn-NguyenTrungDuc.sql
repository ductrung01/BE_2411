create database manager_students;
use manager_students; 
create table students(
	student_id int primary key auto_increment,
    name varchar(50),
    age int ,
    major varchar(50)
);

create table manager(
	course_id int primary key  auto_increment,
	course_name varchar(50),
	credits int
);

insert into students ( name , age,major) values 
	('Nguyen',18,'cntt'),
	('Trung',20,'ke toan'),
	('Duc',22,'Duoc');
    select form students ;
insert into manager (course_name , credits ) values 
	('toan roi rac' ,5),
    ('lap trinh cau truc',3),
    ('c' , 3);
    select form manager ;
    
    #bai2 
    #them cot 
    use manager_students; 
ALTER TABLE  students
ADD column gmail   VARCHAR(100);
select students;
	#doi ten 
ALTER TABLE  students
CHANGE  column major department varchar(50);
select students;
	#bai 3
    #chen 
    insert into students(name,age,department)values
    (' a ',21,'thiet ke wed');
select * from students;
	#capnhat
update students
set age=39
where name='Nguyen';
select *from students;    
#bai4 
create table enrollments(
enrollment_id int primary key auto_increment,
student_id int ,
course_id int ,
enrollment_date date,
foreign key (student_id)references students(student_id),
foreign key (course_id)references courses(course_id)
);