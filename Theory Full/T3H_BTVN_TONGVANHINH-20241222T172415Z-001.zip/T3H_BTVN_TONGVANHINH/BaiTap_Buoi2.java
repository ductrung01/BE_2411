package com.t3h.buoi2;

import java.util.Scanner;

public class BaiTap {
    public static void main(String[] args) {
        //Bài 1. Tính diện tích và Chu vi hình chữ nhật, với chiều dài và chiều rộng nhập từ bàn phím
        int chieuDai;
        int chieuRong;
        int dienTich;
        int chuVi;

        //Khai báo thư viện để đọc dữ liệu đầu vào
        Scanner sc = new Scanner(System.in);
        System.out.println("Bạn hãy nhập vào chiều dài của hình chữ nhât: ");
        chieuDai = sc.nextInt();
        System.out.println("Bạn hãy nhập vào chiều rộng của hình chữ nhật: ");
        chieuRong = sc.nextInt();

        //Tính diện tích S = dai * rong;
        dienTich = chieuDai * chieuRong;
        System.out.println("Diện tích của hình chữ nhật là: "+ dienTich);
        chuVi = (chieuDai + chieuRong) * 2;
        System.out.println("Chu vi của hình chữ nhật là: "+ chuVi);

        //Bài 2. Viết chương trình nhập vào một số nguyên. Kiểm tra số vừa nhập vào có phải số chẵn hay không?
        int soCheck;
        String ketQua;

        //Khai báo thư viện đọc dữ liệu đầu vào
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bạn vui lòng vào số cần kiểm tra: ");
        soCheck = scanner.nextInt();

        //Kiểm tra
        ketQua = soCheck % 2 == 0 ? "Số vừa nhập là số chẵn" : "Số vừa nhập không phải là số chẵn";
        System.out.println("Kết quả là "+ketQua);

        //Bài 3 Thực hiện theo hướng dẫn
        var a = 15;
        var b = 10;
        BaiTap.addToInt(a,b);
        System.out.println("Giá trị của a là: "+a);

        //Bài 4 thực hành theo huướng dẫn
        int moon = 9, start = 2 + 2 * 3;
        float sun = start > 10 ? 1 : 3;
        double jupiter = (sun + moon) - 1.0f;
        int mars = --moon <= 8 ? 2 : 3;
        System.out.println(sun+"-"+jupiter+"-"+mars);


    }

    public static void addToInt(int x, int amountToAdd){
        x = x +amountToAdd;
    }
}
