package com.t3h.buoi5_bai_kiem_tra_cuoi_module.bai1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Chương trình bắt đầu chạy");
        System.out.println("Mời bạn nhập vào số nguyên: ");
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        while (x <= 0) {
            System.out.println("Số không hơp lệ vui lòng nhập lại: ");
            x = sc.nextInt();
        }

        //Khai báo mảng
        int[] arrNum = new int[x];
        System.out.println("Bạn vừa tạo ra một mảng arrNum với "+x+" phần tử");

        //Nhập mảng
        for (int i = 0; i < arrNum.length; i++) {
            System.out.println("Mời bạn nhập vào phần tử thứ "+ (i+1));
            arrNum[i] = sc.nextInt();
        }


        //Bắt đầu chương trình
        while (true){
            System.out.println("\n======MENU=======");
            System.out.println("1. Hiển thị danh sách đã nhập");
            System.out.println("2. Tính tổng các phần tử lẻ của danh sách số nguyên");
            System.out.println("3. Nhập vào một số bất kỳ, cho biết có bao nhiêu số giống với số vừa nhập");
            System.out.println("4. Sắp xếp danh sách theo thứ tự từ bé đến lớn");
            System.out.println("5. Sắp xếp danh sách theo thứ tự từ lớn đến bé");
            System.out.println("6. Cho phép nhập vào một phần tử, xóa đi các phần tử trong mảng trùng với phần tử đã nhập");
            System.out.println("7. Thóa chương trình?");
            System.out.println("Nhập lựa chọn của bạn: ");
            int luaChon  = sc.nextInt();

            switch (luaChon){
                case 1:
                    Main.hienThiDanhSachMang(arrNum);
                    break;
                case 2:
                    Main.tinhTongCaSoLe(arrNum);
                    break;
                case 3:
                    System.out.println("Mời bạn nhập vào số cần so sánh: ");
                    int n = sc.nextInt();
                    Main.tinhSoLuongSoTrongMangGiongVoiSoVuaNhap(arrNum, n);
                    break;
                case 4:
                    Main.sapXepTheoThuTuTuBeDenLon(arrNum);
                    break;
                case 5:
                    Main.sapXepTheoThuTuTuLonDenBe(arrNum);
                    break;
                case 6:
                    System.out.println("Nhập vào số cần xóa trung: ");
                    int m = sc.nextInt();
                    Main.nhapVaoSoNguyenXoaCacPhanTuTrungVoiSoVuaNhap(arrNum, m);
                    break;
                case 7:
                    System.out.println("Đã thoát chương trình.");
                    System.exit(0);
                default:
                    System.out.println("Lựa chọn không hợp lệ, vui lòng chọn lại.");
            }
        }
    }

    public static void hienThiDanhSachMang(int[] arrN){
        System.out.println("Danh sách mảng vừa nhập là: ");
        for (int i = 0; i < arrN.length; i++) {
            System.out.println("Phần tử thứ "+(i+1)+" là: "+arrN[i]);
        }
    }

    public static void tinhTongCaSoLe(int[] arrN){
        int tongLe = 0;
        for (int i = 0; i < arrN.length; i++) {
            if(arrN[i] % 2 != 0){
                tongLe += arrN[i];
            }
        }
        System.out.println("Tổng các số lẻ trong mảng là: "+tongLe);
    }

    public static void tinhSoLuongSoTrongMangGiongVoiSoVuaNhap(int[] arrN, int n){
        int soLuong = 0;
        for (int i = 0; i < arrN.length; i++) {
            if(arrN[i] == n){
                soLuong++;
            }
        }
        System.out.println("Trong mảng có "+soLuong+" giống với số "+n);
    }

    public static void sapXepTheoThuTuTuBeDenLon(int[] arrN){
        int temp;
        for (int i = 0; i < arrN.length; i++) {
            for (int j = i + 1; j < arrN.length; j++) {
                if(arrN[i] > arrN[j]){
                    temp = arrN[i];
                    arrN[i] = arrN[j];
                    arrN[j] = temp;
                }
            }
        }
        Main.hienThiDanhSachMang(arrN);
    }

    public static void sapXepTheoThuTuTuLonDenBe(int[] arrN){
        int temp;
        for (int i = 0; i < arrN.length; i++) {
            for (int j = i + 1; j < arrN.length; j++) {
                if(arrN[i] < arrN[j]){
                    temp = arrN[i];
                    arrN[i] = arrN[j];
                    arrN[j] = temp;
                }
            }
        }
        Main.hienThiDanhSachMang(arrN);
    }

    public static void nhapVaoSoNguyenXoaCacPhanTuTrungVoiSoVuaNhap(int[] arrN, int n){
        int soLuongXoa = 0;
        for (int i = arrN.length - 1; i >= 0; i--) {
            for (int j = i; j >= 0; j--) {
                if(arrN[j] == n){
                    arrN[j] = arrN[j - 1];
                    soLuongXoa++;
                }
            }
        }
        System.out.println("Bạn đã xóa "+soLuongXoa+" trùng với số"+n);
        Main.hienThiDanhSachMang(arrN);
    }
}
