package com.t3h.buoi5_bai_kiem_tra_cuoi_module.bai2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Chào mừng bạn đến với Chương trình quản lý học sinh");
        System.out.println("Mời bạn nhập vào số lượng hồ sơ nhận");
        Scanner sc = new Scanner(System.in);
        int soLuong = sc.nextInt();

        //Khởi tạo lớp quản lý
        QuanLyHoSoHocSinh quanLyHoSoHocSinh = new QuanLyHoSoHocSinh(soLuong);

       while (true){
           System.out.println("\n===== MENU =====");
           System.out.println("1. Hiển thị danh sách hồ sơ học sinh");
           System.out.println("2. Thêm hồ sơ học sinh");
           System.out.println("3. Hiển thị học sinh có tuổi 23 và quê quán ở Đà Nẵng");
           System.out.println("4. Nhập vào tên hoặc năm sinh của sinh viên tìm kiếm các học sinh");
           System.out.println("5. Nhập vào mã học sinh và Tên học sinh, nếu trùng sẽ xóa đi học sinh đó");
           System.out.println("6. Cho phép nhập vào mã học sinh, hiển thị thông tin của sinh viên đó");
           System.out.println("7. Thoát chương trình");
           System.out.print("Nhập lựa chọn của bạn: ");
           int luaChon = sc.nextInt();
           sc.nextLine();

           switch (luaChon)
           {
               case 1:
                   quanLyHoSoHocSinh.hienThiDanhSach();
                   break;
               case 2:
                   System.out.println("Nhập thông tin hồ sơ học sinh: ");
                   HocSinh hocSinh = new HocSinh();
                   hocSinh.nhapThongTinHocSinh();
                   quanLyHoSoHocSinh.themmHoSo(hocSinh);
                   break;
               case 3:
                   System.out.println("Nhập vào tuổi và quê quán");
                   long tuoi = sc.nextInt();
                   sc.nextLine();
                   String queQuan = sc.nextLine();
                   quanLyHoSoHocSinh.hienThiTheoTuoiVaQueQuan(tuoi, queQuan);
                   break;

               case 4:
                   System.out.println("Nhập vào Tên hoặc tuổi để tìm kiếm");
                   String keyWord = sc.nextLine();
                   quanLyHoSoHocSinh.hienThiTheoTuoiVaTen(keyWord);
                   break;
               case 5:
                   System.out.println("Nhập vào thông mã học sinh: ");
                   String maHocSinh = sc.nextLine();
                   sc.nextLine();
                   String hoTenHocSinh = sc.nextLine();
                   quanLyHoSoHocSinh.timKiemVaXoaThongTinHocSinh(maHocSinh, hoTenHocSinh);
                   break;

               case 6:
                   System.out.println("Nhập vào mã học sinh");
                   String maHS = sc.nextLine();
                   quanLyHoSoHocSinh.timKiemTheoMaHienThiThongTinVaCapNhatThongTin(maHS);
                   break;
               case 7:
                   System.out.println("Đã thoát chương trình.");
                   System.exit(0);
                   break;
               default:
                   System.out.println("Lựa chọn không hợp lệ, vui lòng chọn lại.");
           }
       }
    }
}
