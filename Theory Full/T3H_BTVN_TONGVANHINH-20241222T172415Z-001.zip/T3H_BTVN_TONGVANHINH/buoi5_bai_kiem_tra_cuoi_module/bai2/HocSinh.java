package com.t3h.buoi5_bai_kiem_tra_cuoi_module.bai2;

import java.util.Scanner;

public class HocSinh {
    private String maHocSinh;
    private String hoVaTen;
    private long tuoi;
    private String queQuan;
    private long namSinh;
    private String soDienThoai;
    private String ngayThanhNamSinh;

    public HocSinh() {
    }

    public HocSinh(String maHocSinh, String hoVaTen, long tuoi, String queQuan, long namSinh, String soDienThoai, String ngayThanhNamSinh) {
        this.maHocSinh = maHocSinh;
        this.hoVaTen = hoVaTen;
        this.tuoi = tuoi;
        this.queQuan = queQuan;
        this.namSinh = namSinh;
        this.soDienThoai = soDienThoai;
        this.ngayThanhNamSinh = ngayThanhNamSinh;
    }

    public void nhapThongTinHocSinh(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập thông tin mã học sinh: ");
        this.maHocSinh = sc.nextLine();
        System.out.println("Nhập thông tin họ tên học sinh: ");
        this.hoVaTen = sc.nextLine();
        System.out.println("Nhập thông tin tuổi học sinh: ");
        this.tuoi = sc.nextLong();
        sc.nextLine();
        System.out.println("Nhập thông tin quê quán học sinh: ");
        this.queQuan = sc.nextLine();
        System.out.println("Nhập thông tin năm sinh học sinh: ");
        this.namSinh = sc.nextLong();
        sc.nextLine();
        System.out.println("Nhập thông tin số điện thoại học sinh: ");
        this.soDienThoai = sc.nextLine();
        System.out.println("Nhập thông tin ngày tháng năm sinh: ");
        this.ngayThanhNamSinh = sc.nextLine();
    }

    public void hienThiThongTin(){
        System.out.println(this.toString());
    }
    @Override
    public String toString() {
        return "HocSinh{" +
                "Mã học sinh = '" + maHocSinh + '\'' +
                ", Họ và tên = '" + hoVaTen + '\'' +
                ", Tuổi = " + tuoi +
                ", Quê quán = '" + queQuan + '\'' +
                ", Năm sinh = " + namSinh +
                ", Số điện thoại = '" + soDienThoai + '\'' +
                ", Ngày tháng năm sinh = '" + ngayThanhNamSinh + '\'' +
                '}';
    }

    public String getMaHocSinh() {
        return maHocSinh;
    }

    public void setMaHocSinh(String maHocSinh) {
        this.maHocSinh = maHocSinh;
    }

    public String getHoVaTen() {
        return hoVaTen;
    }

    public void setHoVaTen(String hoVaTen) {
        this.hoVaTen = hoVaTen;
    }

    public long getTuoi() {
        return tuoi;
    }

    public void setTuoi(long tuoi) {
        this.tuoi = tuoi;
    }

    public String getQueQuan() {
        return queQuan;
    }

    public void setQueQuan(String queQuan) {
        this.queQuan = queQuan;
    }

    public long getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(long namSinh) {
        this.namSinh = namSinh;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getNgayThanhNamSinh() {
        return ngayThanhNamSinh;
    }

    public void setNgayThanhNamSinh(String ngayThanhNamSinh) {
        this.ngayThanhNamSinh = ngayThanhNamSinh;
    }
}
