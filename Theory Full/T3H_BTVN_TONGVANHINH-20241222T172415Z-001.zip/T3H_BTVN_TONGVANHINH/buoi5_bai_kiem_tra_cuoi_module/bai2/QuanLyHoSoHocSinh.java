package com.t3h.buoi5_bai_kiem_tra_cuoi_module.bai2;

import java.util.Scanner;

public class QuanLyHoSoHocSinh {

    //Khai báo mảng hồ so học sinh
    private HocSinh[] hocSinhs;

    //Đánh dấu số lượng học sinh hiện tại
    private int soLuongHocSinhHienTai;

    //Đánh dấu số lượng hồ sơ học sinh nhận
    private int tongSoLuongHoSoHocSinh;

    //Khởi tạo lớp quan ly hoc sinh
    public QuanLyHoSoHocSinh(int tongSoLuongHocSinh) {
        this.hocSinhs = new HocSinh[tongSoLuongHocSinh];
        this.soLuongHocSinhHienTai = 0;
        this.tongSoLuongHoSoHocSinh = tongSoLuongHocSinh;
    }

    public void timKiemTheoMaHienThiThongTinVaCapNhatThongTin(String maHocSinh){
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < this.soLuongHocSinhHienTai; i++){
            if(hocSinhs[i].getMaHocSinh().equals(maHocSinh)){
                hocSinhs[i].hienThiThongTin();

                System.out.println("Cập nhật thông tin họ tên học sinh: ");
                hocSinhs[i].setHoVaTen(scanner.nextLine());
                System.out.println("Cập nhật thông tin tuổi học sinh: ");
                hocSinhs[i].setTuoi(scanner.nextLong());
                scanner.nextLine();
                System.out.println("Cập nhật thông tin quê quán học sinh: ");
                hocSinhs[i].setQueQuan(scanner.nextLine());
                System.out.println("Cập nhật thông tin năm sinh học sinh: ");
                hocSinhs[i].setNamSinh(scanner.nextLong());
                scanner.nextLine();
                System.out.println("Cập nhật thông tin số điện thoại học sinh: ");
                hocSinhs[i].setSoDienThoai(scanner.nextLine());
                System.out.println("Cập nhật thông tin ngày tháng năm sinh: ");
                hocSinhs[i].setNgayThanhNamSinh(scanner.nextLine());
            }
        }
    }

    //Tìm kiếm theo mã học sinh và xóa thông tin
    public void timKiemVaXoaThongTinHocSinh(String maHocSinh, String tenHocSinh){
        boolean xoaHocSinh = false;
        for (int i = 0; i < this.soLuongHocSinhHienTai; i++){
            /**
             * Kiểm tra nếu mã học sinh và tên nhập vào tồn tài
             */
            if(hocSinhs[i].getMaHocSinh().equals(maHocSinh) && hocSinhs[i].getHoVaTen().equals(tenHocSinh)){
                //Thực hiện xóa
                for(int j = i; j < this.soLuongHocSinhHienTai; j++){
                    this.hocSinhs[j] = this.hocSinhs[j+1];
                }
                this.soLuongHocSinhHienTai--;
                xoaHocSinh = true;
            }
            if(xoaHocSinh == true){
                System.out.println("Đã xóa thành công học sinh voi mã "+maHocSinh+" họ tên là "+tenHocSinh);
            }
        }
    }

    //Hiển thị học sinh theo năm và tên
    public void hienThiTheoNamSinhVaTen(String keword){
        for(int i = 0; i < this.soLuongHocSinhHienTai; i++){
            if(hocSinhs[i].getNamSinh() == Long.parseLong(keword) || hocSinhs[i].getHoVaTen().equalsIgnoreCase(keword)){
                System.out.println(this.hocSinhs[i].toString());
            }
        }
        System.out.println("Không có hồ sơ thỏa mã điều kiện");
    }

    //Hiển thị học sinh theo tuổi và Quê quán
    public void hienThiTheoTuoiVaQueQuan(long tuoi, String queQuan){
        for(int i = 0; i < this.soLuongHocSinhHienTai; i++){
            if(hocSinhs[i].getTuoi() == tuoi && hocSinhs[i].getQueQuan().equalsIgnoreCase(queQuan)){
                System.out.println(this.hocSinhs[i].toString());
            }
        }
        System.out.println("Không có hồ sơ thỏa mã điều kiện");
    }

    //Thêm moi ho so học sinh
    public void themmHoSo(HocSinh hocSinh){
        //Kiểm tra số lượng hồ sơ đã đầy chưa
        if(this.soLuongHocSinhHienTai == this.tongSoLuongHoSoHocSinh){
            System.out.println("Đã đủ số lượng hồ sơ");
            return;
        }

       this.hocSinhs[this.soLuongHocSinhHienTai] = hocSinh;
        soLuongHocSinhHienTai++;
    }
    //Hiển thị danh sách học sinh
    public void hienThiDanhSach(){
        if(this.soLuongHocSinhHienTai == 0){
            System.out.println("Hiện tại chưa có hồ sơ học sinh");
        }else{
            for(int i = 0; i < this.soLuongHocSinhHienTai; i++){
                System.out.println(this.hocSinhs[i].toString());
            }
        }
    }
}
