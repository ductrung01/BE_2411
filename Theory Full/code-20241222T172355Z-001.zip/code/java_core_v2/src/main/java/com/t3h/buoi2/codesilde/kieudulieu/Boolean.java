package com.t3h.buoi2.codesilde.kieudulieu;

public class Boolean {
    public static void main(String[] args) {
        boolean isTrue = true;
        System.out.println("boolean: " + isTrue);
    }
}
