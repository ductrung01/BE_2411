package com.t3h.buoi2.codesilde.phan1;

public class ViDuHang {


    public static void main(String[] args) {
        // Khai báo hằng số kiểu số nguyên
        final int SO_NGUYEN_HANG = 10;

        // Truy cập hằng số và hiển thị giá trị
        System.out.println("Giá trị của hằng số là: " + SO_NGUYEN_HANG);
        // SO_NGUYEN_HANG = 10 ;// Lỗi! Không thể thay đổi giá trị của hằng
    }
}
