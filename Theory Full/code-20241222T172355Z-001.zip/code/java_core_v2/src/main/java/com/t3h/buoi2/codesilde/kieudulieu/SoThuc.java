package com.t3h.buoi2.codesilde.kieudulieu;

public class SoThuc {
    public static void main(String[] args) {
        float f = 3.14f;
        double d = 3.141592653589793;

        System.out.println("float: " + f);
        System.out.println("double: " + d);
    }
}
