package com.t3h.buoi4.codeslide.haichieu;

/**



 <kiểu_dữ_liệu>[][] <tên_mảng> = new <kiểu_dữ_liệu>[số_hàng][số_cột];


 */
public class Main {
    public static void main(String[] args) {
        int[][] matrix = new int[3][3]; // Mảng hai chiều 3x3 chứa các số nguyên
    }

}
