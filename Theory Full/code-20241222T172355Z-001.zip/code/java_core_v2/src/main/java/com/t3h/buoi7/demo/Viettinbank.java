package com.t3h.buoi7.demo;

public class Viettinbank extends Bank{
}
