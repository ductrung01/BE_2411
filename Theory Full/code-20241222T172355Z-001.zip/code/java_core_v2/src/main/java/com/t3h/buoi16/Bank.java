package com.t3h.buoi16;

public class Bank {

    private Long soTien;

    public Long getSoTien() {
        return soTien;
    }

    public void setSoTien(Long soTien) {
        this.soTien = soTien;
    }
}
