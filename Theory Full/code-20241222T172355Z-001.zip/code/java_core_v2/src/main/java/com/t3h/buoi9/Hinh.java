package com.t3h.buoi9;

public class Hinh {

    public void hello(){
        System.out.printf("a");
    }
}
