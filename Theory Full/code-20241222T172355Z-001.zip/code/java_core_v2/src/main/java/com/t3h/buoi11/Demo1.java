package com.t3h.buoi11;

import java.util.Scanner;

public class Demo1 {

    /**
     Bài 1:
     Viết một chương trình yêu cầu người dùng nhập hai số nguyên
     và sau đó thực hiện phép chia số thứ nhất cho số thứ hai.
     Sử dụng xử lý ngoại lệ để đảm bảo chương trình không bị lỗi khi người dùng nhập 0 làm mẫu số.
     */
    public static void main(String[] args) {

       try {
//           System.out.println("Nhập vào 1 số nguyên a: ");
//           int a = new Scanner(System.in).nextInt();
//           System.out.println("Nhập vào 1 số nguyên a: ");
//           int b = new Scanner(System.in).nextInt();
//           System.out.println("a/b: " + a/b);
           Object person = null;
           person.toString();

           int[] arr = new int[3];
           arr[10] = 5;
       }catch (ArrayIndexOutOfBoundsException e){
           System.out.println("lỗi null");
       }catch (NullPointerException e){
           System.out.println("null object");
       }catch (Exception e){

       }

    }
}
