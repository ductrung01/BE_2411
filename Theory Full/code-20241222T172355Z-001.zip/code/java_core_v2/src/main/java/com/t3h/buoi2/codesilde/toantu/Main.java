package com.t3h.buoi2.codesilde.toantu;

public class Main {
    public static void main(String[] args) {
        int a = 10;
        int b = 5;
        int sum = a + b;    // sum = 15
        int difference = a - b;  // difference = 5
        int product = a * b;  // product = 50
        int quotient = a / b;  // quotient = 2

        int x = 10;
        int y = 5;
        x += y;  // Tương đương với x = x + y; (x = 15)

        int m = 10;
        int n = 5;
        boolean isEqual = (m == n);    // isEqual = false
        boolean isNotEqual = (m != n); // isNotEqual = true
        boolean isGreater = (m > n);   // isGreater = true
        boolean isLess = (m < n);      // isLess = false

        boolean condition1 = true;
        boolean condition2 = false;

        boolean andResult = (condition1 && condition2);  // andResult = false
        boolean orResult = (condition1 || condition2);   // orResult = true
        boolean notResult = !condition1;  // notResult = false

        int p = 10;
        int q = 5;

        int max = (p > q) ? p : q;  // max = 10


    }
}
