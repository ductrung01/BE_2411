package com.t3h.buoi14.chuabaikiemtramodule2.interfaces;

public interface TongHopCacChucNang {

    public void barkable();
    public void runable();
    public void flyable();
    public void swimable();
}
