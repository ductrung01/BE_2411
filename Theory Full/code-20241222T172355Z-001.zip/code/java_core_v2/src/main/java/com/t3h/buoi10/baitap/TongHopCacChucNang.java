package com.t3h.buoi10.baitap;

public interface TongHopCacChucNang {

    public abstract void barkable();
    public abstract void runable();
    public abstract void flyable();
    void swimable();
}
