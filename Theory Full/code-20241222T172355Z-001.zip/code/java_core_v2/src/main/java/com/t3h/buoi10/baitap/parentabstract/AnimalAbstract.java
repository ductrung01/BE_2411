package com.t3h.buoi10.baitap.parentabstract;


import com.t3h.buoi10.baitap.TongHopCacChucNang;

public abstract class AnimalAbstract implements TongHopCacChucNang {

    private String mauLong;

    @Override
    public void barkable() {

    }

    @Override
    public void runable() {

    }

    @Override
    public void flyable() {

    }

    @Override
    public void swimable() {

    }
}
