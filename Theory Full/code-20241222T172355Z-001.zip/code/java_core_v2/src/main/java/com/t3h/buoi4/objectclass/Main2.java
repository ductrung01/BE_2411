package com.t3h.buoi4.objectclass;

public class Main2 {
    public static void main(String[] args) {
        Sach lapTrinhC = new Sach();
        lapTrinhC.nhapThongTin();
        lapTrinhC.hienThiThongTin();
    }
}
