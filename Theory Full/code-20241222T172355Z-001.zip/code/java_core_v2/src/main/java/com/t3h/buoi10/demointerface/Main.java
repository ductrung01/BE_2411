package com.t3h.buoi10.demointerface;

public class Main {

    public static void main(String[] args) {
        // anonymous class => tức là class do JVM tự định nghĩa, chỉ thực thi các hàm
        // của interface
//        TongHopCacChucNang object = new TongHopCacChucNang() {
//            @Override
//            public void runnable() {
//                System.out.println("aaaaaaaaa");
//            }
//
//            @Override
//            public void flyable() {
//                System.out.println("bbbbbbbbbbb");
//            }
//
//            @Override
//            public void swimming() {
//                System.out.println("cccccccccc");
//            }
//        };
    }
}
