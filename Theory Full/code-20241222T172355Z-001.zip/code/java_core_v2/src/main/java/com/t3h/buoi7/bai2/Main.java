package com.t3h.buoi7.bai2;

/**
 C2:
 Class: Nguoi
     filed:
         Họ tên String
         tuoi int
         cmnd String
 Class: LoaiPhong
    filed:
        tenPhong String
        giaPhong float
 class: Phong
    filed:
        soNgayThue int
        danhSachNguoiThuePhong : Nguoi[]
        soLuongNguoiDangO : int
        loaiPhong : LoaiPhong
    method:
        getGiaPhong()
            switch case
            A => return 500
            B => return 300
            C => return 100
 Class: KhachSan
 filed:
     Phong[] danhSachCacPhong;
     int tongSoCacPhong
     int soLuongPhongDaDungHienTai


 */
public class Main {
}
