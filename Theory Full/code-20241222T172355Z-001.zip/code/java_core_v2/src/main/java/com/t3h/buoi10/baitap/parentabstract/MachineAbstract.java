package com.t3h.buoi10.baitap.parentabstract;

public abstract class MachineAbstract {
}
