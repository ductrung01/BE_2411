package com.t3h.buoi4.codeslide;

public class Demo3 {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        // Duyệt mảng và in ra các phần tử
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Phần tử thứ " + i + ": " + numbers[i]);
        }

    }
}
