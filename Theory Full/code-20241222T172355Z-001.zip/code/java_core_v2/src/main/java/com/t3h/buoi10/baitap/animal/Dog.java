package com.t3h.buoi10.baitap.animal;


import com.t3h.buoi10.baitap.parentabstract.AnimalAbstract;

public class Dog extends AnimalAbstract {
    @Override
    public void barkable() {

    }

    @Override
    public void runable() {

    }
}
