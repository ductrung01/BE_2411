package com.t3h.buoi10.demointerface;

public interface SupperI1 {

    void start();
}
