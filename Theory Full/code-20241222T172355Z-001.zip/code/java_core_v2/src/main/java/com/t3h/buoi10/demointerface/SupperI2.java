package com.t3h.buoi10.demointerface;

public interface SupperI2 {

    void start();
}
