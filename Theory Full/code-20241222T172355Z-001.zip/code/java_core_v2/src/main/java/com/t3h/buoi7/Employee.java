package com.t3h.buoi7;

public class Employee {
    private float salary;
    String address;

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }
}
