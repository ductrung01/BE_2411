package com.t3h.buoi2.codesilde.phan1;

public class ViDuBien {
    public static void main(String[] args) {
        // Khai báo biến kiểu số nguyên
        int soNguyen = 10; // int: kiểu dữ liệu, soNguyen: tên biến
        // Khai báo biến kiểu số thực
        double soThuc = 5.5;
        // Khai báo biến kiểu chuỗi
        String chuoi = "Xin chào, Java!";
        // Hiển thị giá trị của các biến
        System.out.println("Số nguyên: " + soNguyen);
        System.out.println("Số thực: " + soThuc);
        System.out.println("Chuỗi: " + chuoi);
        // Thay đổi giá trị của biến
        soNguyen = 20;
        soThuc = 7.5;
        chuoi = "Java là ngôn ngữ lập trình tuyệt vời!";
        // Hiển thị giá trị mới của các biến
        System.out.println("Số nguyên sau khi thay đổi: " + soNguyen);
        System.out.println("Số thực sau khi thay đổi: " + soThuc);
        System.out.println("Chuỗi sau khi thay đổi: " + chuoi);
    }
}
