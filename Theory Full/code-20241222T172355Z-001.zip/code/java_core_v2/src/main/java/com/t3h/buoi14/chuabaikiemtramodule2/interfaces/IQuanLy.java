package com.t3h.buoi14.chuabaikiemtramodule2.interfaces;

public interface IQuanLy {

    void themMoi();

    void chinhSua();

    void timKiem();

    void hienThiDuLieu();
}
