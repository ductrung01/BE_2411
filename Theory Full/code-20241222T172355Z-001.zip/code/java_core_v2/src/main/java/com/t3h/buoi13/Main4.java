package com.t3h.buoi13;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Main4 {

    public static void main(String[] args) {

        /**
         cung cấp các interface và cấu trúc để lưu trữ các loại dữ liệu
         */
        Collection collection = new ArrayList<>();

        /**
         Collections: cung cấp các giải thuật đung chung để thao tác với tập các dữ liệu
         */
//        Collections

    }
}
