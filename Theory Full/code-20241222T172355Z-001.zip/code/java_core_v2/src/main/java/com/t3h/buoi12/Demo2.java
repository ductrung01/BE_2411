package com.t3h.buoi12;

public class Demo2 {

    public static void main(String[] args) {
        // Tạo ra một mảng lưu trữ danh sách các số nguyên
        int[] arrInt = new int[10];

        // Tạo ra mảng thứ 2
        int[] arrInt2 = new int[20];
    }
}
