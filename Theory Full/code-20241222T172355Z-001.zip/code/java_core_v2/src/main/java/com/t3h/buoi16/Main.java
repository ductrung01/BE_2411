package com.t3h.buoi16;

public class Main {

    public static void main(String[] args) {


        Main main = new Main();

        Bank bank = new Bank();
        Bank bank2 = new Bank();
        Bank bank3 = new Bank();
        Bank bank4 = new Bank();
        Bank bank5 = new Bank();

    }
}
