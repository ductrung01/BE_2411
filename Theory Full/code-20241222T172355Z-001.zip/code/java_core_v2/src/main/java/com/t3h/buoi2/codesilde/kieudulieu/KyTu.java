package com.t3h.buoi2.codesilde.kieudulieu;

public class KyTu {
    public static void main(String[] args) {
        char ch = 'A';
        System.out.println("char: " + ch);
    }
}
