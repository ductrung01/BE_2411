package com.t3h.buoi16.proxy;

public interface Image {
    void showImage();
}
