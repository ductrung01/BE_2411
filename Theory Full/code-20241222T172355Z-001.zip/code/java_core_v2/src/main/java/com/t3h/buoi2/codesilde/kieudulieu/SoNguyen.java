package com.t3h.buoi2.codesilde.kieudulieu;

public class SoNguyen {
    public static void main(String[] args) {
        byte b = 10;
        short s = 300;
        int i = 1000;
        long l = 100000L;
        System.out.println("byte: " + b);
        System.out.println("short: " + s);
        System.out.println("int: " + i);
        System.out.println("long: " + l);
    }
}
