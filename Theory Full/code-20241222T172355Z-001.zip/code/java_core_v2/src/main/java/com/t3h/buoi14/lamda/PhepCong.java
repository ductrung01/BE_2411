package com.t3h.buoi14.lamda;
@FunctionalInterface
public interface PhepCong {

    public int tong(int a, int b);
}
