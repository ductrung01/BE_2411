package com.t3h.buoi16.observers.model;

import com.t3h.buoi16.observers.User;

public interface Observer {
    void update(User user);
}
