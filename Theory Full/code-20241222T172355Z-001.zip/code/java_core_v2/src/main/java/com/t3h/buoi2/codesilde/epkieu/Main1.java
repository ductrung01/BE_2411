package com.t3h.buoi2.codesilde.epkieu;

public class Main1 {
    public static void main(String[] args) {

        int soNguyen = 10;
        double soThuc = soNguyen; // Ép kiểu ngầm định từ int sang double

        double soThucTuongMinh = 10.5;
        int soNguyenTuongMinh = (int) soThucTuongMinh; // Ép kiểu tường minh từ double sang int


    }
}
