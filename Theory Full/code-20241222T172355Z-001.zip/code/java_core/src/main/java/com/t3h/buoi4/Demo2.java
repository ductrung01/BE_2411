package com.t3h.buoi4;

public class Demo2 {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        // Truy cập phần tử đầu tiên
        int firstElement = numbers[0]; // firstElement = 1
        // Truy cập phần tử thứ ba
        int thirdElement = numbers[2]; // thirdElement = 3

    }
}
