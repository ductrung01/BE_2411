package com.t3h.buoi3.demo;

/**
    B1: nhập vào n
        a) tính tổng các số từ 1 đến n
        b) tính tổng các số chẵn
        c) tìm các số nguyên tố từ 1 đến n


 */
public class WhileDemo {
    public static void main(String[] args) {
//        int n=0;
//        while (n <10){
//            System.out.println("Hello!");
//            n++;
//        }
//        int i=0;
//        do {
//            System.out.println("Hello");
//            i++;
//        }while (i < 10);

        for(int i=0;i<10;i++){
            System.out.println("Hello");
        }

    }
}
