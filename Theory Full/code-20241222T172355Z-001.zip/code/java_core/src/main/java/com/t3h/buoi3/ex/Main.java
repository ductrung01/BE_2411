package com.t3h.buoi3.ex;

/**



 Bai 1:
     Kiểm tra số âm, dương hay bằng không:
     Viết một chương trình Java để kiểm tra xem một số nhập từ bàn phím là số âm, số dương hay bằng không.
 Bai 2:
     Xác định số lớn nhất trong ba số:
     Viết một chương trình Java để xác định số lớn nhất trong ba số nhập từ bàn phím.
 Bai 3:
     Cho người dùng nhập vào 3 số thực.
     Kiêm tra 3 số đó có phải là 3 cạnh của 1 tam giác không
 Bai 4:
    Nhập vào một tháng trong năm. Hiển thị mùa cuâ tháng đó
     từ tháng 1,2,12 => mùa đông
     3 đến 5: mùa xuân
     6 đến 8 mùa hè
     9 đến 10 mùa thu
     sử dụng switch case
 Bai 5: nhập vào n
     a) tính tổng các số từ 1 đến n
     b) tính tổng các số chẵn
     c) tìm các số nguyên tố từ 1 đến n

 */
public class Main {
}
