package com.t3h.buoi4;

/**

 <kiểu dữ liệu>[] <tên mảng> = new <kiểu dữ liệu>[<kích thước mảng>];


 */
public class Main {
    public static void main(String[] args) {

        int[] numbers = new int[5]; // Mảng số nguyên có 5 phần tử
        String[] names = new String[10]; // Mảng chuỗi có 10 phần tử

        int[] numbersV2 = {1, 2, 3, 4, 5}; // Khai báo và khởi tạo mảng số nguyên
        String[] namesV2 = {"Alice", "Bob", "Charlie"}; // Khai báo và khởi tạo mảng chuỗi


    }
}
