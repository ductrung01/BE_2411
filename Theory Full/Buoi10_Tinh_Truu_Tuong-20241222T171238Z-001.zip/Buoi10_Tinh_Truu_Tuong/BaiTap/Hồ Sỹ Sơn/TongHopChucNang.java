package com.t3h.buoi10.baitap;

public interface TongHopChucNang {
    void barkable();
    void runable();
    void flyable();
    void swimable();
    void nhapThongTin();
    void hienThiThongTin();
}
