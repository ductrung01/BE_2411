package buoi9.baiTap.Bai1;

import java.util.Scanner;

public class Dog extends Animal {
    private String tailColor;

    public Dog(String id, String name, String furColor, String tailColor) {
        super(id, name, furColor);
        this.tailColor = tailColor;
    }

    @Override
    public void inputInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập ID: ");
        id = scanner.nextLine();
        System.out.print("Nhập tên: ");
        name = scanner.nextLine();
        System.out.print("Nhập màu lông: ");
        furColor = scanner.nextLine();
        System.out.print("Nhập màu đuôi: ");
        tailColor = scanner.nextLine();
    }

    @Override
    public void displayInfo() {
        System.out.println("Dog [ID: " + id + ", Tên: " + name + ", Màu lông: " + furColor + ", Màu đuôi: " + tailColor + "]");
    }
}
