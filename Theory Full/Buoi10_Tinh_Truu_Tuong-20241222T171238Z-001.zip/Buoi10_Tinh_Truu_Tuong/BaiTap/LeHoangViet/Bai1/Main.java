package buoi9.baiTap.Bai1;

import java.util.Scanner;

public class Main {
    private static final int MAX_ANIMALS = 100;
    private static final int MAX_MACHINES = 100;
    private static Animal[] animals = new Animal[MAX_ANIMALS];
    private static Machine[] machines = new Machine[MAX_MACHINES];
    private static int animalCount = 0;
    private static int machineCount = 0;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            showMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline
            switch (choice) {
                case 1:
                    addAnimal();
                    break;
                case 2:
                    editAnimal();
                    break;
                case 3:
                    searchAnimal();
                    break;
                case 4:
                    addMachine();
                    break;
                case 5:
                    editMachine();
                    break;
                case 6:
                    searchMachine();
                    break;
                case 7:
                    System.out.println("Thoát khỏi chương trình...");
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng thử lại.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("Menu:");
        System.out.println("1. Thêm Động Vật");
        System.out.println("2. Sửa Động Vật");
        System.out.println("3. Tìm Kiếm Động Vật");
        System.out.println("4. Thêm Máy Móc");
        System.out.println("5. Sửa Máy Móc");
        System.out.println("6. Tìm Kiếm Máy Móc");
        System.out.println("7. Thoát");
        System.out.print("Nhập lựa chọn của bạn: ");
    }

    private static void addAnimal() {
        if (animalCount >= MAX_ANIMALS) {
            System.out.println("Không thể thêm nhiều động vật hơn. Mảng đã đầy.");
            return;
        }

        System.out.println("Chọn loại động vật:");
        System.out.println("1. Dog");
        System.out.println("2. Bird");
        System.out.println("3. Fish");
        int choice = scanner.nextInt();
        scanner.nextLine();  // consume newline
        Animal animal = null;
        switch (choice) {
            case 1:
                animal = new Dog("", "", "", "");
                break;
            case 2:
                animal = new Bird("", "", "", "");
                break;
            case 3:
                animal = new Fish("", "", "", "");
                break;
            default:
                System.out.println("Lựa chọn không hợp lệ. Động vật không được thêm vào.");
                return;
        }
        animal.inputInfo();
        animals[animalCount++] = animal;
        System.out.println("Đã thêm động vật thành công.");
    }

    private static void editAnimal() {
        System.out.print("Nhập ID động vật để chỉnh sửa: ");
        String id = scanner.nextLine();
        for (int i = 0; i < animalCount; i++) {
            if (animals[i].getId().equals(id)) {
                animals[i].inputInfo();
                System.out.println("Thông tin động vật được cập nhật.");
                return;
            }
        }
        System.out.println("Động vật không được tìm thấy.");
    }

    private static void searchAnimal() {
        System.out.print("Nhập tên Động vật để tìm kiếm: ");
        String name = scanner.nextLine();
        for (int i = 0; i < animalCount; i++) {
            if (animals[i].getName().contains(name)) {
                animals[i].displayInfo();
            }
        }
    }

    private static void addMachine() {
        if (machineCount >= MAX_MACHINES) {
            System.out.println("Không thể thêm nhiều máy hơn. Mảng đã đầy.");
            return;
        }

        System.out.println("Chọn loại máy:");
        System.out.println("1. Car");
        System.out.println("2. Airplane");
        int choice = scanner.nextInt();
        scanner.nextLine();  // consume newline
        Machine machine = null;
        switch (choice) {
            case 1:
                machine = new Car("", "", "", "", "");
                break;
            case 2:
                machine = new Airplane("", "", "", "", "");
                break;
            default:
                System.out.println("Lựa chọn không hợp lệ. Máy chưa được thêm vào.");
                return;
        }
        machine.inputInfo();
        machines[machineCount++] = machine;
        System.out.println("Đã thêm máy thành công.");
    }

    private static void editMachine() {
        System.out.print("Nhập ID máy để chỉnh sửa: ");
        String id = scanner.nextLine();
        for (int i = 0; i < machineCount; i++) {
            if (machines[i].getId().equals(id)) {
                machines[i].inputInfo();
                System.out.println("Thông tin máy được cập nhật");
                return;
            }
        }
        System.out.println("Không tìm thấy máy.");
    }

    private static void searchMachine() {
        System.out.print("Nhập tên máy để tìm kiếm: ");
        String name = scanner.nextLine();
        for (int i = 0; i < machineCount; i++) {
            if (machines[i].getName().contains(name)) {
                machines[i].displayInfo();
            }
        }
    }
}
