package buoi9.baiTap.Bai1;

import java.util.Scanner;

public class Bird extends Animal {
    private String seedType;

    public Bird(String id, String name, String furColor, String seedType) {
        super(id, name, furColor);
        this.seedType = seedType;
    }

    @Override
    public void inputInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập ID: ");
        id = scanner.nextLine();
        System.out.print("Nhập tên: ");
        name = scanner.nextLine();
        System.out.print("Nhập màu lông: ");
        furColor = scanner.nextLine();
        System.out.print("Nhập loại hạt: ");
        seedType = scanner.nextLine();
    }

    @Override
    public void displayInfo() {
        System.out.println("Bird [ID: " + id + ", Tên: " + name + ", Màu lông: " + furColor + ", Loại hạt: " + seedType + "]");
    }
}
