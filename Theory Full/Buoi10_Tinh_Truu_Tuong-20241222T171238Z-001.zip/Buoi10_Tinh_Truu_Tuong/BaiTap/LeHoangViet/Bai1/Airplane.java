package buoi9.baiTap.Bai1;

import java.util.Scanner;

public class Airplane extends Machine {
    private String airport;

    public Airplane(String id, String productionDate, String brand, String name, String airport) {
        super(id, productionDate, brand, name);
        this.airport = airport;
    }

    @Override
    public void inputInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập ID: ");
        id = scanner.nextLine();
        System.out.print("Nhập ngày sản xuất: ");
        productionDate = scanner.nextLine();
        System.out.print("Nhập thương hiệu: ");
        brand = scanner.nextLine();
        System.out.print("Nhập tên: ");
        name = scanner.nextLine();
        System.out.print("Nhập sân bay: ");
        airport = scanner.nextLine();
    }

    @Override
    public void displayInfo() {
        System.out.println("Airplane [ID: " + id + ", Ngày sản xuất: " + productionDate + ",Thương hiệu: " + brand + ", Tên: " + name + ",Sân bay: " + airport + "]");
    }
}
