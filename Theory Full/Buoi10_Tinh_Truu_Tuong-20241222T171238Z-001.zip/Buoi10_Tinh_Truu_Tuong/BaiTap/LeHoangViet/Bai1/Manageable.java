package buoi9.baiTap.Bai1;

public interface Manageable {
    void inputInfo();
    void displayInfo();
}
