package buoi9.baiTap.Bai1;

public abstract class Animal implements Manageable {
    protected String id;
    protected String name;
    protected String furColor;

    public Animal(String id, String name, String furColor) {
        this.id = id;
        this.name = name;
        this.furColor = furColor;
    }

    public abstract void inputInfo();
    public abstract void displayInfo();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFurColor() {
        return furColor;
    }

    public void setFurColor(String furColor) {
        this.furColor = furColor;
    }
}
