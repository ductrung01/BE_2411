package buoi9.baiTap.Bai1;

public abstract class Machine implements Manageable {
    protected String id;
    protected String productionDate;
    protected String brand;
    protected String name;

    public Machine(String id, String productionDate, String brand, String name) {
        this.id = id;
        this.productionDate = productionDate;
        this.brand = brand;
        this.name = name;
    }

    public abstract void inputInfo();
    public abstract void displayInfo();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(String productionDate) {
        this.productionDate = productionDate;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
