package buoi9.baiTap.Bai1;

import java.util.Scanner;

public class Fish extends Animal {
    private String seaArea;

    public Fish(String id, String name, String furColor, String seaArea) {
        super(id, name, furColor);
        this.seaArea = seaArea;
    }

    @Override
    public void inputInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập ID: ");
        id = scanner.nextLine();
        System.out.print("Nhập tên: ");
        name = scanner.nextLine();
        System.out.print("Nhập màu: ");
        furColor = scanner.nextLine();
        System.out.print("Nhập vùng biển: ");
        seaArea = scanner.nextLine();
    }

    @Override
    public void displayInfo() {
        System.out.println("Fish [ID: " + id + ", tên: " + name + ", màu: " + furColor + ", vùng biển: " + seaArea + "]");
    }
}
