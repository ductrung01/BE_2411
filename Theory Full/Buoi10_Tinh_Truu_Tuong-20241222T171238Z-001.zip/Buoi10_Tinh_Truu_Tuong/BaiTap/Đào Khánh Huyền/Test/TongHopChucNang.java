package org.example.Test;

public interface TongHopChucNang {
    void barkable();
    void runnable();
    void flyable();
    void swimable();


}
