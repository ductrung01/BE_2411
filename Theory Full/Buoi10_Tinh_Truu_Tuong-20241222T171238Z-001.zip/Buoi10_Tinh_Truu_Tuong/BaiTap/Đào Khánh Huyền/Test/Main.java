package org.example.Test;

import org.example.Test.Manage.AnimalManage;
import org.example.Test.Manage.MachineManage;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        AnimalManage am = new AnimalManage();
        MachineManage mm = new MachineManage();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Quan ly dong vat");
            System.out.println("2. Quan ly may moc");
            System.out.println("3. Thoat");

            System.out.print("Chon mot chuc nang: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    am.manage();
                    break;
                case 2:
                    mm.manage();
                    break;
                case 3:
                    System.out.println("Thoat chuong trinh.");
                    return;
                default:
                    System.out.println("Lua chon khong hop le. Vui long chon lai.");
            }
        }
    }

    }


