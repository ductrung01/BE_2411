package org.example.Test.Manage;

import org.example.Test.Abstract.Machine;
import org.example.Test.Machine.MayBay;
import org.example.Test.Machine.Xe;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MachineManage {
    private List<Machine> machines = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void manage(){
        while (true) {
            System.out.println("Quan ly may moc:");
            System.out.println("1. Them may moc");
            System.out.println("2. Sua thong tin may moc theo ID");
            System.out.println("3. Tim kiem may moc theo ten");
            System.out.println("4. Hien thi danh sach may moc");
            System.out.println("5. Quay lai menu chinh");

            System.out.print("Chon mot chuc nang: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addMachine();
                    break;
                case 2:
                    System.out.print("Nhap thong tin id cua dong vat muon update");
                    int id = scanner.nextInt();
                    updateMachine(id);
                    break;
                case 3:
                    System.out.print("Nhap ten de tim kiem dong vat do: ");
                    String name = scanner.nextLine();
                    searchMachineByName(name);
                    break;
                case 4:
                    displayAllMachines();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Lua chon khong hop le. Vui long chon lai.");
            }
        }

    }

    private void addMachine() {

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Chon loai may ma ban muon them: ");
            System.out.println("1. Xe");
            System.out.println("2. May Bay");
            System.out.println("3. Quay lai menu chinh");

            int option = scanner.nextInt();
            scanner.nextLine();
            Machine machine = null;

            switch (option) {
                case 1:
                    machine = new Xe();
                    break;
                case 2:
                    machine = new MayBay();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid option");
                    continue;
            }

            machine.enterInfo();
            machine.input();
            machines.add(machine);
            System.out.println("Machine added successfully.");
        }
    }

    private void updateMachine(int machineId){
        for (Machine machine : machines) {
            if (machine.getId() == machineId){
                machine.enterInfo();
                machine.input();
                return;
            }
        }
        System.out.println("Invalid machine ID: " +machineId);
    }

    private void searchMachineByName(String name){
        if (name == null){
            throw new IllegalArgumentException("Name cannot be null");
        }
        for (Machine machine : machines) {
            if (machine.getTen().toLowerCase().contains(name.toLowerCase())){
                machine.output();
            }
        }
        System.out.println("Invalid machine name: " +name);
    }

    private void displayAllMachines(){
        machines.forEach(System.out::println);
    }
}
