package org.example.Test.Manage;

import org.example.Test.Abstract.Animal;
import org.example.Test.Animal.Ca;
import org.example.Test.Animal.Chim;
import org.example.Test.Animal.Dog;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AnimalManage {
    private List<Animal> animals = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void manage() {
        while (true) {
            System.out.println("Quan ly dong vat:");
            System.out.println("1. Them dong vat hem may moc");
            System.out.println("2. Sua thong tin dong vat theo ID");
            System.out.println("3. Tim kiem dong vat theo ten");
            System.out.println("4. Hien thi danh sach dong vat");
            System.out.println("5. Quay lai menu chinh");

            System.out.print("Chon mot chuc nang: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addAnimal();
                    break;
                case 2:
                    System.out.print("Nhap thong tin id cua dong vat muon update");
                    int id = scanner.nextInt();
                    updateAnimal(id);
                    break;
                case 3:
                    System.out.print("Nhap ten de tim kiem dong vat do: ");
                    String name = scanner.nextLine();
                    searchAnimalByName(name);
                    break;
                case 4:
                    displayAllAnimals();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Lua chon khong hop le. Vui long chon lai.");
            }
        }
    }


    private void addAnimal() {
            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("Chon dong vat ma ban muon them: ");
                System.out.println("1. Cho");
                System.out.println("2. Chim");
                System.out.println("3. Ca");
                System.out.println("4. Quay lai menu chinh");

                int option = scanner.nextInt();
                scanner.nextLine();
                Animal animal = null;

                switch (option) {
                    case 1:
                        animal = new Dog();
                        break;
                    case 2:
                        animal = new Chim();
                        break;
                    case 3:
                        animal = new Ca();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Invalid option");
                        continue;
                }

                animal.enterInfo();
                animal.input();
                animals.add(animal);
                System.out.println("Animal added successfully.");
            }

    }

    private void updateAnimal(int animalId){
        for (Animal animal : animals) {
            if (animal.getId() == animalId){
                animal.enterInfo();
                animal.input();
                return;
            }
        }
        System.out.println("Invalid animal ID: " +animalId);
    }

    private void searchAnimalByName(String name){
        if (name == null){
            throw new IllegalArgumentException("Name cannot be null");
        }
        for (Animal animal : animals) {
            if (animal.getTen().toLowerCase().contains(name.toLowerCase())){
                animal.output();
            }
        }
        System.out.println("Invalid animal name: " +name);
    }

    private void displayAllAnimals(){
        animals.forEach(System.out::println);
    }
}
