package org.example.Test.Manage;

import org.example.Test.Abstract.Animal;
import org.example.Test.Abstract.Machine;

import java.util.ArrayList;
import java.util.List;

public class CommonManagement {

//    private List<Animal> animals = new ArrayList<>();
//    private List<Machine> machines = new ArrayList<>();
//
//    //Animals
//
//    public void addAnimal(Animal animal) {
//        animals.add(animal);
//    }
//
//    public void updateAnimal(int animalId){
//        for (Animal animal : animals) {
//            if (animal.getId() == animalId){
//                animal.enterInfo();
//                animal.input();
//                return;
//            }
//        }
//        System.out.println("Invalid animal ID: " +animalId);
//    }
//
//    public void searchAnimalByName(String name){
//        if (name == null){
//            throw new IllegalArgumentException("Name cannot be null");
//        }
//        for (Animal animal : animals) {
//            if (animal.getTen().toLowerCase().contains(name.toLowerCase())){
//                animal.output();
//            }
//        }
//        System.out.println("Invalid animal name: " +name);
//    }
//
//    public void displayAllAnimals(){
//        animals.forEach(System.out::println);
//    }
//
//    //Machines
//
//    public void addMachine(Machine machine) {
//        machines.add(machine);
//    }
//
//    public void updateMachine(int machineId){
//        for (Machine machine : machines) {
//            if (machine.getId() == machineId){
//                machine.enterInfo();
//                machine.input();
//                return;
//            }
//        }
//        System.out.println("Invalid machine ID: " +machineId);
//    }
//
//    public void searchMachineByName(String name){
//        if (name == null){
//            throw new IllegalArgumentException("Name cannot be null");
//        }
//        for (Machine machine : machines) {
//            if (machine.getTen().toLowerCase().contains(name.toLowerCase())){
//                machine.output();
//            }
//        }
//        System.out.println("Invalid machine name: " +name);
//    }
//
//    public void displayAllMachines(){
//        machines.forEach(System.out::println);
//    }





}
