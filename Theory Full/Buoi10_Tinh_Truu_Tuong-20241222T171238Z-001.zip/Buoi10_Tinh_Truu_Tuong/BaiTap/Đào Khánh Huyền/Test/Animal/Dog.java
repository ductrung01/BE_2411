package org.example.Test.Animal;

import org.example.Test.Abstract.Animal;

import java.util.Scanner;

public class Dog extends Animal {
    private String mauDuoi;

    public Dog(int id, String ten, String mauLong, String mauDuoi) {
        super(id, ten, mauLong);
        this.mauDuoi = mauDuoi;
    }

    public Dog() {
        super();
    }

    @Override
    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhap mau duoi: ");
        mauDuoi = scanner.nextLine();


    }

    @Override
    public void output() {
        System.out.println("Dog co cac thong tin sau: id: " +id+ ", ten: " +ten + ", mau long: " +mauLong + ", mau duoi: " +mauDuoi);

    }

    @Override
    public void barkable() {
        System.out.println("Cho " +this.ten + " co the sua");

    }

    @Override
    public void runnable() {
        System.out.println("Cho " +this.ten + " co the chay");

    }

    @Override
    public void flyable() {
        System.out.println("Cho " +this.ten + " khong the bay");

    }

    @Override
    public void swimable() {
        System.out.println("Cho " +this.ten +" co the boi");
    }
}
