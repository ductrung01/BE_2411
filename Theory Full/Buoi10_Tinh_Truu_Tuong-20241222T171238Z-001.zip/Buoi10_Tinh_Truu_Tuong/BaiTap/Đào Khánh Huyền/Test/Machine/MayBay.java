package org.example.Test.Machine;

import org.example.Test.Abstract.Machine;

import java.util.Scanner;

public class MayBay extends Machine {
    private String sanBay;

    public MayBay(int id, long ngaySanXuat, String hang, String ten, String sanBay) {
        super(id, ngaySanXuat, hang, ten);
        this.sanBay = sanBay;
    }

    public MayBay(){
        super();
    }

    @Override
    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap san bay: ");
        sanBay = scanner.nextLine();

    }

    @Override
    public void output() {
        System.out.println("May bay co cac thong tin sau: id:  " +this.id + ", ngay san xuat: " +this.ngaySanXuat + ", hang san xuat: "+this.hang+
                ", ten may bay: "+this.ten+", san bay: "+this.sanBay);
    }

    @Override
    public void barkable() {
        System.out.println("May bay " +this.ten + " khong the sua");

    }

    @Override
    public void runnable() {
        System.out.println("May bay "+this.ten + " khong the chay");
    }

    @Override
    public void flyable() {
        System.out.println("May bay " +this.ten + " co the bay");
    }

    @Override
    public void swimable() {
        System.out.println("May bay " +this.ten +" khong the boi");

    }
}
