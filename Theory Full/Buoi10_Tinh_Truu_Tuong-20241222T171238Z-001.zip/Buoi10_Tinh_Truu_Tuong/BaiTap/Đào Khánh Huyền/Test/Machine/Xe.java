package org.example.Test.Machine;

import org.example.Test.Abstract.Machine;

import java.util.Scanner;

public class Xe extends Machine {
    private long ngayHetDangKiem;

    public Xe(int id, long ngaySanXuat, String hang, String ten, long ngayHetDangKiem) {
        super(id, ngaySanXuat, hang, ten);
        this.ngayHetDangKiem = ngayHetDangKiem;
    }

    public Xe(){
        super();
    }

    @Override
    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhap ngay het dang kiem: ");
        long ngayHetDangKiem = scanner.nextLong();

    }

    @Override
    public void output() {
        System.out.println("Xe co cac thong tin: id: "+id+ ", ngay san xuat: "+ngaySanXuat+ ", hang: " +hang+ ", ten: " +ten + ", ngay het dang kiem: " +ngayHetDangKiem);

    }

    @Override
    public void barkable() {
        System.out.println("Xe khong the sua");
    }

    @Override
    public void runnable() {
        System.out.println("Xe co the chay");
    }

    @Override
    public void flyable() {
        System.out.println("Xe khong the bay");
    }

    @Override
    public void swimable() {
        System.out.println("Xe khong the boi");
    }
}
