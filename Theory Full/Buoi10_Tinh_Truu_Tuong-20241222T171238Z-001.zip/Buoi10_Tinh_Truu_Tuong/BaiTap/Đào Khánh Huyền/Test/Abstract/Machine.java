package org.example.Test.Abstract;

import org.example.Test.TongHopChucNang;

import java.util.Scanner;

public abstract class Machine implements TongHopChucNang {
    protected int id;
    protected long ngaySanXuat;
    protected String hang;
    protected String ten;

    public Machine(int id, long ngaySanXuat, String hang, String ten) {

        this.id = id;
        this.ngaySanXuat = ngaySanXuat;
        this.hang = hang;
        this.ten = ten;
    }

    public Machine(){
        super();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getNgaySanXuat() {
        return ngaySanXuat;
    }

    public void setNgaySanXuat(long ngaySanXuat) {
        this.ngaySanXuat = ngaySanXuat;
    }

    public String getHang() {
        return hang;
    }

    public void setHang(String hang) {
        this.hang = hang;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public void enterInfo(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap id: ");
        id = scanner.nextInt();
        System.out.println("Nhap ngay san xuat: ");
        ngaySanXuat = scanner.nextLong();
        System.out.println("Nhap hang: ");
        hang = scanner.nextLine();
        System.out.println("Nhap ten: ");
        ten = scanner.nextLine();
    }

    public abstract void input();
    public abstract void output();
}
