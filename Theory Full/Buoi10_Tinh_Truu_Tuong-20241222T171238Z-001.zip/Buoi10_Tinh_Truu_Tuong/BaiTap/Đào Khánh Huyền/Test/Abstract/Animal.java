package org.example.Test.Abstract;

import org.example.Test.TongHopChucNang;

import java.util.Scanner;

public abstract class Animal implements TongHopChucNang {
    protected int id;
    protected String ten;
    protected String mauLong;

    public Animal(int id, String ten, String mauLong) {
        this.id = id;
        this.ten = ten;
        this.mauLong = mauLong;
    }

    public Animal() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getMauLong() {
        return mauLong;
    }

    public void setMauLong(String mauLong) {
        this.mauLong = mauLong;
    }

    public void enterInfo(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Animal ID: ");
        this.id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Animal Name: ");
        this.ten = scanner.nextLine();
        System.out.print("Enter Fur Color: ");
        this.mauLong = scanner.nextLine();
    }

    public abstract void input();
    public abstract void output();
}
