package Lesson14.Module2;

public interface Management {
    void chinhSua();
    void themMoi();
    void timKiem();
    void display();
}
