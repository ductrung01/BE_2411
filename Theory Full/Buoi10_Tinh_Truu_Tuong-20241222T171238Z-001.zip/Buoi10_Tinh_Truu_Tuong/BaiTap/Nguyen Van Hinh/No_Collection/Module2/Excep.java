package Lesson14.Module2;

public class Excep extends Exception {
    public Excep(){
        super("Lỗi mặc đinh");

    }
    public Excep(String msg){
        super(msg);
    }

}
