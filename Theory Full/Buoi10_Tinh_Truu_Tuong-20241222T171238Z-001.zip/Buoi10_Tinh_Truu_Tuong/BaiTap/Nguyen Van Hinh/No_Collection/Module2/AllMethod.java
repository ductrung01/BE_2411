package Lesson14.Module2;

public interface AllMethod {
    void barkable();
    void flyable();
    void runnable();
    void swimmable();

}
