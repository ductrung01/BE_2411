package Lesson14.Module2.Animal;

import java.util.Scanner;

public class Dog extends Animals {
    private String mauDuoi;

    @Override
    public void nhapThongTin(){
        super.nhapThongTin();
        System.out.println("Moi nhap mau duoi: ");
        Scanner sc = new Scanner(System.in);
        this.mauDuoi = sc.nextLine();
    }
    @Override
    public void hienThi(){
        super.hienThi();
        System.out.println("Mau duoi " + this.mauDuoi);

    }

    public String getMauDuoi() {
        return mauDuoi;
    }

    public void setMauDuoi(String mauDuoi) {
        this.mauDuoi = mauDuoi;
    }


}
