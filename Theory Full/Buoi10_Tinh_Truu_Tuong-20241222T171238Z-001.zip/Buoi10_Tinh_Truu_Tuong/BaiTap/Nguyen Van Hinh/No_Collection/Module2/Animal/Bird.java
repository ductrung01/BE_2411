package Lesson14.Module2.Animal;

import java.util.Scanner;

public class Bird extends Animals {
    private String loaiHat;

    @Override
    public void nhapThongTin(){
        super.nhapThongTin();
        System.out.println("Moi nhap loai hat: ");
        Scanner sc = new Scanner(System.in);
        this.loaiHat = sc.nextLine();
    }

    @Override
    public void hienThi(){
        super.hienThi();
        System.out.println("loai hat " + this.loaiHat);
    }
    @Override
    public void flyable(){
        System.out.println(super.getName()+ " fly ");
    }

    public String getLoaiHat() {
        return loaiHat;
    }

    public void setLoaiHat(String loaiHat) {
        this.loaiHat = loaiHat;
    }
}
