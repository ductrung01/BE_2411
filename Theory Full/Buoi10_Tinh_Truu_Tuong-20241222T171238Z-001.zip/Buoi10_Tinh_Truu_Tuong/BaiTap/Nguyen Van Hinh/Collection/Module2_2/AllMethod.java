package Module2_2;

public interface AllMethod{
    void barkable();
   void flyable();
   void runnable();
    void swimmable();
}
