package Module2_2;

import Lesson14.Ex;

public class CustomEx extends Exception {
    public CustomEx() {
        super("Loi mac dinh.");
    }
    public CustomEx(String message) {
        super(message);
    }
}
