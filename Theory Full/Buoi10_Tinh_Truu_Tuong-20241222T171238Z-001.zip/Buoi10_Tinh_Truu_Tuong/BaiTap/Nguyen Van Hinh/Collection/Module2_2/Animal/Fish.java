package Module2_2.Animal;


import java.util.Scanner;

public class Fish extends Animals {
    private String vungBien;

    @Override
    public void nhapThongTin(){
        super.nhapThongTin();
        System.out.println("Moi nhap vung bien: ");
        Scanner sc = new Scanner(System.in);
        this.vungBien = sc.nextLine();
    }

    @Override
    public void hienThi(){
        super.hienThi();
        System.out.println("Vung bien " + this.vungBien);
    }

    @Override
    public void swimmable(){
        System.out.println(super.getName() + "swimming");
    }

    public String getVungBien() {
        return vungBien;
    }

    public void setVungBien(String vungBien) {
        this.vungBien = vungBien;
    }


}
