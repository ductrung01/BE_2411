package Module2_2.Animal;

import java.util.Scanner;

public class Bird extends Animals {
    private String loaiHat;

    @Override
    public void nhapThongTin(){
        super.nhapThongTin();
        Scanner sc = new Scanner(System.in);
        System.out.println("Moi nhap loai hat:");
        this.loaiHat = sc.nextLine();
    }
    @Override
    public void hienThi(){
        System.out.println(this.toString());
    }
    @Override
    public void flyable(){
        System.out.println("Bay kép kép");
    }


    public String getLoaiHat() {
        return loaiHat;
    }

    public void setLoaiHat(String loaiHat) {
        this.loaiHat = loaiHat;
    }

    @Override
    public String toString() {
        return "Bird{" + "ten "+ getName()+ " id " + "mau Long "+ getMauLong() + getId() + " loaiHat " + loaiHat + '}';

    }
}
