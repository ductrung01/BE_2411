package Module2_2.Animal;


import Module2_2.AllMethod;

import java.util.Scanner;

public abstract class Animals implements AllMethod {
    private String name;
    private int id;
    private String mauLong;

    public void nhapThongTin(){
        System.out.println("Nhap Thong Tin");
        System.out.println("Name: ");
        Scanner sc = new Scanner(System.in);
        this.name = sc.nextLine();
        System.out.println("Mau long: ");
        this.mauLong = sc.nextLine();
    }
    public void hienThi(){
        System.out.println(this.toString());
    }



    @Override
    public void barkable() {

    }

    @Override
    public void flyable() {

    }

    @Override
    public void runnable() {

    }

    @Override
    public void swimmable() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMauLong() {
        return mauLong;
    }

    public void setMauLong(String mauLong) {
        this.mauLong = mauLong;
    }


    @Override
    public String toString() {
        return "Animals{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", mauLong='" + mauLong + '\'' +
                '}';
    }
}
