package Module2_2.Animal;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class QuanLi {
    private List<Animals> qldv = new LinkedList<>();
    public static Scanner sc = new Scanner(System.in);

    public void add(){
        System.out.println("Moi nhap loai dong vat muon them. ");
        System.out.println("1. Chim");
        System.out.println("2. Cho");
        System.out.println("3. Ca");
       Scanner sc = new Scanner(System.in);
       int luaChon = sc.nextInt();
       Animals an = null;

       switch (luaChon) {
           case 1:
             an = new Dog();
             break;
           case 2:
               an = new Bird();
               break;
           case 3:
               an = new Fish();
               break;
           default:
               System.out.println("invalid value.");
               break;


       }

        if (an == null){
            System.out.println("Lua chon khong hop le ");
            return;

        }
        System.out.println("Moi nhap vao thong tin.");
       try{
           int id = sc.nextInt();
           if (trungId(id)){
               System.out.println("Dong vat nay da ton tai trong danh sach.");
           }
           else{
               an.setId(id);
               an.nhapThongTin();
               System.out.println("thong tin dong vat la:");
               an.hienThi();
               qldv.add(an);
           }

       }catch(Exception e){
           System.out.println(e);
       }
    }
    public boolean trungId(int id){

        for(Animals a : qldv){
            if(a.getId()==id){
                return true;
            }
        }
        return false;

    }
    public void suaTheoId(){
        System.out.println("Moi nhap vao thong tin can chinh sua: ");
        try{
            int id = sc.nextInt();
            Animals dvdangtim = null;
            for (Animals a : qldv) {
                if (a.getId()==id){
                    dvdangtim = a;
                    break;
                }
            }
            if (dvdangtim == null){
                System.out.println("Dong vat khong ton tai trong danh sach");
                return;
            }
            System.out.println("Thong tin dong vat la: ");
            dvdangtim.hienThi();
            System.out.println("Moi nhap vao thong tin can chinh sua: ");
            dvdangtim.nhapThongTin();
            System.out.println("Thong tin dong vat sau khi chinh sua la: ");
            dvdangtim.hienThi();
            return;
        }catch(Exception e){
            System.out.println(e);
        }
    }

    public void timKiem(){
        System.out.println("Moi nhap vao ten dong vat muon tim kiem: ");
        try{
            String name = sc.nextLine();
            Animals an = null;
            for (Animals a : qldv) {
                if (a.getName().equals(name)){
                    an = a;
                    break;
                }
            }
            if (an == null){
                System.out.println("Khoong tim thay dong vat voi ten la: " + name);
                return;
            }
            else{
                System.out.println("Thong tin dong vat la: ");
                an.hienThi();
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public void display(){
        System.out.println("Danh sach dong vat la: ");
        for(int i = 0; i<qldv.size(); i++){
            System.out.println(i+1);
            Animals an = qldv.get(i);
            an.hienThi();
        }
    }

}
