package Module2_2;

import Lesson14.Module2.Animal.QuanLi;
import Module2.CustomEx;
import Module2_2.Machine.QuanLi2;
import lesson10.ex02.Qldv.QuanLi1;

import java.util.Scanner;

public class Main {
    private static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        QuanLi qla  = new QuanLi();
        QuanLi2 qlmm = new QuanLi2();
        String exit = " no";
        while (!exit.equalsIgnoreCase("yes")) {
            System.out.println("Enter an option: ");
            System.out.println("1. Them dong vat");
            System.out.println("2. Sua thong ten dong vat theo id");
            System.out.println("3. Tim  dong vat theo ten");
            System.out.println("4. Them may");
            System.out.println("5. Sua may theo id");
            System.out.println("6. Tim may theo ten");


            try{
                int option = sc.nextInt();
              nhap(option, qla, qlmm);
                }catch(Exception e){
                System.out.println("Invalid option");
            }
            System.out.println("Ban muon thoat chuong trinh?");
            System.out.println("Nhap yes/no");
            sc.nextLine();
            exit = sc.nextLine();
            }



        }
    public static void nhap(int choice, QuanLi qla, QuanLi2 qlmm) throws CustomEx{

switch (choice){
    case 1:
        qla.themMoi();
        break;
    case 2:
        qla.chinhSua();
        break;
    case 3:
        qla.timKiem();
        break;
    case 4:
        qlmm.them();
        break;
    case 5:
        qlmm.suaTheoId();
        break;
    case 6:
        qlmm.timTheoTen();
        break;
    case 7:
        qla.display();
        break;
    case 8:
        qlmm.hienThi();
        break;


    default:
        throw new CustomEx("Just input from 1 -> 6");
    }
    }
}
