package Module2_2.Machine;

import Module2_2.AllMethod;

import java.util.Scanner;

public abstract class Machine implements AllMethod {
    private int id;
    private String name;
    private String hang;
    private String ngaySanXuat;

    public void nhapThongTin(){
        System.out.println("Moi nhap vao ten: ");
        Scanner sc = new Scanner(System.in);
        this.name = sc.nextLine();
        System.out.println("Moi nhap vao hang: ");
        this.hang = sc.nextLine();
        System.out.println("Moi nhap vao ngay san xuat: ");
        this.ngaySanXuat = sc.nextLine();
    }

    public void hienThi(){
        System.out.println(this.toString());
    }


    @Override
    public void barkable() {

    }

    @Override
    public void flyable() {

    }

    @Override
    public void runnable() {

    }

    @Override
    public void swimmable() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNgaySanXuat() {
        return ngaySanXuat;
    }

    public void setNgaySanXuat(String ngaySanXuat) {
        this.ngaySanXuat = ngaySanXuat;
    }

    public String getHang() {
        return hang;
    }

    public void setHang(String hang) {
        this.hang = hang;
    }

    @Override
    public String toString() {
        return "Machine{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", hang='" + hang + '\'' +
                ", ngaySanXuat='" + ngaySanXuat + '\'' +
                '}';
    }
}
