package Module2_2.Machine;

import java.util.Scanner;

public class Car extends Machine {
    private String ngayHetHan;

    @Override
    public void nhapThongTin(){
        super.nhapThongTin();
        System.out.println("Moi nhap vao ngay het dang kiem: ");
        Scanner sc = new Scanner(System.in);
        this.ngayHetHan = sc.nextLine();

    }
    @Override
    public void hienThi(){
        super.hienThi();
        System.out.println("Ngay het dang kiem: " + this.ngayHetHan);
    }

    @Override
    public void runnable() {
        System.out.println(super.getName()+ " is running.");
    }

    public String getNgayHetHan() {
        return ngayHetHan;
    }

    public void setNgayHetHan(String ngayHetHan) {
        this.ngayHetHan = ngayHetHan;
    }

}
