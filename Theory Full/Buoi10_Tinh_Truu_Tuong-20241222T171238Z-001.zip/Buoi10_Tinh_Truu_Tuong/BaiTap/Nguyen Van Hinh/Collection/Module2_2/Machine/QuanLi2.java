package Module2_2.Machine;

import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class QuanLi2 {
    private static Scanner sc = new Scanner(System.in);
    private List<Machine> qlmm = new LinkedList<Machine>();

    public void them(){
        System.out.println("Moi chon loai may muon them: ");
        System.out.println("1. Car ");
        System.out.println("2. Plane ");

        Machine mc = null;
        int choice = sc.nextInt();
        switch(choice){
            case 1:
                mc = new Car();
                break;
            case 2:
                mc = new Plane();
                break;
            default:
                System.out.println("Invalid choice. Try again.");
                break;

        }
        if (mc == null) {
            System.out.println("Lua chon khong hop le vui long nhap lai.");
            return;
        }
        else{
            System.out.println("Moi nhap vao id");
            try {
                int id = sc.nextInt();
                if (trungId(id)){
                    System.out.println("May moc da ton tai vui long chon id khac");
                    return;
                }else{
                    mc.setId(id);
                    mc.nhapThongTin();
                    System.out.println("Thong tin may la: ");
                    mc.hienThi();
                    qlmm.add(mc);

                }
            }catch(InputMismatchException ime){
                System.out.println(ime);
            }
        }


    }
    public boolean trungId(int id){
        for (Machine mc : qlmm){
     if (mc.getId() == id) {
         return true;
     }
        }
        return false;

    }
    public void hienThi(){

    }
    public void suaTheoId(){
      try{
          System.out.println("Moi nhap vao id may can sua: ");
          int id = sc.nextInt();
          Machine mc= null;
          for (Machine m  : qlmm){
              if(m.getId() == id){
                  mc= m;
                  break;
              }
          }
          if (mc == null){
              System.out.println("Khong tim thay may.");
              return;
          }
              System.out.println("thong tin dong vat muon chinh sua la: ");
              mc.hienThi();
              System.out.println("Moi nhap thong tin muon sua: ");
              mc.nhapThongTin();
              System.out.println("Thong tin dong vat sau khi sua la: ");
              mc.hienThi();
              return;

      }catch(Exception e){
          System.out.println(e);
      }



    }
    public void timTheoTen(){
        try{
            String name = sc.nextLine();
            Machine mc = null;
            for (Machine m : qlmm){
                if (m.getName().equalsIgnoreCase(name)){
                    mc = m;
                    break;
                }
            }
            if (mc == null){
                System.out.println("Khong ton tai dong vat trong danh sach");
                return;
            }else{
                System.out.println("Thong tin dong vat la: ");
                mc.hienThi();
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
}
