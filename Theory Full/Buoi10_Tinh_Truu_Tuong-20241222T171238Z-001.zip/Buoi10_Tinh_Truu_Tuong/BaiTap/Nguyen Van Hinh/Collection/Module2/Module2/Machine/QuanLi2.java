package Lesson14.Module2.Machine;

import Lesson14.Module2.Management;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class QuanLi2 implements Management {
    private List<Machine> danhSachMay = new LinkedList<>();

    @Override
    public void chinhSua() {
        System.out.println("Mòi nhập vào id máy bạn muốn chỉnh sửa: ");
        int id = kieuNumber();
        System.out.println("Loại máy đang cần chỉnh sửa là: " + id);
        Machine mc = null;
        for(Machine m : danhSachMay) {
            if(m.getId() == id) {
                mc = m;
                break;
            }
        }
        if(mc == null){
            System.out.println("Không tìm thấy loại máy trong danh sách");
            return;
        }
        System.out.println("Thông tin của máy là: ");
        mc.hienThi();
        System.out.println("Mời nhập thông tin cần chỉnh sửa: ");
        mc.nhapThongTin();
        System.out.println("Thông tin của máy sau chỉnh sửa là: ");
        mc.hienThi();
    }

    @Override
    public void themMoi() {
        System.out.println("Chọn loại máy móc muốn thêm: ");
        System.out.println("1.Car ");
        System.out.println("2. Plane");
        Scanner sc = new Scanner(System.in);
        int choice  = sc.nextInt();
        Machine mc = null;
        switch(choice){
            case 1:
                mc = new Car();
                break;
            case 2:
                mc = new Plane();
                break;
            default:
                System.out.println("Invalid value; please try again. ");

        }
        if(mc == null){
            System.out.println("Loại máy không tồn tại vui lòng chọn lại");
            return;
        }
        System.out.println("Mời nhập vào id: ");
        int id = kieuNumber();
        if(this.idInvalid(id)){
            System.out.println("id đã bị trùng vui lòng nhập id khác. ");

        }
        mc.setId(id);
        mc.nhapThongTin();
        System.out.println("Thông tind dộngd vật vừa nhập là: ");
        mc.hienThi();
        danhSachMay.add(mc);
    }

    @Override
    public void timKiem() {
        System.out.println("Mời nhập vào tên cần tìm kiếm: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        System.out.println("Đang tim kiếm " + name );
        Machine mc = null;
        for(Machine m : danhSachMay) {
            if(m.getName().equals(name)){
                mc = m;
            }
        }
        if(mc == null){
            System.out.println("Không tìm thấy máy này trong danh sách vui lòng nhập máy khác");
            return;
        }
        System.out.println("Thông tin của máy là: ");
        mc.hienThi();
    }

    @Override
    public void display() {
        System.out.println("Thông tin máy móc trong danh sách là: ");
        for(Machine m : danhSachMay) {
            m.hienThi();
        }
    }

    public boolean idInvalid(int id) {
        for (Machine m : danhSachMay) {
            if (m.getId() == id) {
                return true;
            }
        }
        return false;

    }

    public int kieuNumber(){
        int id = 0;
        boolean invalid = true;
        do{
            try{
                Scanner sc = new Scanner(System.in);
                id = sc.nextInt();
                invalid = false;
            }catch(Exception e){
                System.out.println("Invalid value; please try again.");
            }
        }while(invalid);

        return id;
    }
}
