package Lesson14.Module2.Animal;

import Lesson14.Module2.Animal.Animals;
import Lesson14.Module2.Animal.Bird;
import Lesson14.Module2.Animal.Dog;
import Lesson14.Module2.Animal.Fish;
import Lesson14.Module2.Management;
import lesson10.ex02.Qldv.Animal;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public  class QuanLi implements Management {
    private List<Animals> danhSachDv = new ArrayList<>();


    @Override
    public void chinhSua() {
        System.out.println("Mòi nhạp vaopf id động vật cần chỉnh sửa: ");
        int id = giaTriSo();
        Animals dvDangTim = null;
        for(Animals dv : danhSachDv) {
            if(dv.getId() == id) {
                dvDangTim = dv;
                break;
            }
        }

        if(dvDangTim == null) {
            System.out.println("không timf thấy động vật với id là : " + id);
            return;

        }

        System.out.println("Thông tin động vật cần tìm là: ");
        dvDangTim.hienThi();
        System.out.println("Mòi nhâpj vaod thông tin cần chinhr sửa: ");
        dvDangTim.nhapThongTin();
        System.out.println();
        System.out.println("Thông tin động vật sau khi chỉnh sưat là: ");
        dvDangTim.hienThi();
    }


    @Override
    public void themMoi() {
        System.out.println("Moi nhap loai dong vat muon them. ");
        System.out.println("1. Chim");
        System.out.println("2. Cho");
        System.out.println("3. Ca");
        Scanner sc = new Scanner(System.in);
        int luaChon = sc.nextInt();
        Animals an = null;
        switch (luaChon) {
            case 1:
                an = new Bird();
                break;
            case 2:
                an = new Dog();
                break;
            case 3:
                an = new Fish();
                break;
            default:
                System.out.println("Invalid value");
                break;

        }
        if( an == null){
            System.out.println("Lua chon khong dung dang");
            return;
        }
        System.out.println("Moi nhap vao id : ");
        int id = giaTriSo();
        if(this.idInvalid(id)){
            System.out.println("Id đã tồn tại trong danh sách.");
            return;
        }
        an.setId(id);
        an.nhapThongTin();
        System.out.println("Thông tin của động vật vừa nhập là: ");

        an.hienThi();
        danhSachDv.add(an);
    }

    @Override
    public void timKiem() {
        System.out.println("Mời nhập vào tên động vật muốn tìm kiếm: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        Animals an = null;
        for(int i = 0; i< danhSachDv.size(); i++){
            if(danhSachDv.get(i).getName().equals(name)){
                an = danhSachDv.get(i);
                break;
            }

        }
        if(an == null){
            System.out.println("Không tìm thấy đôgngj vật " + name + " trong danh sách");
            return;
        }
        System.out.println("Thông tin động vật là: ");
        an.hienThi();
    }

    @Override
    public void display() {
        System.out.println("Thong tin danh sach dong vat la: ");
        for (int i = 0; i< danhSachDv.size(); i++){
            System.out.println((i+1) + "  ");
            Animals an = danhSachDv.get(i);
            an.hienThi();
        }
    }

    boolean idInvalid(int id){
        for(Animals a : danhSachDv){
            if(a.getId() ==id ){
                return true;
            }
        }
        return false;
    }

    public int giaTriSo(){
        boolean invalidValue = true;
        int giatri = 0;
        do{
            try{
                Scanner sc = new Scanner(System.in);
                giatri = sc.nextInt();
                invalidValue = false;
            }catch(Exception e){
                System.out.println("Invalid input, please try again");
            }


        }while(invalidValue);
        return giatri;
    }
}
