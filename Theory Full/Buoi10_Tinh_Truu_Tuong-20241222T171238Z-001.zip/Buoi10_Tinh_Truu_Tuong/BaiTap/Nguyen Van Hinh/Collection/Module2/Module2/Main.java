package Lesson14.Module2;

import Lesson14.Module2.Animal.QuanLi;
import Lesson14.Module2.Machine.QuanLi2;

import java.util.Scanner;

public class Main {

    public static final int QLDV = 1;
    public static final int QLMM = 2;
    public static final int ThOAT = -1;

    public static final int THEM = 1;
    public static final int SUA = 2;
    public static final int TIM = 3;
    public static final int DISPLAY = 4;
    public static final int AGAIN = 5;

    public static Management qldv = null;
    public static Management qlmm = null;


    public static Scanner sc = new Scanner(System.in);


    public static void main(String[] args) {

        boolean tiepTuc = true;
        while (tiepTuc) {
            tiepTuc = thucThiQuanLi();
        }

    }

    public static boolean thucThiQuanLi() {
        Management quanLi = null;

        int chucNangQuanLi = nhapThongTinLoaiQuanLi();
        if (chucNangQuanLi == QLDV) {
            if (qldv != null) {
                quanLi = qldv;
            } else {
                quanLi = new QuanLi();
            }
        }
        else if (chucNangQuanLi == QLMM) {
            if (qlmm != null) {
                quanLi = qlmm;
            } else {
                quanLi = new QuanLi2();
            }
        } else {
            return false;
        }

        boolean chonLai = thucThiChucNang(chucNangQuanLi, quanLi);
        if (chucNangQuanLi == QLDV) {
            qldv = quanLi;
        }
        else if (chucNangQuanLi == QLMM) {
            qlmm = quanLi;
        }
        return chonLai;


    }

    public static boolean thucThiChucNang(int chucNang, Management quanLi) {
        boolean tiepTucChon = true;
        do {
            int chucNangChiTiet = getLoaiChucNang(chucNang);
            switch (chucNangChiTiet) {
                case THEM:
                    quanLi.themMoi();
                    break;
                case SUA:
                    quanLi.chinhSua();
                    break;
                case TIM:
                    quanLi.timKiem();
                    break;
                case DISPLAY:
                    quanLi.display();
                    break;
                case AGAIN:
                    return true;
                case ThOAT:
                    System.exit(0);

            }
        } while (tiepTucChon);
        return false;

    }


    public static int getLoaiChucNang(int chucNang) {
        int chucNangChiTiet = 0;
        switch (chucNang) {
            case QLDV:
                System.out.println("Quản lí động vật; chọn các chức năng để quản lí; ");
                chucNangChiTiet = nhapThongTinLoaiChucNang();
                break;
            case QLMM:
                System.out.println("Quản lí máy moc; mời chọn loại chức năng; ");
                chucNangChiTiet = nhapThongTinLoaiChucNang();
                break;
            default:
                System.out.println("Bạn đã thoát chương trình");
                chucNangChiTiet = ThOAT;
                break;

        }

        return chucNangChiTiet;

    }

    public static int nhapThongTinLoaiQuanLi() {
        int loaiQuanLi = 0;
        boolean data = true;
        do {
            try {
                System.out.println("Mời chọn loại quản lí: ");
                System.out.println("1. Quản lí đông vật");
                System.out.println("2. Quản lí máy móc");
                System.out.println("-1: thoát chương trình");

                loaiQuanLi = sc.nextInt();
                sc.nextLine();
                if (loaiQuanLi >= 1 && loaiQuanLi <= 2 || loaiQuanLi == -1) {
                    data = false;
                } else {
                    System.out.println("Loại quản lí không hợp lệ vui lòng nhập lại.");
                }
            } catch (Exception e) {
                System.out.println("Loại quản lí không hợp lệ ");
                break;
            }

        } while (data);
        return loaiQuanLi;
    }

    public static int nhapThongTinLoaiChucNang() {
        int chucnang = 0;
        boolean data = true;
        do {
            try {
                System.out.println("1.Thêm mới");
                System.out.println("2. Chỉnh sửa theo id");
                System.out.println("3. Tìm kiếm theo tên");
                System.out.println("4. Hiển thị danh sách.");
                System.out.println("5. Quay lại chọn chức năng quản lí");
                System.out.println("-1 Thoát chương trình");

                chucnang = sc.nextInt();
                sc.nextLine();

                sc.nextLine();
                if (chucnang >= 1 && chucnang <= 5) {
                    data = false;
                } else {
                    System.out.println("Dữ liệu nhập không nằm trong danh sách vui lòng nhập lại.");

                }
            } catch (Exception e) {
                System.out.println("Invalid value");
                sc.nextLine();
            }

        } while (data);
        return chucnang;
    }
}
