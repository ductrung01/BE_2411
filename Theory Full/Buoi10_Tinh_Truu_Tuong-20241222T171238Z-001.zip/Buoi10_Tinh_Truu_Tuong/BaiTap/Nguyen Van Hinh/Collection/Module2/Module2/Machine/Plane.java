package Lesson14.Module2.Machine;

import java.util.Scanner;

public class Plane extends Machine {
    private String sanBay;

    @Override
    public void nhapThongTin(){
        super.nhapThongTin();
        System.out.println("Moi nhap vao ten san bay");
        Scanner sc = new Scanner(System.in);
        this.sanBay = sc.nextLine();

    }
    public void hienThi(){
        super.hienThi();
        System.out.println("San bay " + this.sanBay);
    }
    @Override
    public void flyable(){
        System.out.println(super.getName() + "is flying");

    }

    public String getSanBay() {
        return sanBay;
    }

    public void setSanBay(String sanBay) {
        this.sanBay = sanBay;
    }


}
