package com.javaweb.kiemtramodule;

public interface TongHopThuocTinh {
    void barkAble();
    void runAble();
    void flyAble();
    void swimAble();
}
