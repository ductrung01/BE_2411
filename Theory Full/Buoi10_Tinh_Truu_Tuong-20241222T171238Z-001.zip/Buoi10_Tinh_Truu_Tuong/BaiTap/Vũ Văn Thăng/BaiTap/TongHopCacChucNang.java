package Buoi10.BaiTap;

public interface TongHopCacChucNang {
    void bark();
    void run();
    void fly();
    void swim();
}
