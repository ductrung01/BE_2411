package Buoi10.BaiTap;

public class InvalidInputException extends Exception{
    public InvalidInputException(String message){
        super(message);
    }
}
