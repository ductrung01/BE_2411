package buoi3;

import java.util.Scanner;
public class BaiTap {

//Bài 1:
public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
//    System.out.print("Nhập số cần kiểm tra: ");
//    int so = sc.nextInt();
//
//    if (so > 0) {
//        System.out.println(so + " là số dương");
//    } else if (so < 0) {
//        System.out.println(so + " là số âm");
//    } else {
//        System.out.println(so + " là số 0");
//    }

//Bài 2:
//    System.out.print("Nhập vào số thứ 1: ");
//    int a = sc.nextInt();
//    System.out.print("Nhập vào số thứ 2: ");
//    int b = sc.nextInt();
//    System.out.print("Nhập vào số thứ 3: ");
//    int c = sc.nextInt();
//
//    int max = a;
//    if ( b > max ){
//        max = b;
//    }
//    if ( c > max ){
//        max = c;
//    }
//    System.out.print("Số lớn nhất là : " + max);

//Bài 3:
//    System.out.print("Nhập vào số thực thứ 1: ");
//    float a = sc.nextFloat();
//    System.out.print("Nhập vào số thực thứ 2: ");
//    float b = sc.nextFloat();
//    System.out.print("Nhập vào số thực thứ 3: ");
//    float c = sc.nextFloat();
//
//    if (a+b>c && a+c>b && b+c>a){
//        System.out.print(a + "," + b +","+ c +"là cạnh của tam giác ");
//    }   else {
//        System.out.print(a + "," + b +","+ c +" không là cạnh của tam giác ");
//    }

//Bài 4:
//    System.out.println("Nhập vào số tháng :");
//    int soThang = sc.nextInt();
//
//    switch (soThang) {
//        case 12:
//        case 1:
//        case 2:
//            System.out.println("Mùa đông");
//            break;
//        case 3:
//        case 4:
//        case 5:
//            System.out.println("Mùa xuân");
//            break;
//        case 6:
//        case 7:
//        case 8:
//            System.out.println("Mùa hè");
//            break;
//        case 9:
//        case 10:
//        case 11:
//            System.out.println("Mùa thu");
//            break;
//        default:
//            System.out.println("Tháng không hợp lệ");
//    }

//Bài 5:
    System.out.println("Nhập vào số n :");
    int n = sc.nextInt();
    for (int i = 1; i <= n; i++) {
        System.out.print(i + " ");
    }
    // Tính tổng các số từ 1 đến n
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i;
}
    System.out.println("Tổng các số từ 1 đến n: " +sum);
//Tính tổng các số chẵn
    int tongSoChan = 0;
    for (int i = 2; i <= n; i += 2) {
        tongSoChan += i;
    }
    System.out.println("Tổng các số chẵn: " + tongSoChan);
//Tìm các số nguyên tố:
    System.out.println("Các số nguyên tố từ 1 đến n là: ");
    for (int i = 2; i <= n; i++) {
        boolean SoNguyenTo = true;
        for (int j = 2; j <= Math.sqrt(i); j++) {
            if (i % j == 0) {
                SoNguyenTo = false;
                break;
            }
        }
        if (SoNguyenTo) {
            System.out.print(i + " ");
        }
    }

}
}
