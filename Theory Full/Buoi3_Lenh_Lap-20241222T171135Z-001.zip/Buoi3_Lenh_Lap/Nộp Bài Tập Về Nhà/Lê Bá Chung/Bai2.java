package com.javaweb;

import java.util.Scanner;

public class Bai2 {
    public static void main(String[] args) {
        System.out.printf("Nhập Số Thứ Nhất:");
        Scanner sc = new Scanner(System.in);
        int number1 = sc.nextInt();
        System.out.printf("Nhập Số Thứ Hai:");
        int number2 = sc.nextInt();
        System.out.printf("Nhập Số Thứ Ba:");
        int number3 = sc.nextInt();
        System.out.printf("Số Lớn Nhất Trong 3 Số Là: " + numberMax(number1,number2,number3));
    }
    public static int numberMax(int _number1,int _number2, int _number3) {
        int max ;
        max =_number1;
        if(max < _number2)
            max = _number2;
        if (max < _number3)
            max = _number3;
        return max;
    }
}
