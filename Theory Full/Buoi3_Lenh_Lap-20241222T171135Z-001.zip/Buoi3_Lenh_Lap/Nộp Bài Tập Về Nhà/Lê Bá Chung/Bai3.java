package com.javaweb;

import java.util.Scanner;

public class Bai3 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.printf("Nhập Số Thực Thứ Nhất: ");
        float number1 = scanner.nextFloat();
        while (number1 <= 0){
            System.out.printf("Cạnh Tam Giác Phải Lớn Hơn 0, Vui Lòng Nhập Lại:");
            number1 = scanner.nextFloat();
        }
        System.out.printf("Nhập Số Thực Thứ Hai: ");
        float number2 = scanner.nextFloat();
        while (number2 <= 0){
            System.out.printf("Cạnh Tam Giác Phải Lớn Hơn 0, Vui Lòng Nhập Lại:");
            number2 = scanner.nextFloat();
        }
        System.out.printf("Nhập Số Thực Thứ Ba: ");
        float number3 = scanner.nextFloat();
        while (number3 <= 0){
            System.out.printf("Cạnh Tam Giác Phải Lớn Hơn 0, Vui Lòng Nhập Lại:");
            number3 = scanner.nextFloat();
        }
        if(checkTriangle(number1,number2,number3) && checkTriangle(number1,number3,number2)
        && checkTriangle(number2,number3,number1)){
            System.out.printf("Đây Là 3 Cạnh Của Hình Tam Giác");
        }else {
            System.out.printf("Đây Không Phải Là 3 Cạnh Của Hình Tam Giác");
        }
    }
    public static boolean checkTriangle(float _number1, float _number2 ,float _number3){
        if(_number1 + _number2 > _number3){
            return true;
        }
        return false;
    }
}
