package com.javaweb;

import java.util.Scanner;

public class Bai4 {
    public static void main(String[] args){
        System.out.printf("Nhập 1 Tháng Không Được Lớn Hơn 12:");
        Scanner scanner= new Scanner(System.in);
        int month = scanner.nextInt();
        while (month > 12 || month < 1){
            System.out.printf("Tháng Không Phù Hợp ,Vui Lòng Nhập Lại Tháng :");
            month = scanner.nextInt();
        }
        switch (month){
            case 12:
            case 1:
            case 2:
                System.out.printf("Đây Là Mùa Đông");
                break;
            case 3:
            case 4:
            case 5:
                System.out.printf("Đây Là Mùa Xuân");
                break;
            case 6:
            case 7:
            case 8:
                System.out.printf("Đây Là Mùa Hè");
                break;
            case 9:
            case 10:
            case 11:
                System.out.printf("Đây Là Mùa Thu");
                break;
        }
    }
}
