package com.javaweb;

import java.util.Scanner;

public class Bai5 {
    public static void main(String[] args){
        System.out.printf("Nhập Số n:");
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int sum = 0;
        for (int i = 0 ; i <= n; i++){
            sum += i;
        }
        System.out.printf("Tổng Các Số Bằng: "+ sum);
        int sumEven = 0;
        for (int i = 0 ; i <= n; i++){
            if(i % 2 ==0){
                sumEven += i;
            }
        }
        System.out.printf("%nTổng Các Số Chẵn Bằng: " + sumEven);
        int sumPrime =0;
        for (int i = 0 ; i <= n ; i++){
            if(checkSoNguyenTo(i)){
                sumPrime += i;
                System.out.printf("%nSố Nguyên Tố Là : "+i);
            }
        }
        System.out.printf("%nTổng Các Số Nguyên Tố Bằng: " + sumPrime);
    }
    public static boolean checkSoNguyenTo(int _prime){
        if(_prime < 2){
             return false;
        }
        for (int i = 2; i < _prime; i++){
            if(_prime % i == 0){
                return false;
            }
        }
        return true;
    }
}
