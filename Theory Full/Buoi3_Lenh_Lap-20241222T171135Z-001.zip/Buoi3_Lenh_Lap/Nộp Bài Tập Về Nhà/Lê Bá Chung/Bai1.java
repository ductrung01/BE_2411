package com.javaweb;

import java.util.Scanner;

public class Bai1 {
    public static void main(String[] args) {
        System.out.printf("Nhập 1 số Bất kỳ : %n");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if (n < 0) {
            System.out.printf("Số Đã Nhập Là Số Âm");
        }else if(n == 0){
            System.out.printf("Số Đã Nhập Bằng 0");
        }else {
            System.out.printf("Số Đã Nhập Là Số Dương");
        }
    }
}
