package com.t3h.buoi3;

import java.util.Scanner;

public class baitap {
    public static void main(String[] args) {
        //Bài 1: kiểm tra số âm,dương hay bằng không.
        int n;
        System.out.println("Nhập n:");
        n = new Scanner(System.in).nextInt();
        if(n < 0){
            System.out.println(n+" là số âm");
        } else if (n == 0) {
            System.out.println(n+" bằng 0");
        } else {
            System.out.println(n+" là số dương");
        }

        //Bài 2: xác định số lớn nhất trong 3 số
        System.out.println("Nhập 3 số nguyên: ");
        int num1 = new Scanner(System.in).nextInt();
        int num2 = new Scanner(System.in).nextInt();
        int num3 = new Scanner(System.in).nextInt();
        int max = num1;
        if(num2 > max){
            max = num2;
        }if (num3 > max){
            max = num3;
        }
        System.out.println(" Số lớn nhất trong 3 số trên là: "+max);

        //Bài 3:Kiểm tra 3 số nhập vào có tạo thành một hình tam giác không
        System.out.println("Nhập vào 3 số dương: ");
        float n1 = new Scanner(System.in).nextFloat();
        float n2 = new Scanner(System.in).nextFloat();
        float n3 = new Scanner(System.in).nextFloat();
        if (n1 <= 0 || n2 <= 0 || n3 <= 0){
            System.out.println("Không thỏa mãn điều kiện tạo thành 1 tam giác.");
        }else {
            if (n1 + n2 > n3 && n1 + n3 > n2 && n2 + n3 > n1){
                System.out.println("Ba số trên tạo thành 1 hình tam giác");
            }else {
                System.out.println("Ba số trên không tạo thành 1 hình tam giác");
            }
        }

        //Bài 4:nhập vào 1 tháng bất kỳ trong năm và kiểm tra tháng đó vào mùa nào trong năm
        System.out.println("Nhập tháng:");
        int thang = new Scanner(System.in).nextInt();

            switch (thang){
                case 1:
                case 2:
                case 12:
                    System.out.println("Mùa đông");
                break;
                case 3:
                case 4:
                case 5:
                    System.out.println("Mùa xuân");
                break;
                case 6:
                case 7:
                case 8:
                    System.out.println("Mùa hè");
                break;
                case 9:
                case 10:
                case 11:
                    System.out.println("Mùa thu");
                break;

                default:
                    System.out.println("Sai");
            }

        /*Bài 5:Nhập vào n
        a. tính tổng các số từ 1 đến n
        b. tính tổng các số chẵn
        c. tìm các số nguyên tố từ 1 đến n
         */
        System.out.println("Nhập vào số nguyên:");
        int m = new Scanner(System.in).nextInt();
        int sum1 = 0;
        int sum2 = 0;
        int sum3 = 0;
        for (int i = 1;i <= m;i++){
            //Tính tổng từ 1 đến m
            sum1+=i;
            //Tính tổng các số chẵn
            if(i % 2 == 0){
                sum2+=i;
            }
            //In ra các số nguyên tố
           boolean isCheck = true;
            for (int j = 2;j <= i/2;j++){
                if(i % j == 0){
                    isCheck = false;
                    break;
                }
            }
            if (isCheck){
                System.out.println("Các số nguyên tố từ 1 đến "+m+" là:");
                System.out.println(i);
                sum3 += i;
            }
        }

        System.out.println("Tổng các số từ 1 đến "+m+" là: "+sum1);
        System.out.println("Tổng các số chẵn từ 1 đến "+m+" là: "+sum2);
        System.out.println("Tổng các số nguyên tố từ 1 đến "+m+" là: "+sum3);
    }
}
