import java.util.Scanner;

public class b2 {
    public static void main(String[] args) {
//        S(n) = 1^3 + 2^3 + ...+ n^3
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhap vao so nguyen duong n: ");
        int n = scanner.nextInt();

        int tong = 0;
        int a = 1;
        for (int i = 1; i <= n; i++) {
            tong += i * i * i;
        }

        System.out.println("Tổng S(n) = " + tong);
    }
}
