public class b6 {
    public static void main(String[] args) {
        int numLoop = 0;
        int count = 0;
        for(int x = 0; x <= 200/ 5; x ++){
            for (int y = 0; y <= (200 - x*5)/2; y++){
                numLoop++;
                count++;
            }
        }
        System.out.println("So lan lap " + numLoop +" so lan dem " + count);
    }
}
