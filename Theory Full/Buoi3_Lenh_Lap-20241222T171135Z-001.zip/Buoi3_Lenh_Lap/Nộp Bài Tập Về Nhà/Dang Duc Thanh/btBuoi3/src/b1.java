import java.util.Scanner;

public class b1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n;

        while (true) {
            System.out.print("Nhap vao so nguyen duong n: ");
            n = scanner.nextInt();
            if (n > 0) {
                break;
            }
            System.out.println("Nhap lai so nguyen duong.");
        }

        int[] fibonacci = new int[n];
        fibonacci[0] = 1;
        fibonacci[1] = 1;

        if (n == 1) {
            System.out.println("Dãy Fibonacci f(1): " + fibonacci[0]);
        } else if (n == 2) {
            System.out.println("Dãy Fibonacci f(2): " + fibonacci[1]);
        } else {
            for (int i = 2; i < n; i++) {
                fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
            }

            System.out.print("Dãy Fibonacci f(" + n + "): ");
            for (int i = 0; i < n; i++) {
                System.out.print(fibonacci[i] + " ");
            }
            System.out.println();
        }
    }
}
