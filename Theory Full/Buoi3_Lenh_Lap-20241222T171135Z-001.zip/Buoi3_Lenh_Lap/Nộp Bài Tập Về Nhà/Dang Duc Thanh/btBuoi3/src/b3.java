import java.util.Scanner;

public class b3 {
    public static int nhapSoNguyenDuong(String tenSo) {
        Scanner scanner = new Scanner(System.in);
        int so;
        do {
            System.out.print("Nhap vao so n duong " + tenSo + ": ");
            so = scanner.nextInt();
        } while (so <= 0);
        return so;
    }

    public static int timUSCLN(int a, int b) {
        while (b != 0) {
            int eg = b;
            b = a % b;
            a = eg;
        }
        return a;
    }

    public static int timBSCNN(int a, int b) {
        return (a * b) / timUSCLN(a, b);
    }

    public static void main(String[] args) {
        int a = nhapSoNguyenDuong("a");
        int b = nhapSoNguyenDuong("b");

        int uscln = timUSCLN(a, b);
        int bscnn = timBSCNN(a, b);

        System.out.println("USCLN của " + a + " và " + b + " là: " + uscln);
        System.out.println("BSCNN của " + a + " và " + b + " là: " + bscnn);
    }
}
