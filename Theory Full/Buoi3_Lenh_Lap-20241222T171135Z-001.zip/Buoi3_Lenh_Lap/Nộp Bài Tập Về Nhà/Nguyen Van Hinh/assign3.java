package lesson3;

import java.util.Scanner;

public class assign3 {
    public static void main(String[] args) {
//          assign3.checkNumb();
//          assign3.checkMaxNumber();
//          assign3.checkTriangle();
//          assign3.months();
        Scanner sc = new Scanner(System.in);
        System.out.println("Input n");
        int n = sc.nextInt();
        System.out.println(sumOfEvenNumbers(n));
        printPrimeNumbers(n);
    }

    public static void checkNumb() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input number:");
        int a = sc.nextInt();
        if (a < 0) {
            System.out.println("Negativve number");
        } else if (a > 0) {
            System.out.println("Positive number");
        } else {
            System.out.println("Zero number");
        }
    }

    public static void checkMaxNumber() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input number1: ");
        int number1 = sc.nextInt();
        System.out.println("Input number2: ");
        int number2 = sc.nextInt();
        System.out.println("Input number3: ");
        int number3 = sc.nextInt();

        int max = number1;
        if (number2 > max) {
            max = number2;
        }
        if (number3 > max) {
            max = number3;
        }
        System.out.println("Largest number: " + max);
    }

    public static void checkTriangle() {
        Scanner sc = new Scanner(System.in);
        double a, b, c;
        System.out.println("Input edge a: ");
        a = sc.nextDouble();
        System.out.println("Input edge b : ");
        b = sc.nextDouble();
        System.out.println("Input edge c: ");
        c = sc.nextDouble();

        if (a + b > c && a + c > b && c + b > a && a > 0 && b > 0 && c > 0) {
            if (a == b && b == c) {
                System.out.println("Equilateral triangle");
            } else if (a == b || b == c || a == c) {
                System.out.println("Isosceles triangle");
            } else if (a * a == b * b + c * c || b * b == a * a + c * c) {
                System.out.println("Right triangle");
            } else {
                System.out.println("Normal trianglee");
            }
        } else {
            System.out.println("Can't create a triangle with 3 input above.");
        }
    }

    public static void months() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your months: ");
        int months = sc.nextInt();

        switch (months) {
            case 1:
            case 2:
            case 3:
                System.out.println("Spring");
                break;
            case 4:
            case 5:
            case 6:
                System.out.println("Summer");
                break;
            case 7:
            case 8:
            case 9:
                System.out.println("Autumn ");
                break;
            case 10:
            case 11:
            case 12:
                System.out.println("Winter");
                break;
            default:
                System.out.println("Invalid value.");

        }
    }

    public static int sumOfEvenNumbers(int n) {
        // Tính tổng các số chẵn từ 1 đến n
        int totalSum = 0;
        for (int i = 2; i <= n; i += 2) {
            totalSum += i;
        }
        return totalSum;
    }

    public static boolean isPrime(int num) {

        if (num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void printPrimeNumbers(int n) {
        for (int i = 2; i <= n; i++) {
            if (isPrime(i)) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }
}
