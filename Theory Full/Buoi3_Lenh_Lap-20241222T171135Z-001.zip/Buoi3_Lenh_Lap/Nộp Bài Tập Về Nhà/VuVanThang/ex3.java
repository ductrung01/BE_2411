package VuVanThang;

import java.util.Scanner;

public class ex3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double a, b, c;
        boolean isValidInput = false;

        while (!isValidInput) {
            System.out.println("Nhập ba cạnh của tam giác:");
            System.out.print("Cạnh a: ");
            a = scanner.nextDouble();
            System.out.print("Cạnh b: ");
            b = scanner.nextDouble();
            System.out.print("Cạnh c: ");
            c = scanner.nextDouble();

            if (a <= 0 || b <= 0 || c <= 0) {
                System.out.println("Ba cạnh của tam giác phải là các số dương. Vui lòng nhập lại.");
            } else {
                isValidInput = true;
                if (isTriangle(a, b, c)) {
                    System.out.println("Ba cạnh đã nhập tạo thành một tam giác.");
                } else {
                    System.out.println("Ba cạnh đã nhập không thể tạo thành một tam giác.");
                }
            }
        }


    }

    public static boolean isTriangle(double a, double b, double c) {
        return (a + b > c) && (a + c > b) && (b + c > a);
    }
}
