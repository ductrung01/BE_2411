package VuVanThang;

import java.util.Scanner;

public class ex5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter n: ");
        int n = sc.nextInt();
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum+=i;
        }
        System.out.println("The sum of number from 1 to n is: " + sum);

        int tong = 0;
        for (int i = 1; i <= n; i++) {
            if (i % 2 == 0){
                tong+=i;
            }
        }
        System.out.println("The sum of the even numbers from 1 to n is: " + tong);

        for (int i =2; i <= n; i++){
            boolean isPrime = true;
            for (int j = 2; j < i; j++){
                if (i % j == 0){
                    isPrime = false;
                }
            }
            if (isPrime){
                System.out.println(i);
            }
        }

    }
}
