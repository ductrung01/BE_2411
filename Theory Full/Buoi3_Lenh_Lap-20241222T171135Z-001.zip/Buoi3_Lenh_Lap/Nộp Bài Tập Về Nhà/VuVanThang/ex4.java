package VuVanThang;

import java.util.Scanner;

public class ex4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập vào một tháng trong năm (từ 1 đến 12): ");
        int month = scanner.nextInt();



        switch (month) {
            case 1:
            case 2:
            case 12:
                System.out.println("Mua dong");
                break;
            case 3:
            case 4:
            case 5:
                System.out.println("Mua xuan");
                break;
            case 6:
            case 7:
            case 8:
                System.out.println("Mua he");
                break;
            case 9:
            case 10:
                System.out.println("Mua thu");
                break;
            default:
                System.out.println("Khong xac dinh");
                break;
        }
    }
}
