package org.example.Exercises.Lesson2;

import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a random number: ");
        int n = scanner.nextInt();
        String positiveNumber = "Positive number";
        String negativeNumber = "Negative number";

        String result = (n > 0) ? positiveNumber : negativeNumber;
        if(n == 0) {
            System.out.print("This number equal to 0");
        }
        System.out.println("Result: "+result);

    }
}
