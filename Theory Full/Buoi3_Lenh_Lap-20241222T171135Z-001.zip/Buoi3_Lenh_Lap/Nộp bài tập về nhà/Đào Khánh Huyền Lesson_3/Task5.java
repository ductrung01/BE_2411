package org.example.Exercises.Lesson2;

import java.util.Scanner;

public class Task5 {

    public static boolean checkPrime(int n){
        int count = 0;
        for(int i = 1; i <= n; i++){
            if(n % i == 0){
                count++;
            }
        }
        return count == 2;
    }

    public static void main(String[] args) {
        System.out.print("Enter a random number: ");
        int n = new Scanner(System.in).nextInt();
        int sum = 0, sumEven = 0;
        System.out.print("The prime numbers are: ");
        for(int i = 1; i < n; i++){
            sum += i;
            if(i % 2 == 0){
                sumEven += i;
            }
            if(checkPrime(i)){
                System.out.print( i+" ");
            }

        }
        System.out.println();
        System.out.print("Sum of the number from 0 to n: " + sum + "\n");
        System.out.print("Sum of the even number from 0 to n: " + sumEven);



    }
}
