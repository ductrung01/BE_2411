package org.example.Exercises.Lesson2;

import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a, b ,c;
        System.out.print("Enter a: ");
        a = scanner.nextInt();
        System.out.print("Enter b: ");
        b = scanner.nextInt();
        System.out.print("Enter c: ");
        c = scanner.nextInt();
        if(a == 0 || b == 0 || c == 0){
            System.out.print("One of the invalid numbers");
        } else if (a <= 0 || b <= 0 || c <= 0) {
            System.out.print("One of the invalid numbers");
        } else if(a + b >= c || a + c >= b || b + c >= a){
            System.out.print("This is a triangle");
        }
    }
}
