package org.example.Exercises.Lesson2;

import java.util.Scanner;

public class Task4 {
    public static void main(String[] args) {
        System.out.print("Enter a random month: ");
        int month = new Scanner(System.in).nextInt();
        switch (month){
            case 1, 2, 12:
                System.out.print("This month is Winter");
                break;
                case 3, 4, 5:
                System.out.print("This month is Spring");
                break;
                case 6, 7, 8:
                System.out.print("This month is Summer");
                break;
                case 9, 10, 11:
                System.out.print("This month is Autumn");
                break;
            default:
                System.out.print("Invalid month");
                break;
        }

    }
}
