package org.example.Exercises.Lesson2;

import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a, b ,c, max = Integer.MIN_VALUE, min = Integer.MAX_VALUE;
        System.out.print("Enter a: ");
        a = scanner.nextInt();
        System.out.print("Enter b: ");
        b = scanner.nextInt();
        System.out.print("Enter c: ");
        c = scanner.nextInt();

        int[] numbers = new int[]{a, b, c};
        checkNumbers(max, min, numbers);


    }

    public static void checkNumbers(int max, int min, int[] numbers) {
        for(int n : numbers){
            if(n < min){
                min = n;
            }
            if(n > max){
                max = n;
            }
        }
        System.out.print("Minimum number is:  "+min +"\n");
        System.out.print("Maximum number is: " +max);
    }
}
