package Javat3h;

import java.util.Scanner;

public class VũVănThăng {
    public static void main(String[] args) {

        //Bai 1
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length: ");
        double length = sc.nextDouble();
        System.out.println("Enter the width: ");
        double width = sc.nextDouble();

        double area =length*width;
        System.out.println("The area of the rectangle is "+area);

        //Bai 2
        System.out.println("Enter the number: ");
        int num = sc.nextInt();
        if (num%2==0) {
            System.out.println("The number is even");
        }else {
            System.out.println("The number is odd");
        }
    }
}
