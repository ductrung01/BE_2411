package buoi2;

import java.util.Scanner;

public class BaiTap {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập chiều dài và chiều rộng
        System.out.print("Nhập chiều dài: ");
        float chieuDai = sc.nextFloat();
        System.out.print("Nhập chiều rộng: ");
        float chieuRong = sc.nextFloat();

        // Tính diện tích và chu vi
        float dienTich = chieuDai * chieuRong;
        float chuVi = 2 * (chieuDai + chieuRong);

        // Hiển thị kết quả
        System.out.println("Diện tích: " + dienTich);
        System.out.println("Chu vi: " + chuVi);
    }
}
//Bài 2
//public static void main(String[] args) {
//    Scanner sc = new Scanner(System.in);
//
//    // Nhập số nguyên
//    System.out.print("Nhập số nguyên: ");
//    int n = sc.nextInt();
//
//    // Kiểm tra số chẵn/lẻ
//    if (n % 2 == 0) {
//        System.out.println(n + " là số chẵn");
//    } else {
//        System.out.println(n + " là số lẻ");
//    }
//}}

