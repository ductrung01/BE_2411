public class buoi2_b3 {
    public static void main(String[] args) {
        
    }
}
