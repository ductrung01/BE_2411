import java.util.Scanner;

public class buoi2_b1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Nhap he so a: ");
        double a = scanner.nextDouble();

        System.out.println("Nhap he so b: ");
        double b = scanner.nextDouble();

        if (a == 0) {
            if (b == 0) {
                System.out.println("Pt vo so nghiem");
            } else {
                System.out.println("Pt vo nghiem");
            }
        } else {
            double x = -b / a;
            System.out.println("No cua pt la x = " + x);
        }
    }
}
