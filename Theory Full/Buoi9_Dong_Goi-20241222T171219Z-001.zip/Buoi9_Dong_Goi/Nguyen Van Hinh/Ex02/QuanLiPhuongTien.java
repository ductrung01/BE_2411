package lesson9.Ex02;

import java.util.Scanner;

public class QuanLiPhuongTien {
    private PhuongTienGiaoThong[] ptgt;
    private int tongPhuongTien;

    public void themPhuongTienGiaoThong() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Chon 1 loai phuong tien : \n 1. XeMay \n 2.Xe Tai \n3.Oto");
        int loaiPhuongTien = sc.nextInt();
        sc.nextInt();
        PhuongTienGiaoThong pt = null;
        switch(loaiPhuongTien){
            case 1:
                pt = new XeMay();
               pt.nhapThongTin();
                break;
            case 2:
                pt = new XeTai();
                pt.nhapThongTin();
                break;

            case 3:
                pt = new Oto();
                pt.nhapThongTin();
                break;
            default:
                System.out.println("loai phuong tien khong dung");

        }
        this.ptgt[this.tongPhuongTien] = pt;
        this.tongPhuongTien++;
    }
    public void xoaTheoId(int id){
        boolean flag = false;
        for (int i = 0; i < this.tongPhuongTien; i++) {
            if (ptgt[i].getId() == id){
                for (int j = i; j < this.tongPhuongTien-1; j++) {
                    ptgt[j] = ptgt[j+1];
                }
                ptgt[this.tongPhuongTien-1] = null;
                flag = true;
                System.out.println("phuong tien " + id + "da xoa thanh cong");
                break;
            }
        }
        if (flag == false){
            System.out.println("Khong tim thay phuong tien voi id nhu tren");
        }

    }
    public void timTheoHangSanXuat(String hangSanXuat){
        boolean flag = false;
for (int i =0; i< this.tongPhuongTien; i++) {
 if (ptgt[i].getHangSanXuat().equalsIgnoreCase(hangSanXuat)){
     System.out.println(ptgt[i]);
     flag = true;
 }
}
if (!flag){
    System.out.println("khong ton tai phuong tien voi ma san xuat nay.");
}
    }

}
