package lesson9.Ex02;

import java.util.Scanner;

public class XeMay extends PhuongTienGiaoThong {
    private int congSuat;

@Override
public void nhapThongTin(){
    super.nhapThongTin();
    Scanner sc = new Scanner(System.in);
    System.out.println("Moi nhap cong suat:");
    congSuat = sc.nextInt();

}
@Override
public void hienThiThongTin(){
    super.hienThiThongTin();
    this.toString();
}
    public int getCongSuat() {
        return congSuat;
    }

    public void setCongSuat(int congSuat) {
        this.congSuat = congSuat;
    }

    @Override
    public String toString() {
        return "Oto{" +
                "congSuat=" + congSuat +
                '}';
    }
}
