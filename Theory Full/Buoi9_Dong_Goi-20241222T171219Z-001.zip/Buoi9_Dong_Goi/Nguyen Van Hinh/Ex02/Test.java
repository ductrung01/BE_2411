package lesson9.Ex02;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        QuanLiPhuongTien qlptgt = new QuanLiPhuongTien();
        Scanner sc = new Scanner(System.in);
boolean tieptuc = true;
        while(tieptuc){
            System.out.println("chon chuc nang");
            System.out.println("1.Them phuong tien");
            System.out.println("2. Xoa theo id");
            System.out.println("3. Tim kiem theo hang san xuat");
            int choice = sc.nextInt();

            switch(choice){
                case 1:
                    qlptgt.themPhuongTienGiaoThong();
                    break;
                case 2:
                    System.out.println("Moi nhap vao id");
                    int id = sc.nextInt();
                    qlptgt.xoaTheoId(id);
                    break;
                case 3:
                    System.out.println("Moi nhap vao hang san xuat muon tim:");
                    String hsx = sc.next();
                    qlptgt.timTheoHangSanXuat(hsx);
                    break;
                default:
                    tieptuc = false;
            }
        }
    }
}
