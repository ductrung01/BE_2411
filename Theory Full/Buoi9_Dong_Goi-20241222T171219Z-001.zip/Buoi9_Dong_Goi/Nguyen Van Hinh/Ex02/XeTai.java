package lesson9.Ex02;

import java.util.Scanner;

public class XeTai extends PhuongTienGiaoThong {
    private String trongTai;



    @Override
    public void nhapThongTin(){
        super.nhapThongTin();
        Scanner sc = new Scanner(System.in);
        System.out.println("Moi nhap thong tin trong tai");
        this.trongTai = sc.nextLine();
    }
    @Override
    public void hienThiThongTin(){
        super.hienThiThongTin();
        this.toString();

    }
    public String getTrongTai() {
        return trongTai;
    }

    public void setTrongTai(String trongTai) {
        this.trongTai = trongTai;
    }

    @Override
    public String toString() {
        return "XeTai{" +
                "trongTai='" + trongTai + '\'' +
                '}';
    }
}
