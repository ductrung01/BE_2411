package lesson9.Ex02;

import java.util.Scanner;

public class Oto extends PhuongTienGiaoThong {
     private int soChoNgoi;
     private String kieuDongCo;

     @Override
     public void nhapThongTin(){
         super.nhapThongTin();
         Scanner sc = new Scanner(System.in);
         System.out.println("Moi nhap so cho ngoi:");
         this.soChoNgoi = sc.nextInt();
         System.out.println("Moi nhap kieu dong co:");
         this.kieuDongCo = sc.nextLine();

     }
     @Override
     public void hienThiThongTin(){
         super.hienThiThongTin();
         this.toString();
     }
    public int getSoChoNgoi() {
        return soChoNgoi;
    }

    public void setSoChoNgoi(int soChoNgoi) {
        this.soChoNgoi = soChoNgoi;
    }

    public String getKieuDongCo() {
        return kieuDongCo;
    }

    public void setKieuDongCo(String kieuDongCo) {
        this.kieuDongCo = kieuDongCo;
    }

    @Override
    public String toString() {
        return "Oto{" +
                "soChoNgoi=" + soChoNgoi +
                ", kieuDongCo='" + kieuDongCo + '\'' +
                '}';
    }
}
