package lesson9.Ex02;

import java.util.Scanner;

public class PhuongTienGiaoThong {

    private int id;
    private String hangSanXuat;
    private int namSanXuat;
    private int gia;
    private String mauXe;


    public void nhapThongTin(){
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap vao hang San xuat: ");
        this.hangSanXuat = sc.nextLine();
        System.out.println("Nhap vao nam san xuat: ");
        namSanXuat =sc.nextInt();
    }

    public void hienThiThongTin(){
        System.out.println(this.toString());
    }


    public int getGia() {
        return gia;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }

    public int getNamSanXuat() {
        return namSanXuat;
    }

    public void setNamSanXuat(int namSanXuat) {
        this.namSanXuat = namSanXuat;
    }

    public String getHangSanXuat() {
        return hangSanXuat;
    }

    public void setHangSanXuat(String hangSanXuat) {
        this.hangSanXuat = hangSanXuat;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMauXe() {
        return mauXe;
    }

    public void setMauXe(String mauXe) {
        this.mauXe = mauXe;
    }

    @Override
    public String toString() {
        return "PhuongTienGiaoThong{" +
                "id=" + id +
                ", hangSanXuat='" + hangSanXuat + '\'' +
                ", namSanXuat=" + namSanXuat +
                ", gia=" + gia +
                ", mauXe='" + mauXe + '\'' +
                '}';
    }
}
