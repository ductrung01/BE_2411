package lesson9.ex01;

import java.util.Arrays;

public class Family {
    private int totalMember;
    private int address;
    private Person[] member;
    public Family(int totalMember, int numberMember, Person[] member) {
        this.totalMember = totalMember;
        this.address = address;
        this.member = member;
    }

    public int getTotalMember() {
        return totalMember;
    }

    public void setTotalMember(int totalMember) {
        this.totalMember = totalMember;
    }

    public int getAddress() {
        return address;
    }

    public void setAddress(int numberMember) {
        this.address = address;
    }

    public Person[] getMember() {
        return member;
    }

    public void setMember(Person[] member) {
        this.member = member;
    }

    @Override
    public String toString() {
        return "Family{" +
                "totalMember=" + totalMember +
                ", numberMember=" + address +
                ", member=" + Arrays.toString(member) +
                '}';

    }
}
