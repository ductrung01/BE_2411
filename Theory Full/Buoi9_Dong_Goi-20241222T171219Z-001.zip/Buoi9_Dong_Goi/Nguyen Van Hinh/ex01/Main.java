package lesson9.ex01;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Import the total number of house");
        int numberHouse = sc.nextInt();
        Quarter quarter = new Quarter(numberHouse);
        quarter.inputInfor();

        while(true){
            System.out.println("1. Print information about quater");
            System.out.println("2. Search Name : ");
            System.out.println("3. Exit");
            System.out.println("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();
            switch(choice){
                case 1:
                    quarter.print();
                    break;
                case 2:
                    System.out.println("Input name want search: ");
                String name = sc.nextLine();
                    quarter.searchName(name);
                    break;
                    case 3:
                        System.out.println("Exit the program");
                        return;
                default:
                    System.out.println("Invalid choice");

            }
        }
    }
}
