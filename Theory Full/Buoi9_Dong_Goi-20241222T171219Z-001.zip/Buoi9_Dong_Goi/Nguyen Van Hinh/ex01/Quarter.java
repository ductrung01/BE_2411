package lesson9.ex01;

import java.lang.reflect.Member;
import java.util.Scanner;

public class Quarter {
    private Family[] eachFamily;
    private int numberHouse;

    public Quarter(int numberHouse) {
        this.numberHouse = numberHouse;
        eachFamily = new Family[numberHouse];

    }

    public void inputInfor(){
        Scanner sc = new Scanner(System.in);
        for(int i = 0; i < eachFamily.length; i++){
            System.out.println("Import information for the family in order" + (i+1));
            System.out.println("Import the number of members in your family: ");
            int totalMember = sc.nextInt();
            System.out.println("Import the address: ");
            int address = sc.nextInt();
            Person[] member = new Person[totalMember];
            for(int j = 0; j < totalMember; j++){
                System.out.println("Import information for member in" + (j+1));
                sc.nextLine();
                System.out.println("Import the name" );
                String name = sc.nextLine();
                System.out.println("Import age: ");
                int age = sc.nextInt();
                sc.nextLine();
                System.out.println("Import job: ");
                String job = sc.nextLine();
                System.out.println("Import cmnd: ");
                String cmnd = sc.nextLine();
                member[j] = new Person(name,age,job,cmnd);
            }
            eachFamily[i] = new Family(totalMember, address, member);
        }
    }
    public void print(){
        for(int i = 0; i < eachFamily.length; i++){
            System.out.println(eachFamily[i]);
        }
    }
    public void searchName(String names){
        for(Family family : eachFamily){
            for(Person person : family.getMember()){
                if(person.getName().toLowerCase().contains(names.toLowerCase())){
                    System.out.println("Family has member name; " +  names);
                    System.out.println("Total member of Family: " +family.getTotalMember());
                    System.out.println("Address: " + family.getAddress());
                    System.out.println();
                    break;
                }
            }
        }
    }
}
