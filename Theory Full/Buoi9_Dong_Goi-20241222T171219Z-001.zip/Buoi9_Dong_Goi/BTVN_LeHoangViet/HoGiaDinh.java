package buoi9.baiTap;

import java.util.ArrayList;

    class HoGiaDinh {
    private int soThanhVien;
    private String soNha;
    private Nguoi[] thanhVien;

    public HoGiaDinh(int soThanhVien, String soNha, Nguoi[] thanhVien) {
        this.soThanhVien = soThanhVien;
        this.soNha = soNha;
        this.thanhVien = thanhVien;
    }

    public String getSoNha() {
        return soNha;
    }

    public Nguoi[] getThanhVien() {
        return thanhVien;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("Số nhà: " + soNha + ", Số thành viên: " + soThanhVien + "\n");
        for (Nguoi nguoi : thanhVien) {
            result.append(nguoi.toString()).append("\n");
        }
        return result.toString();
    }
}