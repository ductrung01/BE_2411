package buoi9.baiTap.bai2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class QLPTGT {
    private List<PhuongTien> danhSachPhuongTien;

    public QLPTGT() {
        this.danhSachPhuongTien = new ArrayList<>();
    }

    public void themPhuongTien(PhuongTien phuongTien) {
        danhSachPhuongTien.add(phuongTien);
        System.out.println("Đã thêm phương tiện: " + phuongTien);
    }

    public void xoaPhuongTienTheoId(String id) {
        Iterator<PhuongTien> iterator = danhSachPhuongTien.iterator();
        boolean found = false;
        while (iterator.hasNext()) {
            PhuongTien pt = iterator.next();
            if (pt.getId().equals(id)) {
                iterator.remove();
                found = true;
                System.out.println("Đã xóa phương tiện có ID: " + id);
                break;
            }
        }
        if (!found) {
            System.out.println("Không tìm thấy phương tiện có ID: " + id);
        }
    }

    public void timPhuongTienTheoHangSanXuat(String hangSanXuat) {
        boolean found = false;
        for (PhuongTien pt : danhSachPhuongTien) {
            if (pt.getHangSanXuat().equalsIgnoreCase(hangSanXuat)) {
                System.out.println(pt);
                found = true;
            }
        }
        if (!found) {
            System.out.println("Không tìm thấy phương tiện của hãng sản xuất: " + hangSanXuat);
        }
    }

    public void timPhuongTienTheoMau(String mauXe) {
        boolean found = false;
        for (PhuongTien pt : danhSachPhuongTien) {
            if (pt.getMauXe().equalsIgnoreCase(mauXe)) {
                System.out.println(pt);
                found = true;
            }
        }
        if (!found) {
            System.out.println("Không tìm thấy phương tiện có màu: " + mauXe);
        }
    }

    public void thoatChuongTrinh() {
        System.out.println("Thoát chương trình.");
        System.exit(0);
    }

    public static void main(String[] args) {
        QLPTGT qlptgt = new QLPTGT();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Thêm phương tiện");
            System.out.println("2. Xóa phương tiện theo ID");
            System.out.println("3. Tìm phương tiện theo hãng sản xuất");
            System.out.println("4. Tìm phương tiện theo màu");
            System.out.println("5. Thoát chương trình");
            System.out.print("Chọn chức năng: ");
            int chon = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            switch (chon) {
                case 1:
                    System.out.println("Chọn loại phương tiện:");
                    System.out.println("1. Ô tô");
                    System.out.println("2. Xe máy");
                    System.out.println("3. Xe tải");
                    int loai = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    System.out.print("ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Hãng sản xuất: ");
                    String hangSanXuat = scanner.nextLine();
                    System.out.print("Năm sản xuất: ");
                    int namSanXuat = scanner.nextInt();
                    System.out.print("Giá bán: ");
                    double giaBan = scanner.nextDouble();
                    scanner.nextLine();  // Consume newline
                    System.out.print("Màu xe: ");
                    String mauXe = scanner.nextLine();
                    switch (loai) {
                        case 1:
                            System.out.print("Số chỗ ngồi: ");
                            int soChoNgoi = scanner.nextInt();
                            scanner.nextLine();  // Consume newline
                            System.out.print("Kiểu động cơ: ");
                            String kieuDongCo = scanner.nextLine();
                            qlptgt.themPhuongTien(new OTo(id, hangSanXuat, namSanXuat, giaBan, mauXe, soChoNgoi, kieuDongCo));
                            break;
                        case 2:
                            System.out.print("Công suất: ");
                            double congSuat = scanner.nextDouble();
                            scanner.nextLine();  // Consume newline
                            qlptgt.themPhuongTien(new XeMay(id, hangSanXuat, namSanXuat, giaBan, mauXe, congSuat));
                            break;
                        case 3:
                            System.out.print("Trọng tải: ");
                            double trongTai = scanner.nextDouble();
                            scanner.nextLine();  // Consume newline
                            qlptgt.themPhuongTien(new XeTai(id, hangSanXuat, namSanXuat, giaBan, mauXe, trongTai));
                            break;
                        default:
                            System.out.println("Loại phương tiện không hợp lệ!");
                    }
                    break;
                case 2:
                    System.out.print("Nhập ID phương tiện cần xóa: ");
                    String idXoa = scanner.nextLine();
                    qlptgt.xoaPhuongTienTheoId(idXoa);
                    break;
                case 3:
                    System.out.print("Nhập hãng sản xuất: ");
                    String hangSX = scanner.nextLine();
                    qlptgt.timPhuongTienTheoHangSanXuat(hangSX);
                    break;
                case 4:
                    System.out.print("Nhập màu xe: ");
                    String mau = scanner.nextLine();
                    qlptgt.timPhuongTienTheoMau(mau);
                    break;
                case 5:
                    qlptgt.thoatChuongTrinh();
                    break;
                default:
                    System.out.println("Chức năng không hợp lệ!");
            }
        }
    }
}
