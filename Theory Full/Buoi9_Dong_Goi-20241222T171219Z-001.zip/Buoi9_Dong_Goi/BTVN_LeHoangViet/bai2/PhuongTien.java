package buoi9.baiTap.bai2;

abstract class PhuongTien {
    protected String id;
    protected String hangSanXuat;
    protected int namSanXuat;
    protected double giaBan;
    protected String mauXe;

    public PhuongTien(String id, String hangSanXuat, int namSanXuat, double giaBan, String mauXe) {
        this.id = id;
        this.hangSanXuat = hangSanXuat;
        this.namSanXuat = namSanXuat;
        this.giaBan = giaBan;
        this.mauXe = mauXe;
    }

    public String getId() {
        return id;
    }

    public String getHangSanXuat() {
        return hangSanXuat;
    }

    public String getMauXe() {
        return mauXe;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Hãng sản xuất: " + hangSanXuat + ", Năm sản xuất: " + namSanXuat + ", Giá bán: " + giaBan + ", Màu xe: " + mauXe;
    }
}

class OTo extends PhuongTien {
    private int soChoNgoi;
    private String kieuDongCo;

    public OTo(String id, String hangSanXuat, int namSanXuat, double giaBan, String mauXe, int soChoNgoi, String kieuDongCo) {
        super(id, hangSanXuat, namSanXuat, giaBan, mauXe);
        this.soChoNgoi = soChoNgoi;
        this.kieuDongCo = kieuDongCo;
    }

    @Override
    public String toString() {
        return super.toString() + ", Số chỗ ngồi: " + soChoNgoi + ", Kiểu động cơ: " + kieuDongCo;
    }
}

class XeMay extends PhuongTien {
    private double congSuat;

    public XeMay(String id, String hangSanXuat, int namSanXuat, double giaBan, String mauXe, double congSuat) {
        super(id, hangSanXuat, namSanXuat, giaBan, mauXe);
        this.congSuat = congSuat;
    }

    @Override
    public String toString() {
        return super.toString() + ", Công suất: " + congSuat;
    }
}

class XeTai extends PhuongTien {
    private double trongTai;

    public XeTai(String id, String hangSanXuat, int namSanXuat, double giaBan, String mauXe, double trongTai) {
        super(id, hangSanXuat, namSanXuat, giaBan, mauXe);
        this.trongTai = trongTai;
    }

    @Override
    public String toString() {
        return super.toString() + ", Trọng tải: " + trongTai;
    }
}
