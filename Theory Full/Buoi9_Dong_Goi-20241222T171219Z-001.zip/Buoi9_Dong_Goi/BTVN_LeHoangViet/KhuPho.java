package buoi9.baiTap;

import java.util.ArrayList;

class KhuPho {
    private HoGiaDinh[] hoGiaDinhList;
    private int soHoGiaDinh;

    public KhuPho(int maxHoGiaDinh) {
        this.hoGiaDinhList = new HoGiaDinh[maxHoGiaDinh];
        this.soHoGiaDinh = 0;
    }

    public void themHoGiaDinh(HoGiaDinh hoGiaDinh) {
        if (soHoGiaDinh < hoGiaDinhList.length) {
            hoGiaDinhList[soHoGiaDinh++] = hoGiaDinh;
        } else {
            System.out.println("Không thể thêm hộ gia đình mới, đã đạt giới hạn.");
        }
    }

    public void hienThiThongTin() {
        for (int i = 0; i < soHoGiaDinh; i++) {
            System.out.println(hoGiaDinhList[i]);
        }
    }

    public void timKiemHoGiaDinh(String ten) {
        for (int i = 0; i < soHoGiaDinh; i++) {
            HoGiaDinh hoGiaDinh = hoGiaDinhList[i];
            for (Nguoi nguoi : hoGiaDinh.getThanhVien()) {
                if (nguoi.getHoTen().toLowerCase().contains(ten.toLowerCase())) {
                    System.out.println("Số nhà: " + hoGiaDinh.getSoNha() + ", Số thành viên: " + hoGiaDinh.getThanhVien().length);
                    return;
                }
            }
        }
        System.out.println("Không tìm thấy hộ gia đình có thành viên tên: " + ten);
    }
}