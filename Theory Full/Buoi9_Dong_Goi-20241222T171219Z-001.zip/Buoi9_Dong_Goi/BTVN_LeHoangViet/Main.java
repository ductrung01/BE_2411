package buoi9.baiTap;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập số lượng hộ gia đình tối đa trong khu phố: ");
        int maxHoGiaDinh = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        KhuPho khuPho = new KhuPho(maxHoGiaDinh);

        while (true) {
            System.out.println("1. Nhập n hộ dân");
            System.out.println("2. Hiển thị thông tin các hộ dân");
            System.out.println("3. Tìm kiếm hộ gia đình theo tên thành viên");
            System.out.println("4. Thoát chương trình");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Nhập số hộ dân: ");
                    int n = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    for (int i = 0; i < n; i++) {
                        System.out.print("Nhập số nhà: ");
                        String soNha = scanner.nextLine();
                        System.out.print("Nhập số thành viên: ");
                        int soThanhVien = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        Nguoi[] thanhVien = new Nguoi[soThanhVien];
                        for (int j = 0; j < soThanhVien; j++) {
                            System.out.print("Nhập họ tên thành viên: ");
                            String hoTen = scanner.nextLine();
                            System.out.print("Nhập tuổi: ");
                            int tuoi = scanner.nextInt();
                            scanner.nextLine(); // Consume newline
                            System.out.print("Nhập nghề nghiệp: ");
                            String ngheNghiep = scanner.nextLine();
                            System.out.print("Nhập số CMND: ");
                            String soCMND = scanner.nextLine();

                            thanhVien[j] = new Nguoi(hoTen, tuoi, ngheNghiep, soCMND);
                        }

                        khuPho.themHoGiaDinh(new HoGiaDinh(soThanhVien, soNha, thanhVien));
                    }
                    break;

                case 2:
                    khuPho.hienThiThongTin();
                    break;

                case 3:
                    System.out.print("Nhập tên thành viên để tìm kiếm: ");
                    String ten = scanner.nextLine();
                    khuPho.timKiemHoGiaDinh(ten);
                    break;

                case 4:
                    System.out.println("Thoát chương trình");
                    scanner.close();
                    return;

                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
                    break;
            }
        }
    }
}