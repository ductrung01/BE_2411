package Buoi9.Bai1;

public class HoGiaDinh {
    private int soThanhVien;
    private String soNha;
    private Nguoi[] thanhVien;

    public HoGiaDinh(int soThanhVien, String soNha, Nguoi[] thanhVien) {
        this.soThanhVien = soThanhVien;
        this.soNha = soNha;
        this.thanhVien = thanhVien;
    }

    public int getSoThanhVien() {
        return soThanhVien;
    }

    public String getSoNha() {
        return soNha;
    }

    public Nguoi[] getThanhVien() {
        return thanhVien;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Số nhà: ").append(soNha).append(", Số thành viên: ").append(soThanhVien).append("\n");
        for (Nguoi n : thanhVien) {
            sb.append(n.toString()).append("\n");
        }
        return sb.toString();
    }
}
