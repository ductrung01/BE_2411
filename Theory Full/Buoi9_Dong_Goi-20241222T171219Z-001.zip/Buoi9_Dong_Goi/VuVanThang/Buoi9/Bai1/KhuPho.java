package Buoi9.Bai1;

import java.util.Scanner;

public class KhuPho {
    private HoGiaDinh[] hoGiaDinh;
    private int soHoGiaDinh;

    public KhuPho(int soHoGiaDinh){
        this.soHoGiaDinh=soHoGiaDinh;
        hoGiaDinh=new HoGiaDinh[soHoGiaDinh];
    }

    public void nhapThongTin (){
        Scanner scanner = new Scanner(System.in);

        for (int i=0; i< soHoGiaDinh ; i++){
            System.out.println("Nhap so thanh vien trong gia dinh thu: "+(i+1)+": ");
            int soThanhVien = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Nhap so nha: ");
            String soNha = scanner.nextLine();

            Nguoi[] thanhVien = new Nguoi[soThanhVien];
            for (int j=0; j<soThanhVien; j++){
                System.out.println("Nhap thong tin thanh vien thu "+(j+1)+": ");
                System.out.println("Ho ten: ");
                String hoTen = scanner.nextLine();

                System.out.println("Tuoi: ");
                int tuoi = scanner.nextInt();
                scanner.nextLine();

                System.out.println("Nghe nghiep: ");
                String ngheNghiep = scanner.nextLine();

                System.out.println("So CMND: ");
                String soCMND = scanner.nextLine();

                thanhVien[j] = new Nguoi(hoTen, tuoi, ngheNghiep, soCMND);
            }
            hoGiaDinh[i] = new HoGiaDinh(soThanhVien, soNha, thanhVien);
        }
    }
    public void hienThiThongTin(){
        for (HoGiaDinh hogiadinh: hoGiaDinh){
            System.out.println(hogiadinh);
        }
    }
    public void timKiemHoGiaDinh(String ten){
        for (HoGiaDinh ho: hoGiaDinh){
            for (Nguoi n: ho.getThanhVien()){
                if (n.getHoten().toLowerCase().contains(ten.toLowerCase())){
                    System.out.println("Ho gia dinh co thanh vien: "+n.getHoten());
                    System.out.println("Số nhà: " + ho.getSoNha() + ", Số thành viên: " + ho.getSoThanhVien());
                    return;
                }
            }
        }
        System.out.println("Khong tim thay ho gia dinh co thanh vien ten: "+ ten);
    }
}
