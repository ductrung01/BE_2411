package Buoi9.Bai1;

public class Nguoi {
     private String hoTen;
     private int tuoi;
     private String ngheNghiep;
     private String soCMND;

     public Nguoi(String hoTen, int tuoi, String ngheNghiep, String soCMND) {
         this.hoTen = hoTen;
         this.tuoi = tuoi;
         this.ngheNghiep = ngheNghiep;
         this.soCMND = soCMND;
     }

    public String getHoten() {
        return hoTen;
    }

    public String getNgheNghiep() {
        return ngheNghiep;
    }

    public int getTuoi() {
        return tuoi;
    }

    public String getSoCMND() {
        return soCMND;
    }

    @Override
    public String toString() {
        return "Họ tên: " + hoTen + ", Tuổi: " + tuoi + ", Nghề nghiệp: " + ngheNghiep + ", Số CMND: " + soCMND;
    }
}
