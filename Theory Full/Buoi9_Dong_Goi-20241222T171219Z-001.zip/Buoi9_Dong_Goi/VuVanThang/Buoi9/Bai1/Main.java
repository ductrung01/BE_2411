package Buoi9.Bai1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        KhuPho khuPho = null;

        while(true){
            System.out.println("======MENU======");
            System.out.println("1. Nhap thong tin cac ho dan ");
            System.out.println("2. Hien thi thong tin cac ho dan");
            System.out.println("3. Tim kiem ho gia dinh theo ten thanh vien");
            System.out.println("4. Thoat");
            System.out.println("Chon chuc nang: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("Nhap so ho dan: ");
                    int soHoDan = scanner.nextInt();
                    scanner.nextLine();
                    khuPho = new KhuPho(soHoDan);
                    khuPho.nhapThongTin();
                    break;
                case 2:
                    if (khuPho != null){
                        khuPho.hienThiThongTin();
                    }else{
                        System.out.println("Chua co thong tin cua 1 ho gia dinh nao ca.");
                    }
                    break;
                case 3:
                    if (khuPho != null){
                        System.out.println("Nhap ten thanh vien can tim: ");
                        String ten = scanner.nextLine();
                        khuPho.timKiemHoGiaDinh(ten);
                    }else {
                        System.out.println("Vui long nhap thong tin ho gia dinh truoc.");
                    }
                    break;
                case 4:
                    System.out.println("Thoat chuong trinh.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Lua chon khong hop le. Vui long nhap lai.");
                    break;
            }
        }
    }
}
