package Buoi9.Bai3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        QLPTGT qlptgt = new QLPTGT(100);
        Scanner scanner = new Scanner(System.in);

        while(true){
            System.out.println("1. Thêm Phương Tiện");
            System.out.println("2. Xóa Phương Tiện theo ID");
            System.out.println("3. Tìm Phương Tiện theo Hãng Sản Xuất và Màu Xe");
            System.out.println("4. Hien thi thong tin");
            System.out.println("5. Thoat");
            System.out.print("Chọn một tùy chọn: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch(choice){
                case 1:
                    System.out.print("Nhập loại phương tiện (oto, xe may, xe tai): ");
                    String type = scanner.nextLine();
                    System.out.print("Nhập ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Nhập Hãng Sản Xuất: ");
                    String hangSanXuat = scanner.nextLine();
                    System.out.print("Nhập Năm Sản Xuất: ");
                    int namSanXuat = scanner.nextInt();
                    System.out.print("Nhập Giá Bán: ");
                    double giaBan = scanner.nextDouble();
                    System.out.print("Nhập Màu Xe: ");
                    scanner.nextLine();
                    String mauXe = scanner.nextLine();

                    if (type.equalsIgnoreCase("oto")){
                        System.out.print("Nhập Số Chỗ Ngồi: ");
                        int soChoNgoi = scanner.nextInt();
                        System.out.print("Nhập Kiểu Động Cơ: ");
                        scanner.nextLine();
                        String kieuDongCo = scanner.nextLine();
                        qlptgt.themPhuongTien(new Car(id, hangSanXuat, namSanXuat, giaBan, mauXe, soChoNgoi, kieuDongCo));
                    } else if (type.equalsIgnoreCase("xe may")) {
                        System.out.print("Nhập Công Suất: ");
                        double congSuat = scanner.nextDouble();
                        qlptgt.themPhuongTien(new Motorcycle(id, hangSanXuat, namSanXuat, giaBan, mauXe, congSuat));
                    } else if (type.equalsIgnoreCase("xe tai")) {
                        System.out.print("Nhập Trọng Tải: ");
                        double trongTai = scanner.nextDouble();
                        qlptgt.themPhuongTien(new Truck(id, hangSanXuat, namSanXuat, giaBan, mauXe, trongTai));
                    } else {
                        System.out.println("Loại phương tiện không hợp lệ.");
                    }
                    break;
                case 2:
                    System.out.print("Nhập ID để xóa: ");
                    String removeID = scanner.nextLine();
                    qlptgt.xoaPhuongTien(removeID);
                    break;
                case 3:
                    System.out.print("Nhập Hãng Sản Xuất: ");
                    String searchHangSanXuat = scanner.nextLine();
                    System.out.print("Nhập Màu Xe: ");
                    String searchMauXe = scanner.nextLine();
                    qlptgt.timPhuongTien(searchHangSanXuat,searchMauXe);
                    break;
                case 4:
                    qlptgt.hienThiThongTin();
                    break;
                case 5:
                   qlptgt.thoat();
                   break;
                default:
                    System.out.println("Tùy chọn không hợp lệ. Vui lòng thử lại.");
                    break;
            }
        }
    }
}
