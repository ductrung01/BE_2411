package Buoi9.Bai3;

public class Car extends Vehicle{
    private int soChoNgoi;
    private String kieuDongCo;

    public Car(String id,String hangSanXuat,int namSanXuat, double giaBan, String mauXe, int soChoNgoi, String kieuDongCo){
        super(id,hangSanXuat,namSanXuat,giaBan,mauXe);
        this.soChoNgoi = soChoNgoi;
        this.kieuDongCo=kieuDongCo;
    }

    public int getSoChoNgoi() {
        return soChoNgoi;
    }

    public String getKieuDongCo() {
        return kieuDongCo;
    }

    @Override
    public String toString() {
        return super.toString()+ ", Số Chỗ Ngồi: " + soChoNgoi + ", Kiểu Động Cơ: " + kieuDongCo;
    }
}
