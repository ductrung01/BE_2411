package Buoi9.Bai2;

public class Phong {
    private int soNgayThue;
    private char loaiPhong;
    private Nguoi khachThue;

    public Phong(int soNgayThue, char loaiPhong, Nguoi khachThue) {
        this.soNgayThue = soNgayThue;
        this.loaiPhong = loaiPhong;
        this.khachThue = khachThue;
    }
    public int getSoNgayThue() {
        return soNgayThue;
    }
    public char getLoaiPhong() {
        return loaiPhong;
    }
    public Nguoi getKhachThue() {
        return khachThue;
    }

    public double getGiaPhong(){
        switch(loaiPhong){
            case 'A':
                return 500;
            case 'B':
                return 300;
            case 'C':
                return 100;
            default:
                throw new IllegalArgumentException("Loai phong khong hop le");
        }
    }

    @Override
    public String toString() {
        return "Phòng loại: " + loaiPhong + ", Số ngày thuê: " + soNgayThue + ", Khách thuê: [" + khachThue + "]";
    }
}
