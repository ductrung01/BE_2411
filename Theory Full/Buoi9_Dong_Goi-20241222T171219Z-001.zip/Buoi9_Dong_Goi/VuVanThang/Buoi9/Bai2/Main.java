package Buoi9.Bai2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        KhachSan khachSan = new KhachSan(100);

        while(true){
            System.out.println("=====MENU=====");
            System.out.println("1. Thêm khách thuê phòng");
            System.out.println("2. Xóa khách theo số CMND");
            System.out.println("3. Tính tiền thuê phòng theo số CMND");
            System.out.println("4. Hiển thị thông tin các phòng");
            System.out.println("5. Thoát");
            System.out.print("Chọn chức năng: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice){
                case 1:
                    System.out.print("Nhập số lượng phòng muốn thuê: ");
                    int soLuongPhongThue = Integer.parseInt(scanner.nextLine());
                    for (int i = 0; i < soLuongPhongThue; i++) {
                        System.out.println("\nNhập thông tin cho phòng thứ " + (i + 1) + ":");
                        System.out.print("Nhập họ tên: ");
                        String hoTen = scanner.nextLine();
                        System.out.print("Nhập tuổi: ");
                        int tuoi = Integer.parseInt(scanner.nextLine());
                        System.out.print("Nhập số CMND: ");
                        String soCMND = scanner.nextLine();
                        System.out.print("Nhập số ngày thuê: ");
                        int soNgayThue = Integer.parseInt(scanner.nextLine());
                        char loaiPhong;
                        do {
                            System.out.print("Nhập loại phòng (A/B/C): ");
                            loaiPhong = scanner.nextLine().toUpperCase().charAt(0);
                            if (loaiPhong != 'A' && loaiPhong != 'B' && loaiPhong != 'C') {
                                System.out.println("Loại phòng không hợp lệ. Vui lòng nhập lại.");
                            }
                        } while (loaiPhong != 'A' && loaiPhong != 'B' && loaiPhong != 'C');
                        Nguoi nguoiThue = new Nguoi(hoTen, tuoi, soCMND);
                        Phong phong = new Phong(soNgayThue, loaiPhong, nguoiThue);
                        khachSan.themPhong(phong);
                    }
                    break;
                case 2:
                    System.out.print("Nhập số CMND của khách cần xóa: ");
                    String soCMNDXoa = scanner.nextLine();
                    khachSan.xoaKhachTheoCMND(soCMNDXoa);
                    break;
                case 3:
                    System.out.print("Nhập số CMND của khách cần tính tiền: ");
                    String soCMNDTinhTien = scanner.nextLine();
                    khachSan.tinhTienThuePhong(soCMNDTinhTien);
                    break;
                case 4:
                    khachSan.hienThiThongTin();
                    break;
                case 5:
                    System.out.println("Thoát chương trình.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
                    break;
            }
        }
    }

}
