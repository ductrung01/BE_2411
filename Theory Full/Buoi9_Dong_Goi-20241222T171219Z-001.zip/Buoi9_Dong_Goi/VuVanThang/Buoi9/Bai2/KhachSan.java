package Buoi9.Bai2;

import java.util.Scanner;

public class KhachSan {
    private Phong[] danhSachPhong;
    private int soLuongPhong;

    public KhachSan(int SoLuongPhong) {
        this.danhSachPhong=new Phong[SoLuongPhong];
        this.soLuongPhong=0;
    }

    public void themPhong(Phong phong){
        if (soLuongPhong<danhSachPhong.length){
            danhSachPhong[soLuongPhong++]=phong;
            System.out.println("Them phong thanh cong.");
        }else{
            System.out.println("Khach san da day, khong the them phong");
        }
    }
    public void xoaKhachTheoCMND(String soCMND){
        for (int i = 0; i<soLuongPhong;i++){
            if (danhSachPhong[i].getKhachThue().getSoCMND().equals(soCMND)){
               danhSachPhong[i]=null;
               soLuongPhong--;
               System.out.println("Da xoa khach co so CMND "+soCMND);
               return;
            }
        }
        System.out.println("Khong tim thay khach co so CMND"+soCMND);
    }

    public void tinhTienThuePhong(String soCMND){
        for (int i = 0; i<soLuongPhong;i++){
            if (danhSachPhong[i].getKhachThue().getSoCMND().equals(soCMND)){
                double tienThue = danhSachPhong[i].getSoNgayThue()*danhSachPhong[i].getGiaPhong();
                System.out.println("Khach co so CMND: "+soCMND + " phai tra: "+tienThue+"$");
                return;
            }
        }
        System.out.println("Khong tim thay khach co so CMND "+soCMND);
    }

    public void hienThiThongTin(){
        if (soLuongPhong ==0){
            System.out.println("Khong co phong nao.");
        }else {
            for (int i=0; i<soLuongPhong;i++){
                System.out.println(danhSachPhong[i]);
            }
        }
    }
}
