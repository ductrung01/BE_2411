package Buoi9.Bai2;

public class Nguoi {
    private String hoTen;
    private int tuoi;
    private String soCMND;

    public Nguoi(String hoTen, int tuoi, String soCMND) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.soCMND = soCMND;
    }

    public String getHoTen() {
        return hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public String getSoCMND() {
        return soCMND;
    }

    @Override
    public String toString() {
        return "Họ tên: " + hoTen + ", Tuổi: " + tuoi + ", Số CMND: " + soCMND;
    }
}

