package org.example.Exercises.Lesson9.Bai1;


import java.util.Scanner;

public class HoGiaDinh {
    private Integer soThanhVien;
    private Integer soNha;
    private Nguoi[] thanhVien;
    private Integer chiSiSoHienTai;

    public HoGiaDinh(Integer soThanhVien, Integer soNha) {
        this.soThanhVien = soThanhVien;
        this.soNha = soNha;
        this.thanhVien = new Nguoi[this.soThanhVien];
        this.chiSiSoHienTai = 0;
    }

    public Integer getSoThanhVien() {
        return soThanhVien;
    }

    public void setSoThanhVien(Integer soThanhVien) {
        this.soThanhVien = soThanhVien;
    }

    public Integer getSoNha() {
        return soNha;
    }

    public void setSoNha(Integer soNha) {
        this.soNha = soNha;
    }

    public Nguoi[] getThanhVien() {
        return thanhVien;
    }

    public void setThanhVien(Nguoi[] thanhVien) {
        this.thanhVien = thanhVien;
    }

    public Integer getChiSiSoHienTai() {
        return chiSiSoHienTai;
    }

    public void setChiSiSoHienTai(Integer chiSiSoHienTai) {
        this.chiSiSoHienTai = chiSiSoHienTai;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        System.out.println("Thông tin hộ các hộ gia đình: ");
        sb.append("Số nhà: ").append(this.soNha).append(", Số thành viên của gia đình đó là: \n").append(this.soThanhVien)
                .append("\n Thành viên của hộ gia đình đó là: ");

        for (int i = 0; i < this.soThanhVien; i++){
            sb.append(this.thanhVien[i]).append("\n");
        }
        return sb.toString();
    }

    public void themThanhVien(Nguoi nguoi){
        if (this.chiSiSoHienTai < this.soThanhVien){
            this.thanhVien[this.chiSiSoHienTai] = nguoi;
            this.chiSiSoHienTai++;
        }
        else {
            System.out.println("Số lượng thành vien vượt quá so lượng quy định");
        }
    }


    }

