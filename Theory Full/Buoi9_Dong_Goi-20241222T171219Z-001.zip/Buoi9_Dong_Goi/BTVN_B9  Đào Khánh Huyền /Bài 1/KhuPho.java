package org.example.Exercises.Lesson9.Bai1;


import java.util.Scanner;

public class KhuPho {
    private HoGiaDinh[] hoGiaDinhs;
    private Integer chiSiSoHienTai;

    public KhuPho(Integer soHoDan) {
        this.hoGiaDinhs = new HoGiaDinh[soHoDan];
        this.chiSiSoHienTai = 0;
    }

    public HoGiaDinh[] getHoGiaDinhs() {
        return hoGiaDinhs;
    }

    public void setHoGiaDinhs(HoGiaDinh[] hoGiaDinhs) {
        this.hoGiaDinhs = hoGiaDinhs;
    }

    public Integer getChiSiSoHienTai() {
        return chiSiSoHienTai;
    }

    public void setChiSiSoHienTai(Integer chiSiSoHienTai) {
        this.chiSiSoHienTai = chiSiSoHienTai;
    }


    public void themThongTinHoGiaDinh(HoGiaDinh hoGiaDinh){
                if (this.chiSiSoHienTai < this.hoGiaDinhs.length){
                    this.hoGiaDinhs[this.chiSiSoHienTai] = hoGiaDinh;
                    this.chiSiSoHienTai++;

                }
                else {
                    System.out.println("Khong the them ho gia dinh vi khu pho khong the chua");
                }

    }

    public void hienThiThongTin(){
        if (this.chiSiSoHienTai == 0){
            System.out.println("Khu pho nay khong co nguoi");
        }
        for (int i = 0; i < this.chiSiSoHienTai; i++){
            System.out.println(hoGiaDinhs[i].toString());
        }
    }


    public void timKiemThongTinHoGiaDinhTheoTen(String ten){
        if (ten == null){
            System.out.println("Vui long nhap thong tin cho ten de tim kiem");
        }

        boolean found = false;
        if (ten != null){
            for (HoGiaDinh hoGiaDinh : hoGiaDinhs) {
                for (Nguoi nguoi : hoGiaDinh.getThanhVien()) {
                    if (nguoi.getHoTen().toLowerCase().contains(ten.toLowerCase())){
                        System.out.println(hoGiaDinh.toString());
                    }
                }
            }

        }
        if (!found){
            System.out.println("Khong tim thay thong tin");
        }
    }

    public void nhapThongTin(Scanner scanner){
        System.out.print("Nhập số lượng thành viên trong gia đình: ");
        int soThanhVien = scanner.nextInt();
        System.out.print("Nhập số nhà: ");
        int soNha = scanner.nextInt();
        scanner.nextLine();

        HoGiaDinh hoGiaDinh = new HoGiaDinh(soThanhVien, soNha);

        for (int j = 0; j < soThanhVien; j++) {
            System.out.println("Nhập thông tin thành viên thứ " + (j + 1) + ": ");
            System.out.print("Nhập họ tên: ");
            String hoTen = scanner.nextLine();
            System.out.print("Nhập tuổi: ");
            int tuoi = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Nhập nghề nghiệp: ");
            String ngheNghiep = scanner.nextLine();
            System.out.print("Nhập số chứng minh nhân dân: ");
            String cmnd = scanner.nextLine();

            Nguoi nguoi = new Nguoi(hoTen, tuoi, ngheNghiep, cmnd);
            hoGiaDinh.themThanhVien(nguoi);
        }

        this.themThongTinHoGiaDinh(hoGiaDinh);
    }



}
