package org.example.Exercises.Lesson9.Bai1;

import java.util.Scanner;


//
//Bài 1: Để quản lý các hộ dân cư trong một khu phố, người ta cần các thông tin sau:
//Số thành viên trong gia đình, Số nhà, thông tin mỗi cá nhân trong gia đình(Hộ gia định).
//Với mỗi cá nhân, người ta quản lý các thông tin sau:
//	Họ tên, Tuổi, Nghề nghiệp, số chứng minh nhân dân(duy nhất cho mỗi người).
//Yêu cầu 1: Hãy xây dựng lớp Nguoi để quản lý thông tin của mỗi cá nhân.
//Yêu cầu 2: Xây dựng lớp HoGiaDinh để quản lý thông tin của từng ngưòi.
//Yêu cầu 2: Xây dựng lớp KhuPho để quản lý các thông tin của từng hộ gia đình.
//Yêu cầu 3: Xây dựng các chức năng
//	a) Nhập n hộ dân. (n nhập từ bàn phím),
//	b) hiển thị thông tin của các hộ trong khu phố.
//	c) Cho phép tìm kiếm gần đúng hộ gia dình dựa vào tên của thành viên trong gia đìngh
//		vd: hộ gia đinh có người tên Nguyễn Đắc Kiên
//			=> nhập N, Nguyễn, nguyễn đắc, NGUYỄN ĐẮC KIÊN => đều có thể tìm được ra các thông tin:
//			Số thành viên trong gia đình, Số nhà của gia đình đó
//	d) thoát chương trình
//

public class Test {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
        System.out.print("Nhap so ho dan: ");
        int soHoDan = scanner.nextInt();

        KhuPho khuPho = new KhuPho(soHoDan);
        System.out.println();
        while (true) {
            System.out.println("1. Them thong tin thanh vien cua ho gia dinh trong khu pho");
            System.out.println("2. Hiển thị thông tin các hộ trong khu phố");
            System.out.println("3. Tìm kiếm hộ gia đình dựa vào tên thành viên");
            System.out.println("4. Thoát");
            System.out.print("Chọn chức năng: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    khuPho.nhapThongTin(scanner);
                    break;
                case 2:
                    khuPho.hienThiThongTin();
                    break;
                case 3:
                    scanner.nextLine();
                    System.out.println("Nhap ten: ");
                    String ten = scanner.nextLine();
                    khuPho.timKiemThongTinHoGiaDinhTheoTen(ten);
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
            }
        }
}
}
