package org.example.Exercises.Lesson9.Bai2;


import java.util.Objects;

public class QLPTGT {

    private PhuongTien[] phuongTiens;
    private Integer chiSoHienTai;

    public QLPTGT(Integer soLuongPhuongTien) {
        this.phuongTiens = new PhuongTien[soLuongPhuongTien];
        this.chiSoHienTai = 0;
    }

    public PhuongTien[] getPhuongTiens() {
        return phuongTiens;
    }

    public void setPhuongTiens(PhuongTien[] phuongTiens) {
        this.phuongTiens = phuongTiens;
    }

    public Integer getChiSoHienTai() {
        return chiSoHienTai;
    }

    public void setChiSoHienTai(Integer chiSoHienTai) {
        this.chiSoHienTai = chiSoHienTai;
    }

    public void themPhuongTien(PhuongTien phuongTien){
        if (this.chiSoHienTai < this.phuongTiens.length){
            this.phuongTiens[this.chiSoHienTai] = phuongTien;
            this.chiSoHienTai++;
            System.out.println("Da them thanh cong");
        }
        else {
            System.out.println("So phuong tien luu tru da day, khong the them");
        }

    }

    public void xoaPhuongTienTheoId(Integer id){
        if (id == null){
            System.out.println("Vui long nhap thong tin id");
        }

        boolean found = false;

        for (int i = 0; i < this.chiSoHienTai; i++){
            if (Objects.equals(this.phuongTiens[i].getId(), id)){
                found = true;
                for (int j = i; j < this.chiSoHienTai; j++){
                    this.phuongTiens[i] = this.phuongTiens[j + 1];
                }
                this.phuongTiens[this.chiSoHienTai - 1] = null;
                this.chiSoHienTai--;
                System.out.println("Da xoa thanh cong");
                return;
            }
        }
        System.out.println("Khong tim thay thong tin id hop le, vui long nhap lai");

    }

    public void timPhuongTienTheoMau(String mau){
        if (mau == null){
            System.out.println("Vui long nhap thong tin mau sac de tim kiem");
        }

        boolean found = false;

            for (int i = 0; i < this.chiSoHienTai; i++){
                if(phuongTiens[i].getMauXe().equalsIgnoreCase(mau)){
                    System.out.println(phuongTiens[i].toString());
                }
            }

            if (!found){
                System.out.println("Vui long nhap thong tin hop le");
        }


    }

    public void timPhuongTienTheoHangSanXuat(String hangSanXuat) {

        boolean found = false;

        if (hangSanXuat == null) {
            System.out.println("Vui long nhap thong tin hang sang xuat de tim kiem");
        }

        for (int i = 0; i < this.chiSoHienTai; i++) {
            if (phuongTiens[i].getHangSanXuat().equalsIgnoreCase(hangSanXuat)) {
                System.out.println(phuongTiens[i].toString());
                found = true;
            }
        }

        if (!found){
            System.out.println("Vui long nhap thong tin hang san xuat hop le");
    }


    }

    public void hienThiThongTin(){
        for (int i = 0; i < this.chiSoHienTai; i++){
            System.out.println(phuongTiens[i].toString());
        }
    }

}
