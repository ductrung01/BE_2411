package org.example.Exercises.Lesson9.Bai2;
//Nghành công an cần quản lý các phương tiện giao thông gồm:
//ô tô, xe máy, xe tải. Mỗi loại gồm các thông tin: ID, Hãng sản xuất, năm sản xuất, giá bán và màu xe.
//Các ô tô có các thuộc tính riêng: số chỗ ngồi, kiểu động cơ.
//Các xe máy có các thuộc tính riêng: công xuất.
//Xe tải cần quản lý thêm: Trọng tải.
//Yêu cầu 1: Xây dựng các lớp để quản lý các phương tiện trên sao cho hiệu quả.
//Yêu cầu 2: Xây dựng lớp QLPTGT có các chức năng:
//	1) Thêm, xoá(theo ID) các phương tiện thuộc các loại trên.
//	2) Tìm phương tiện theo hãng sản xuất, màu.
//	3) Thoát chương trình.
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhap so luong luu tru phuong tien: ");
        int soLuongLuuTru = scanner.nextInt();

        QLPTGT qlptgt = new QLPTGT(soLuongLuuTru);

        while (true) {
            System.out.println("Vui long chon chuc nang");
            System.out.println("1. Them thong tin phuong tien");
            System.out.println("2. Xoa thong tin phuong tien theo id");
            System.out.println("3. Tim kiem phuong tien theo hang san xuat");
            System.out.println("4. Tim kiem phuong tien theo mau");
            System.out.println("5. Hien thi thong tin phuong tien");
            System.out.println("6. Thoat chuong trinh");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:

                    System.out.println("Chon loai phuong tien tien ma ban muon them: ");
                    System.out.println("1. Them thong tin oto");
                    System.out.println("2. Them thong tin xe may");
                    System.out.println("3. Them thong tin xe tai");

                    int chon = scanner.nextInt();
                    System.out.print("Nhap id: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nhap hang san xuat: ");
                    String hangSanXuat = scanner.nextLine();
                    System.out.print("Nhap nam san xuat: ");
                    Long namSanXuat = scanner.nextLong();
                    System.out.print("Nhap gia ban: ");
                    Double giaBan = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Nhap mau xe: ");
                    String mauXe = scanner.nextLine();

                        if (chon == 1){
                            System.out.print("Nhap so cho ngoi: ");
                            int soChoNgoi = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Nhap kieu dong co: ");
                            String kieuDongCo = scanner.nextLine();
                            Oto oto = new Oto(id, hangSanXuat, namSanXuat, giaBan, mauXe, soChoNgoi, kieuDongCo);
                            qlptgt.themPhuongTien(oto);
                        }
                        else if (chon == 2){
                            System.out.print("Nhap cong suat: ");
                            int congSuat = scanner.nextInt();
                            XeMay xeMay = new XeMay(id, hangSanXuat, namSanXuat, giaBan, mauXe, congSuat);
                            qlptgt.themPhuongTien(xeMay);
                        }
                        else if (chon == 3){
                            System.out.print("Nhap trong tai: ");
                            int trongTai = scanner.nextInt();
                            XeTai xeTai = new XeTai(id, hangSanXuat, namSanXuat, giaBan, mauXe, trongTai);
                            qlptgt.themPhuongTien(xeTai);
                        }
                    break;
                case 2:
                    System.out.println("Nhap thong tin id phuong tien muon xoa: ");
                    int idXoa = scanner.nextInt();
                    qlptgt.xoaPhuongTienTheoId(idXoa);
                    break;
                case 3:
                    System.out.print("Vui long nhap thong tin hang san xuat: ");
                    String hang = scanner.nextLine();
                    qlptgt.timPhuongTienTheoHangSanXuat(hang);
                    break;
                case 4:
                    System.out.println("Vui long nhap thong tin mau xe: ");
                    String mau = scanner.nextLine();
                    qlptgt.timPhuongTienTheoMau(mau);
                    break;
                case 5:
                    qlptgt.hienThiThongTin();
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
            }
        }
    }
}
