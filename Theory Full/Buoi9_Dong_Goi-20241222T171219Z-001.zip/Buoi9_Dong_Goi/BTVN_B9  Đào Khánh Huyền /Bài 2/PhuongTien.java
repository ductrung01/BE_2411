package org.example.Exercises.Lesson9.Bai2;


public class PhuongTien {
    private Integer id;
    private String hangSanXuat;
    private Long namSanXuat;
    private Double giaBan;
    private String mauXe;


    public PhuongTien(Integer id, String hangSanXuat, Long namSanXuat, Double giaBan, String mauXe) {
        this.id = id;
        this.hangSanXuat = hangSanXuat;
        this.namSanXuat = namSanXuat;
        this.giaBan = giaBan;
        this.mauXe = mauXe;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHangSanXuat() {
        return hangSanXuat;
    }

    public void setHangSanXuat(String hangSanXuat) {
        this.hangSanXuat = hangSanXuat;
    }

    public Long getNamSanXuat() {
        return namSanXuat;
    }

    public void setNamSanXuat(Long namSanXuat) {
        this.namSanXuat = namSanXuat;
    }

    public Double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(Double giaBan) {
        this.giaBan = giaBan;
    }

    public String getMauXe() {
        return mauXe;
    }

    public void setMauXe(String mauXe) {
        this.mauXe = mauXe;
    }

    @Override
    public String toString() {
        return "PhuongTien{" +
                "id=" + id +
                ", hangSanXuat='" + hangSanXuat + '\'' +
                ", namSanXuat=" + namSanXuat +
                ", giaBan=" + giaBan +
                ", mauXe='" + mauXe + '\'' +
                '}';
    }
}
