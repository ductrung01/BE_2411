package org.example.Exercises.Lesson9.Bai2;


public class XeMay extends PhuongTien{

    private Integer congSuat;


    public XeMay(Integer id, String hangSanXuat, Long namSanXuat, Double giaBan, String mauXe, Integer congSuat) {
        super(id, hangSanXuat, namSanXuat, giaBan, mauXe);
        this.congSuat = congSuat;
    }

    public Integer getCongSuat() {
        return congSuat;
    }

    public void setCongSuat(Integer congSuat) {
        this.congSuat = congSuat;
    }

    @Override
    public String toString() {
        return "XeMay{" +
                super.toString() +
                "congSuat=" + congSuat +
                '}';
    }
}
