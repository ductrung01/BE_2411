package org.example.Exercises.Lesson9.Bai2;

public class XeTai extends PhuongTien{
    private Integer trongTai;


    public XeTai(Integer id, String hangSanXuat, Long namSanXuat, Double giaBan, String mauXe, Integer trongTai) {
        super(id, hangSanXuat, namSanXuat, giaBan, mauXe);
        this.trongTai = trongTai;
    }

    public Integer getTrongTai() {
        return trongTai;
    }

    public void setTrongTai(Integer trongTai) {
        this.trongTai = trongTai;
    }

    @Override
    public String toString() {
        return "XeTai{" +
                super.toString() +
                "trongTai=" + trongTai +
                '}';
    }
}
