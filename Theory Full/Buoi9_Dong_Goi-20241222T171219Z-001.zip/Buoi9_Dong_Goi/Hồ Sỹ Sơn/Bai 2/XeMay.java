package com.t3h.buoi9.bai2;

public class XeMay extends XeCo {
    private int congSuat;
    public XeMay(String iD,String hangSanXuat, int namSanXuat,int giaBan, String mauXe, int congSuat){
        super(iD, hangSanXuat, namSanXuat, giaBan, mauXe);
        this.congSuat = congSuat;
    }
    public int getCongSuat(){
        return congSuat;
    }
    public void setCongSuat(int congSuat){this.congSuat = congSuat;}
    @Override
    public String toString(){
        return
                super.toString()+", Công suất= "+congSuat;
    }
}
