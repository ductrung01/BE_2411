package com.t3h.buoi9.bai2;


import java.util.Scanner;

public class QuanLyPhuongTien {
    private XeCo[] danhSachXe;
    private int soLuongXe;
    public QuanLyPhuongTien(int kichThuoc){
        this.danhSachXe = new XeCo[kichThuoc];
        this.soLuongXe = 0;
    }
    public void themMoiPhuongTien(XeCo xeCo){
        if (soLuongXe < danhSachXe.length){
            danhSachXe[soLuongXe] = xeCo;
            soLuongXe++;
        }else {
            System.out.println("Số phương tiện đã đầy. Không thể thêm mới.");
        }
    }
    public void xoaPhuongTienTheoID(String iD){
        for (int i = 0; i < soLuongXe; i++) {
            if (danhSachXe[i].getiD().equals(iD)){
                for (int j = i; j < soLuongXe - 1; j++) {
                    danhSachXe[j] = danhSachXe[j+1];
                }
                soLuongXe--;
                return;
            }
        }
        System.out.println("Không tìm thấy xe với id: "+iD);
    }
    public void hienThiPhuongTien(){
        if (soLuongXe == 0){
            System.out.println("Danh sách phương tiện rỗng.");
        }else {
            for (int i = 0; i < soLuongXe; i++) {
                System.out.println(danhSachXe[i]);
            }
        }

    }
    public void timKiemPhuongTien(String hangSanXuat,String mauXe){
        boolean found = false;
        for (XeCo xeCo : danhSachXe){
            if (xeCo != null && xeCo.getHangSanXuat().equalsIgnoreCase(hangSanXuat) && xeCo.getMauXe().equalsIgnoreCase(mauXe)){
                System.out.println("Phương tiện tìm thấy: "+xeCo);
                found = true;
            }
        }
        if (!found){
            System.out.println("Không tìm thấy phương tiện nào với hãng sản xuất: "+hangSanXuat+" và màu xe: "+mauXe);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        QuanLyPhuongTien quanLyPhuongTien = new QuanLyPhuongTien(100);
        while (true){
            System.out.println("===MENU===");
            System.out.println("1.Thêm phương tiện mới.");
            System.out.println("2.Xóa phương tiện theo ID.");
            System.out.println("3.Tìm phương tiện theo hãng sản xuất và màu xe.");
            System.out.println("4.Hiển thị các phương tiện.");
            System.out.println("5.Thoát chương trình.");
            System.out.println("Chọn chức năng: ");
            int luaChon = scanner.nextInt();
            scanner.nextLine();
            switch (luaChon){
                /**
                 Mỗi loại gồm các thông tin: ID, Hãng sản xuất, năm sản xuất, giá bán và màu xe.
                 Các ô tô có các thuộc tính riêng: số chỗ ngồi, kiểu động cơ.
                 Các xe máy có các thuộc tính riêng: công xuất.
                 Xe tải cần quản lý thêm: Trọng tải.
                 */
                case 1:
                    System.out.println("Chọn loại phương tiện:"+"1.Ô tô."+"2.Xe máy."+"3.Xe tải.");
                    int loai = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Nhập ID: ");
                    String iD = scanner.nextLine();
                    System.out.println("Nhập hãng sản xuất: ");
                    String hangSanXuat = scanner.nextLine();
                    System.out.println("Nhập năm sản xuất: ");
                    int namSanXuat = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Nhập giá bán: ");
                    int giaBan = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Nhập màu xe: ");
                    String mauXe = scanner.nextLine();
                    if (loai == 1){
                        System.out.println("Nhập số chỗ ngồi: ");
                        int soChoNgoi = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("Nhập kiểu động cơ: ");
                        String kieuDongCo = scanner.nextLine();
                        Oto oto = new Oto(iD, hangSanXuat, namSanXuat, giaBan, mauXe, soChoNgoi, kieuDongCo);
                        quanLyPhuongTien.themMoiPhuongTien(oto);
                    }
                    else if (loai == 2){
                        System.out.println("Nhập công suất: ");
                        int congSuat = scanner.nextInt();
                        scanner.nextLine();
                        XeMay xeMay = new XeMay(iD, hangSanXuat, namSanXuat, giaBan, mauXe, congSuat);
                        quanLyPhuongTien.themMoiPhuongTien(xeMay);
                    }
                    else if (loai == 3){
                        System.out.println("Nhập trọng tải: ");
                        int trongTai = scanner.nextInt();
                        scanner.nextLine();
                        XeTai xeTai = new XeTai(iD, hangSanXuat, namSanXuat, giaBan, mauXe, trongTai);
                        quanLyPhuongTien.themMoiPhuongTien(xeTai);
                    }else {
                        System.out.println("Nhập sai loại.Vui lòng thử lại.");
                    }
                   break;
                case 2:
                    System.out.println("Nhập số ID của phương tiện cần xóa: ");
                    String iDXoa = scanner.nextLine();
                    quanLyPhuongTien.xoaPhuongTienTheoID(iDXoa);
                    break;
                case 3:
                    System.out.println("Nhập hãng sản xuất cần tìm kiêm: ");
                    String hangSanXuatTimKiem = scanner.nextLine();
                    System.out.println("Nhập màu xe cần tìm kiếm: ");
                    String mauXeTimKiem = scanner.nextLine();
                    quanLyPhuongTien.timKiemPhuongTien(hangSanXuatTimKiem,mauXeTimKiem);
                    break;
                case 4:
                    quanLyPhuongTien.hienThiPhuongTien();
                    break;
                case 5:
                    System.out.println("Chương trình kết thúc!");
                    return;
                default:
                    System.out.println("Nhập lựa chọn sai.Vui lòng thử lại.");
            }
        }
    }
}
