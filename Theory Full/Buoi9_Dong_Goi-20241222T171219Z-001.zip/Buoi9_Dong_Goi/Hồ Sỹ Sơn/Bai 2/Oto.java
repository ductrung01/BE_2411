package com.t3h.buoi9.bai2;

public class Oto extends XeCo {
    private int soChoNgoi;
    private String kieuDongCo;
    public Oto(String iD, String hangSanXuat, int namSanXuat, int giaBan, String mauXe, int soChoNgoi,String kieuDongCo){
        super(iD, hangSanXuat, namSanXuat, giaBan, mauXe);
        this.soChoNgoi = soChoNgoi;
        this.kieuDongCo = kieuDongCo;
    }
    public int getSoChoNgoi(){
        return soChoNgoi;
    }
    public void setSoChoNgoi(int soChoNgoi){this.soChoNgoi = soChoNgoi;}
    public String getKieuDongCo(){
        return kieuDongCo;
    }
    public void setKieuDongCo(String kieuDongCo){this.kieuDongCo = kieuDongCo;}
    @Override
    public String toString(){
        return
                super.toString()+", Số chỗ ngồi= "+soChoNgoi+", Kiểu động cơ: "+kieuDongCo;
    }
}
