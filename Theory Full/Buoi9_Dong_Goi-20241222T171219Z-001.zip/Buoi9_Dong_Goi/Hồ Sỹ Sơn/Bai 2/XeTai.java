package com.t3h.buoi9.bai2;

public class XeTai extends XeCo {
    private int trongTai;
    public XeTai(String iD,String hangSanXuat, int namSanXuat,int giaBan, String mauXe,int trongTai){
        super(iD, hangSanXuat, namSanXuat, giaBan, mauXe);
        this.trongTai = trongTai;
    }
    public int getTrongTai(){
        return trongTai;
    }
    public void setTrongTai(int trongTai){this.trongTai = trongTai;}
    @Override
    public String toString(){
        return
                super.toString()+", Trọng tải= "+trongTai;
    }
}
