package com.t3h.buoi9.bai2;

public class XeCo {
    private String iD;
    private String hangSanXuat;
    private int namSanXuat;
    private int giaBan;
    private String mauXe;
    public XeCo(String iD, String hangSanXuat, int namSanXuat, int giaBan, String mauXe){
        this.iD = iD;
        this.hangSanXuat = hangSanXuat;
        this.namSanXuat = namSanXuat;
        this.giaBan = giaBan;
        this.mauXe = mauXe;
    }
    public String getiD(){
        return iD;
    }
    public void setiD(String iD){
        this.iD = iD;
    }
    public String getHangSanXuat(){
        return hangSanXuat;
    }
    public void setHangSanXuat(String hangSanXuat){
        this.hangSanXuat = hangSanXuat;
    }
    public int getNamSanXuat(){
        return namSanXuat;
    }
    public void setNamSanXuat(int namSanXuat){
        this.namSanXuat = namSanXuat;
    }
    public int getGiaBan(){
        return giaBan;
    }
    public void setGiaBan(int giaBan){
        this.giaBan = giaBan;
    }
    public String getMauXe(){
        return mauXe;
    }
    public void setMauXe(String mauXe){
        this.mauXe = mauXe;
    }
    @Override
    public String toString(){
        return
                "ID= "+iD+", Hãng sản xuất: "+hangSanXuat+", Năm sản xuất: "+namSanXuat+", Giá bán= "+giaBan+
                        ", Màu xe: "+mauXe;
    }
}
