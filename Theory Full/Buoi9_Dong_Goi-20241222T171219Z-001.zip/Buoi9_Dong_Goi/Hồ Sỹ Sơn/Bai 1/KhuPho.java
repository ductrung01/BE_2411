package com.t3h.buoi9.bai1;

import java.util.Scanner;

public class KhuPho {
    private HoGiaDinh[] danhSachHoGiaDinh;
    private int soHoGiaDinh;

    public KhuPho(int soHoGiaDinh) {
        this.soHoGiaDinh = soHoGiaDinh;
        this.danhSachHoGiaDinh = new HoGiaDinh[soHoGiaDinh];
    }

    public void nhapThongTin() {
        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < soHoGiaDinh; i++) {
            System.out.println("Nhập thông tin cho hộ gia đình thứ " + (i + 1) + ":");
            System.out.print("Nhập số thành viên: ");
            int soThanhVien = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Nhập số nhà: ");
            String soNha = scanner.nextLine();

            HoGiaDinh hoGiaDinh = new HoGiaDinh(soThanhVien, soNha);

            for (int j = 0; j < soThanhVien; j++) {
                System.out.println("Nhập thông tin cho thành viên thứ " + (j + 1) + ":");
                System.out.print("Nhập họ tên: ");
                String hoTen = scanner.nextLine();
                System.out.print("Nhập tuổi: ");
                int tuoi = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Nhập nghề nghiệp: ");
                String ngheNghiep = scanner.nextLine();
                System.out.print("Nhập số CMND: ");
                String soCMND = scanner.nextLine();

                Nguoi nguoi = new Nguoi(hoTen, tuoi, ngheNghiep, soCMND);
                hoGiaDinh.getDanhSachThanhVien()[j] = nguoi;
            }

            danhSachHoGiaDinh[i] = hoGiaDinh;
        }
    }

    public void hienThiThongTin() {
        for (HoGiaDinh hoGiaDinh : danhSachHoGiaDinh) {
            if (hoGiaDinh != null) {
                System.out.println(hoGiaDinh);
            }
        }
    }

    public void timKiemHoGiaDinh(String ten) {
        boolean found = false;
        for (HoGiaDinh hoGiaDinh : danhSachHoGiaDinh){
            if (hoGiaDinh != null){
                for (Nguoi nguoi : hoGiaDinh.getDanhSachThanhVien()){
                    if (nguoi.getHoTen().toLowerCase().contains(ten.toLowerCase())){
                        System.out.println("Hộ gia đình có thành viên tên: "+ten);
                        System.out.println(" Số nhà: "+hoGiaDinh.getSoNha()+", Số thành viên: "+hoGiaDinh.getSoThanhVien());
                        found = true;
                        break;
                    }
                }
            }
        }
        if (!found){
            System.out.println("Không tìm thấy hộ gia đình nào có thành viên tên: "+ten);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhập số hộ gia đình: ");
        int soHoGiaDinh = scanner.nextInt();
        scanner.nextLine();
        KhuPho khuPho = new KhuPho(soHoGiaDinh);
        khuPho.nhapThongTin();
        while (true){
            System.out.println("===MENU===");
            System.out.println("1.Hiển thị thông tin các hộ gia đình trong khu phố.");
            System.out.println("2.Tìm kiếm hộ gia đình theo tên.");
            System.out.println("3.Thoát chương trình.");
            System.out.println("Chọn chức năng: ");
            int luaChon = scanner.nextInt();
            scanner.nextLine();
            switch (luaChon){
                case 1:
                    khuPho.hienThiThongTin();
                    break;
                case 2:
                    System.out.println("Nhập tên thành viên để tìm kiếm hộ gia đình: ");
                    String ten = scanner.nextLine();
                    khuPho.timKiemHoGiaDinh(ten);
                    break;
                case 3:
                    System.out.println("Chương trình kết thúc!");
                    return;
                default:
                    System.out.println("Nhập sai lựa chọn. Vui lòng thử lại.");
            }
        }
    }

}
