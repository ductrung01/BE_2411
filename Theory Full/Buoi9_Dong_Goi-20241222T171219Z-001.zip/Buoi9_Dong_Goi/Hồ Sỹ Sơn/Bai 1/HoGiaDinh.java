package com.t3h.buoi9.bai1;

public class HoGiaDinh {
    private int soThanhVien;
    private String soNha;
    private Nguoi[] danhSachThanhVien;

    public HoGiaDinh(int soThanhVien, String soNha) {
        this.soThanhVien = soThanhVien;
        this.soNha = soNha;
        this.danhSachThanhVien = new Nguoi[soThanhVien];
    }

    // Getters và Setters
    public int getSoThanhVien() {
        return soThanhVien;
    }

    public void setSoThanhVien(int soThanhVien) {
        this.soThanhVien = soThanhVien;
    }

    public String getSoNha() {
        return soNha;
    }

    public void setSoNha(String soNha) {
        this.soNha = soNha;
    }

    public Nguoi[] getDanhSachThanhVien() {
        return danhSachThanhVien;
    }

    public void setDanhSachThanhVien(Nguoi[] danhSachThanhVien) {
        this.danhSachThanhVien = danhSachThanhVien;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Số thành viên: ").append(soThanhVien).append(", Số nhà: ").append(soNha).append("\n");
        for (Nguoi nguoi : danhSachThanhVien) {
            sb.append(nguoi).append("\n");
        }
        return sb.toString();
    }
}
