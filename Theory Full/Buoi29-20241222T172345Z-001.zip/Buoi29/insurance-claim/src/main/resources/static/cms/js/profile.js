const urlBase = 'http://localhost:8080';

// được gọi khi load hoàn chỉnh được toàn bộ html
$(document).ready(function () {
    // gọi hàm get profile, setup thông tin lên html
    getProfile();

    // gắn sự khiện khi click vào button Saves Changes sẽ gọi tới api update thông tin profile, bao gồm cả ảnh avatar
    $('#formAccountSettings').submit(async function (e) {
        await updateUserInfo(e);
    });
});

function getProfile(){
    $.ajax({
        url: urlBase + '/resource/user/profile',
        type: 'GET',
        success: function(response) {
            console.log(response);
            if (response.code !== 200) {
                console.error('Error: Unable to fetch user profile');
                return;
            }
            const user = response.data;
            setUserToView(user);
        },
        error: function(error) {
            console.error('Error fetching user:', error);
        }
    });
}

function setUserToView(user) {
    // Đặt giá trị vào các trường input
    $('#username').val(user.username);
    $('#code').val(user.code);
    $('#email').val(user.email);
    $('#firstName').val(user.firstName);
    $('#lastName').val(user.lastName);
    $('#phone').val(user.phone);
    $('#address').val(user.address);
    $('#createdDate').val(user.createdDate);
    $('#createdBy').val(user.createdBy);
    $('#lastModifiedDate').val(user.lastModifiedDate);
    $('#lastModifiedBy').val(user.lastModifiedBy);
    // save userId to localStorage in font-end
    localStorage.setItem("userId", user.id);
    // set avatar
    const avatarUrl = user.pathAvatar; //http://localhost:8080/file/avatar/avatar_admin_1.jpg
    $('#uploadedAvatar').attr('src', avatarUrl);
}

async function updateUserInfo(e){
    e.preventDefault();

    let obj = {};

    // lấy ra hình ảnh, chuyển hình ảnh sang dangj string base64 -> gửi lên back-end
    // vd: tại câu lệnh obj.file = await toBase64($('#upload')[0].files[0]);
    // nếu không sử dụng await, async thì hàm toBase64 sẽ được tách ra một thread riêng và convert ảnh -> stirng base64 tại thread độc lập đấy
    // mà trong object obj cần stringbase64 img mới có thể gửi lên server => phải sử dụng await, async để chờ cho hàm xử lý
    // xong mới tiếp tục chạy các câu lệnh tiếp theo
    obj.file = await toBase64($('#upload')[0].files[0]);

    // lấy các value trên giao diện
    obj.username = $('#username').val();
    obj.code = $('#code').val();
    obj.email = $('#email').val();
    obj.firstName = $('#firstName').val();
    obj.lastName = $('#lastName').val();
    // get userId from localStorage
    obj.id=parseInt(localStorage.getItem("userId"));

    $.ajax({
        url: urlBase + '/resource/user/update', // For update
        type: 'PUT', // Use POST for creation
        contentType: 'application/json',
        data: JSON.stringify(obj),
        success: function (response) {
            alert('Profile updated successfully');
        },
        error: function (error) {
            alert('An error occurred: ' + error.responseText);
        }
    });
}
// show avatar sau khi upload lên html, nhưng chưa gửi ảnh lên server
document.getElementById('upload').addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById('uploadedAvatar').setAttribute('src', e.target.result);
        }
        reader.readAsDataURL(file);
    }
});

/**
 Promise : được sử dụng để lý bất đồng bổ
 vì quá trình chuyển từ file img -> stringBase64 mất nhiều gian và phải xử lý bất đồng bộ
 => sử dụng Promise để xử lý
 => tại nơi gọi hàm toBase64 phải thêm từ khóa await, và tại hàm to phải thêm từ khóa async
 cặp await, async => thể hiện việc sẽ chờ cho tời khi hàm xử lý bất đồng bộ xử lý xong mới thực hiện các câu lệnh phia sau
 vd: tại câu lệnh obj.file = await toBase64($('#upload')[0].files[0]);
 nếu không sử dụng await, async thì hàm toBase64 sẽ được tách ra một thread riêng và convert ảnh -> stirng base64 tại thread độc lập đấy
 mà trong object obj cần stringbase64 img mới có thể gửi lên server => phải sử dụng await, async để chờ cho hàm xử lý
 xong mới tiếp tục chạy các câu lệnh tiếp theo
 */
const toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
})