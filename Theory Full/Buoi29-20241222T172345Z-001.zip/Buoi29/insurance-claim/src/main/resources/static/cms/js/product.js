const urlBase = 'http://localhost:8080';

// chạy khi html load xong
$(document).ready(function () {
    getProductSlide();

    getProductRow();
});

function getProductRow() {
    $.ajax({
        url: urlBase + '/resource/product/slide',
        type: 'GET',
        success: function (response) {
            console.log(response);
            let productsDto = response.data;
            let productRow = $('#productRow');
            for (let i = 0; i < 3; i++) {
                let product = productsDto[i];
                let row = `<div className="col-md-4">
                                    <div className="cat-item image-zoom-effect">
                                        <div className="image-holder">
                                            <a href="products.html">
                                                <img src="${product.pathAvatar}" alt="categories"
                                                     className="product-image img-fluid"/>
                                            </a>
                                        </div>
                                        <div className="category-content">
                                            <div className="product-button">
                                                <a href="products.html" className="btn btn-common text-uppercase">${product.name}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>`
                productRow.append(row);
            }

        },
        error: function (error) {
            console.error('Error fetching user:', error);
        }
    });
}

function getProductSlide() {
    $.ajax({
        url: urlBase + '/resource/product/slide',
        type: 'GET',
        success: function (response) {
            console.log(response);
            let productsDto = response.data;
            let slideProduct = $('#slideProduct');
            for (let i = 0; i < productsDto.length; i++) {
                let product = productsDto[i];
                let row = `<div class="swiper-slide">
                                  <div class="banner-item image-zoom-effect">
                                    <div class="image-holder">
                                      <a href="#">
                                        <img src="${product.pathAvatar}" alt="product" class="img-fluid">
                                      </a>
                                    </div>
                                    <div class="banner-content py-4">
                                      <h5 class="element-title text-uppercase">
                                        <a href="products.html" class="item-anchor">${product.name}</a>
                                      </h5>
                                      <p>${product.description}</p>
                                      <div class="btn-left">
                                        <a href="#" class="btn-link fs-6 text-uppercase item-anchor text-decoration-none">Discover Now</a>
                                      </div>
                                    </div>
                                  </div>
                                </div>`
                slideProduct.append(row);
            }

        },
        error: function (error) {
            console.error('Error fetching user:', error);
        }
    });
}



