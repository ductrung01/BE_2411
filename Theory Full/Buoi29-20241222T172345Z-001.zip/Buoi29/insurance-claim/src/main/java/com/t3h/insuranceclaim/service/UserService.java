package com.t3h.insuranceclaim.service;

import com.t3h.insuranceclaim.dto.UserDTO;
import com.t3h.insuranceclaim.dto.response.Response;

public interface UserService {
    UserDTO getUserByUsername(String username);

    Response<UserDTO> getProfileUser();

    UserDTO updateProfileUser(UserDTO userDTO);
}
