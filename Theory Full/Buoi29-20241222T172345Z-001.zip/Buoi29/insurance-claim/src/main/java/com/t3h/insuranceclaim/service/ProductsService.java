package com.t3h.insuranceclaim.service;

import com.t3h.insuranceclaim.dto.ProductsDTO;
import com.t3h.insuranceclaim.dto.response.Response;

import java.util.List;

public interface ProductsService {

    public Response<List<ProductsDTO>> getProductSlide();
}
