package com.t3h.insuranceclaim.service.impl;

import com.t3h.insuranceclaim.config.ApplicationConfig;
import com.t3h.insuranceclaim.dto.UserDTO;
import com.t3h.insuranceclaim.dto.response.Response;
import com.t3h.insuranceclaim.entity.UserEntity;
import com.t3h.insuranceclaim.mapper.UserMapper;
import com.t3h.insuranceclaim.repository.UserRepository;
import com.t3h.insuranceclaim.security.SecurityUtils;
import com.t3h.insuranceclaim.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Base64;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ApplicationConfig applicationConfig;

    @Autowired
    private UserMapper userMapper;

    @Value("${storage.avatar.relative.path}")
    private String avatarRelativePath;

    @Override
    public UserDTO getUserByUsername(String username) {
        UserEntity userEntity = userRepository.findByUsername(username);
        UserDTO userDTO = userMapper.toDto(userEntity);
        // Nếu user chưa có avatar lưu trong db. Sẽ lấy avatar mặc định
        if (StringUtils.isEmpty(userDTO.getPathAvatar())){
            userDTO.setPathAvatar(avatarRelativePath + FileServiceImpl.DEFAULT_FILE_NAME);
        }
        return userDTO;
    }
    @Override
    public Response<UserDTO> getProfileUser() {
        // lấy ra thông tin username của user đang đăng nhập
        String userCurrentUser = SecurityUtils.getCurrentUserName();

        // query và chuyển sang DTO
        UserDTO userDTO= getUserByUsername(userCurrentUser);
        Response<UserDTO> response = new Response<>();
        response.setData(userDTO);
        response.setCode(HttpStatus.OK.value());
        response.setMessage("Success");
        return response;
    }

    @Override
    public UserDTO updateProfileUser(UserDTO userDTO)  {
        // Lấy UserEntity từ database dựa trên userId
        UserEntity userEntity = userRepository.findById(userDTO.getId().intValue())
                .orElseThrow(() -> new RuntimeException("User not found"));

        handleAvatar(userDTO, userEntity);

        // 2) Convert dữ liệu từ userDTO sang userEntity
        userEntity.setFirstName(userDTO.getFirstName());
        userEntity.setLastName(userDTO.getLastName());
        userEntity.setEmail(userDTO.getEmail());
        userEntity.setCode(userDTO.getCode());
        userEntity.setLastModifiedDate(LocalDateTime.now());
        userEntity.setLastModifiedBy(userDTO.getUsername());
        userEntity.setAddress(userDTO.getAddress());
        userEntity.setPhone(userDTO.getPhone());

        // 3) Lưu UserEntity vào database
        userRepository.save(userEntity);

        // 4) Trả về UserDTO
        return userDTO;
    }

    private void handleAvatar(UserDTO userDTO, UserEntity userEntity) {
        // 1) Convert file base64 trong userDTO sang file ảnh và lưu vào thư mục cấu hình
        if (StringUtils.hasText(userDTO.getFile())) {
            // Chuỗi base64 có định dạng: data:image/jpeg;base64,...
            String base64String = userDTO.getFile();
            String[] parts = base64String.split(",");

            // Phần MIME type, ví dụ: data:image/jpeg;base64
            String mimeType = parts[0];

            // Phần dữ liệu thực sự Base64
            String base64Data = parts[1];

            // Giải mã Base64
            byte[] decodedBytes = Base64.getDecoder().decode(base64Data);

            // Xác định định dạng file từ MIME type (ví dụ: jpg, png)
            String fileExtension = "";
            if (mimeType.contains("image/jpeg")) {
                fileExtension = "jpg";
            } else if (mimeType.contains("image/png")) {
                fileExtension = "png";
            }
            // Lưu file vào folder của hệ thống, nhận về file name để thực hiện tạo ra đường dẫn tương đối
            String fileName = saveFileToFolder(userDTO, fileExtension, decodedBytes);
            String pathAvatarSaveDb = avatarRelativePath + fileName;
            // Set đường dẫn file avatar vào UserEntity
            userEntity.setPathAvatar(pathAvatarSaveDb);
        }
    }

    private String saveFileToFolder(UserDTO userDTO, String fileExtension, byte[] decodedBytes) {
        // Tạo đường dẫn đầy đủ cho file ảnh (rootFolder + tên file)
        String rootFolder = applicationConfig.getRootFolderAvatar();
        String fileName = "avatar_" + userDTO.getUsername() + "_" + userDTO.getId() + "." + fileExtension;
        String finalPath = rootFolder + fileName;

        // Kiểm tra và tạo thư mục nếu chưa tồn tại
        File folder = new File(rootFolder);
        if (!folder.exists()) {
            folder.mkdirs(); // Tạo tất cả các thư mục cần thiết nếu chúng chưa tồn tại
        }

        // Lưu file ảnh vào hệ thống
        try (FileOutputStream fos = new FileOutputStream(new File(finalPath))) {
            fos.write(decodedBytes);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        return fileName;
    }


}
