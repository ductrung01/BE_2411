package com.t3h.insuranceclaim.mapper;

import com.t3h.insuranceclaim.dto.ProductsDTO;
import com.t3h.insuranceclaim.entity.ProductsEntity;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ProductsMapper {

    ProductsDTO toDto(ProductsEntity productsEntity);

    List<ProductsDTO> toDtos(List<ProductsEntity> productsEntities);
}
