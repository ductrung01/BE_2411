package com.t3h.insuranceclaim.controller.resource;

import com.t3h.insuranceclaim.dto.UserDTO;
import com.t3h.insuranceclaim.dto.response.Response;
import com.t3h.insuranceclaim.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/resource/user/")
//@CrossOrigin("*")
public class UserResourceController {

    @Autowired
    private UserService userService;

    @GetMapping("profile")
    public ResponseEntity<Response<UserDTO>> profile() {
        Response<UserDTO> response = userService.getProfileUser();
        return ResponseEntity.ok(response);
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateUser(@RequestBody UserDTO user) {
        try {
            UserDTO userDTO = userService.updateProfileUser(user);
            return ResponseEntity.ok(userDTO);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
}
