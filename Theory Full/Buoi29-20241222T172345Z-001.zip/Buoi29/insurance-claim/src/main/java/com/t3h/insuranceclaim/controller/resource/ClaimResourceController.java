package com.t3h.insuranceclaim.controller.resource;

import com.t3h.insuranceclaim.dto.ClaimDTO;
import com.t3h.insuranceclaim.dto.UserDTO;
import com.t3h.insuranceclaim.dto.request.ClaimRequest;
import com.t3h.insuranceclaim.dto.response.ResponsePage;
import com.t3h.insuranceclaim.service.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/claims")
public class ClaimResourceController {

    @Autowired
    private ClaimService claimService;

    @GetMapping("/id")
    public ClaimDTO getById(@PathVariable Long id) {
        return claimService.getById(id);
    }


    @PostMapping
    public ResponseEntity<ResponsePage<List<ClaimDTO>>> getAll(@RequestBody(required = false) ClaimRequest claimRequest, Pageable pageable) {
        ResponsePage<List<ClaimDTO>> responsePage = claimService.getAllClaims(claimRequest,pageable);
        return ResponseEntity.ok(responsePage);
    }

    @PostMapping("/update")
    public ResponseEntity<?> updateUser(@RequestBody(required = false) UserDTO user) {
        try {
//            User updatedUser = userService.updateUser(id, user, image);
            return ResponseEntity.ok(null);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @PutMapping("/id")
    public ClaimDTO update(@PathVariable Long id, @RequestBody ClaimDTO claimDTO) {
        return claimService.update(id, claimDTO);
    }

    @DeleteMapping("/id")
    public void delete(@PathVariable Long id) {
        claimService.delete(id);
    }
}
