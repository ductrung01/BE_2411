package com.t3h.insuranceclaim.service;

import org.springframework.core.io.Resource;

public interface FileService {

    public Resource loadAvatarAsResource(String filename);
    
    Resource loadImageProduct(String fileName);
}
