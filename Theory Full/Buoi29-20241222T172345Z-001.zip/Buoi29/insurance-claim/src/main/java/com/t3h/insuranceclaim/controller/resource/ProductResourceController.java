package com.t3h.insuranceclaim.controller.resource;

import com.t3h.insuranceclaim.dto.ProductsDTO;
import com.t3h.insuranceclaim.dto.response.Response;
import com.t3h.insuranceclaim.service.ProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/resource/product")
public class ProductResourceController {

    @Autowired
    private ProductsService productsService;

    @GetMapping("/slide")
    public ResponseEntity<Response<List<ProductsDTO>>> productSlide() {
        return ResponseEntity.ok(productsService.getProductSlide());
    }
}
