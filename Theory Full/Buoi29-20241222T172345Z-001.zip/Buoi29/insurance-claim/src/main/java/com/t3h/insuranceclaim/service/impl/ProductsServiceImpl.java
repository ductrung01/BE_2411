package com.t3h.insuranceclaim.service.impl;

import com.t3h.insuranceclaim.dto.ProductsDTO;
import com.t3h.insuranceclaim.dto.UserDTO;
import com.t3h.insuranceclaim.dto.response.Response;
import com.t3h.insuranceclaim.entity.ProductsEntity;
import com.t3h.insuranceclaim.mapper.ProductsMapper;
import com.t3h.insuranceclaim.repository.ProductsRepository;
import com.t3h.insuranceclaim.service.ProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductsServiceImpl implements ProductsService {

    @Autowired
    private ProductsRepository productsRepository;
    @Autowired
    private ProductsMapper productsMapper;

    public Response<List<ProductsDTO>> getProductSlide(){
        List<ProductsEntity> productsEntities = productsRepository.findAll();
        List<ProductsDTO> productsDTOS = productsMapper.toDtos(productsEntities);
        Response<List<ProductsDTO>> response = new Response<>();
        response.setData(productsDTOS);
        response.setCode(HttpStatus.OK.value());
        response.setMessage("Success");
        return response;
    }
}
