package kiemtracuoimodul1;

import java.util.Scanner;

public class Main {
    private static HocSinh hocSinh;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập số lượng học sinh:");
        int n = sc.nextInt();
        sc.nextLine();
        HocSinh[] arrayHocSinh = new HocSinh[n];
        for (int i = 0; i < n; i++) {
            System.out.println("Nhập thông tin học sinh số " + (i + 1));
            arrayHocSinh[i] = nhapThongTin();
        }
        xuatThongTin(arrayHocSinh);
        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Hiển thị danh sách học sinh");
            System.out.println("2. Thêm học sinh mới");
            System.out.println("3. Hiển thị các học sinh có tuổi là 23 và quê ở Đà Nẵng");
            System.out.println("4. Tìm kiếm học sinh theo tên hoặc năm sinh");
            System.out.println("5. Xóa học sinh theo mã học sinh và tên học sinh");
            System.out.println("6. Chỉnh sửa thông tin học sinh theo mã học sinh");
            System.out.println("0. Thoát");
            System.out.print("Chọn chức năng: ");
            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    xuatThongTin(arrayHocSinh);
                    break;
                case 2:
                    System.out.println("Nhập số lượng học sinh cần thêm:");
                    int m = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    arrayHocSinh = themHocSinh(arrayHocSinh, m, sc);
                    break;
                case 3:
                    hienThiHocSinh23TuoiQueDaNang(arrayHocSinh);
                    break;
                case 4:
                    System.out.print("Nhập tên hoặc năm sinh để tìm kiếm: ");
                    String keyword = sc.nextLine();
                    timHocSinhTheoTenHoacNamSinh(arrayHocSinh, keyword);
                    break;
                case 5:
                    System.out.print("Nhập mã học sinh: ");
                    String maHocSinhXoa = sc.nextLine();
                    System.out.print("Nhập tên học sinh: ");
                    String tenHocSinhXoa = sc.nextLine();
                    arrayHocSinh = xoaHocSinh(arrayHocSinh, maHocSinhXoa, tenHocSinhXoa);
                    break;
                case 6:
                    System.out.print("Nhập mã học sinh cần chỉnh sửa: ");
                    String maHSSua = sc.nextLine();
                    suaThongTinHocSinh(arrayHocSinh, maHSSua, sc);
                    break;
                case 0:
                    System.out.println("Thoát chương trình.");
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ.");
                    break;
            }
        }
    }
    private static void xuatThongTin(HocSinh[] arrayHocSinh) {
        System.out.println("Thông Tin Danh Sách Học Sinh:");
        for (HocSinh hs : arrayHocSinh) {
            System.out.println(hs);
        }
    }
    private static HocSinh nhapThongTin() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập Mã Học Sinh:");
        String maHocSinh = sc.nextLine();
        System.out.println("Nhập Họ Tên:");
        String hoTen = sc.nextLine();
        System.out.println("Nhập Tuổi:");
        int tuoi = sc.nextInt();
        sc.nextLine(); // Consume newline
        System.out.println("Nhập Quê Quán:");
        String queQuan = sc.nextLine();
        System.out.println("Nhập Năm Sinh:");
        int namSinh = sc.nextInt();
        sc.nextLine();
        System.out.println("Nhập Số Điện Thoại:");
        long soDienThoai = sc.nextLong();
        sc.nextLine();
        System.out.println("Nhập Ngày Tháng Năm Sinh:");
        String ngayThangNamSinh = sc.nextLine();

        return new HocSinh(maHocSinh, hoTen, tuoi, queQuan, ngayThangNamSinh, soDienThoai, namSinh);
    }

    private static HocSinh[] themHocSinh(HocSinh[] arrayHocSinh, int number, Scanner sc) {
        HocSinh[] arrayHocSinhNew = new HocSinh[arrayHocSinh.length + number];
        for (int i = 0 ; i <arrayHocSinh.length;i++){
            arrayHocSinhNew[i]=arrayHocSinh[i];
        }
        for (int i = arrayHocSinh.length; i < arrayHocSinhNew.length; i++) {
            System.out.println("Nhập thông tin học sinh mới số " + (i + 1));
            arrayHocSinhNew[i] = nhapThongTin();
        }
        return arrayHocSinhNew;
    }
    private static void hienThiHocSinh23TuoiQueDaNang(HocSinh[] arrayHocSinh) {
        System.out.println("Danh sách học sinh có tuổi là 23 và quê ở Đà Nẵng:");
        for (HocSinh hs : arrayHocSinh) {
            if (hs.getTuoi() == 23 && hs.getQueQuan().equalsIgnoreCase("Đà Nẵng")) {
                System.out.println(hs);
            }
        }
    }
    private static void timHocSinhTheoTenHoacNamSinh(HocSinh[] arrayHocSinh, String keyword) {
        System.out.println("Kết quả tìm kiếm học sinh:");
        for (HocSinh hs : arrayHocSinh) {
            if (hs.getHoTen().toLowerCase().contains(keyword.toLowerCase()) ||
                    Integer.toString(hs.getNamSinh()).equals(keyword)) {
                System.out.println(hs);
            }
        }
    }
    private static HocSinh[] xoaHocSinh(HocSinh[] arrayHocSinh, String maHocSinh, String hoTen) {
        int index = -1;
        for (int i = 0; i < arrayHocSinh.length; i++) {
            if (arrayHocSinh[i].getMaHocSinh().equals(maHocSinh) && arrayHocSinh[i].getHoTen().equals(hoTen)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            System.out.println("Không tìm thấy học sinh với mã và tên đã nhập.");
            return arrayHocSinh;
        }

        HocSinh[] arrayHocSinhNew = new HocSinh[arrayHocSinh.length - 1];
        for (int i = 0, j = 0; i < arrayHocSinh.length; i++) {
            if (i != index) {
                arrayHocSinhNew[j++] = arrayHocSinh[i];
            }
        }
        System.out.println("Đã xóa học sinh với mã và tên đã nhập.");
        return arrayHocSinhNew;
    }
    private static void suaThongTinHocSinh(HocSinh[] arrayHocSinh, String maHocSinh, Scanner sc) {
        for (HocSinh hs : arrayHocSinh) {
            if (hs.getMaHocSinh().equals(maHocSinh)) {
                System.out.println("Nhập thông tin mới cho học sinh:");
                System.out.print("Nhập họ tên mới: ");
                hs.setHoTen(sc.nextLine());
                System.out.print("Nhập tuổi mới: ");
                hs.setTuoi(sc.nextInt());
                sc.nextLine();
                System.out.print("Nhập quê quán mới: ");
                hs.setQueQuan(sc.nextLine());
                System.out.print("Nhập năm sinh mới: ");
                hs.setNamSinh(sc.nextInt());
                sc.nextLine();
                System.out.print("Nhập số điện thoại mới: ");
                hs.setSoDienThoai(sc.nextLong());
                sc.nextLine();
                System.out.print("Nhập ngày tháng năm sinh mới: ");
                hs.setNgayThangNamSinh(sc.nextLine());
                break;
            }
        }
    }
}
