package kiemtracuoimodul1;

public class HocSinh {
      private String maHocSinh;
      private String hoTen;
      private int tuoi;
      private String queQuan;
      private String ngayThangNamSinh;
      private long soDienThoai;
      private int namSinh;

      public HocSinh(String maHocSinh, String hoTen, int tuoi, String queQuan, String ngayThangNamSinh, long soDienThoai, int namSinh) {
            this.maHocSinh = maHocSinh;
            this.hoTen = hoTen;
            this.tuoi = tuoi;
            this.queQuan = queQuan;
            this.ngayThangNamSinh = ngayThangNamSinh;
            this.soDienThoai = soDienThoai;
            this.namSinh = namSinh;
      }

      public String getMaHocSinh() {
            return maHocSinh;
      }

      public void setMaHocSinh(String maHocSinh) {
            this.maHocSinh = maHocSinh;
      }

      public String getHoTen() {
            return hoTen;
      }

      public void setHoTen(String hoTen) {
            this.hoTen = hoTen;
      }

      public int getTuoi() {
            return tuoi;
      }

      public void setTuoi(int tuoi) {
            this.tuoi = tuoi;
      }

      public String getQueQuan() {
            return queQuan;
      }

      public void setQueQuan(String queQuan) {
            this.queQuan = queQuan;
      }

      public String getNgayThangNamSinh() {
            return ngayThangNamSinh;
      }

      public void setNgayThangNamSinh(String ngayThangNamSinh) {
            this.ngayThangNamSinh = ngayThangNamSinh;
      }

      public long getSoDienThoai() {
            return soDienThoai;
      }

      public void setSoDienThoai(long soDienThoai) {
            this.soDienThoai = soDienThoai;
      }

      public int getNamSinh() {
            return namSinh;
      }

      public void setNamSinh(int namSinh) {
            this.namSinh = namSinh;
      }

      @Override
      public String toString() {
            return "HocSinh{" +
                    "maHocSinh='" + maHocSinh + '\'' +
                    ", hoTen='" + hoTen + '\'' +
                    ", tuoi=" + tuoi +
                    ", queQuan='" + queQuan + '\'' +
                    ", ngayThangNamSinh='" + ngayThangNamSinh + '\'' +
                    ", soDienThoai=" + soDienThoai +
                    ", namSinh=" + namSinh +
                    '}';
      }
}
