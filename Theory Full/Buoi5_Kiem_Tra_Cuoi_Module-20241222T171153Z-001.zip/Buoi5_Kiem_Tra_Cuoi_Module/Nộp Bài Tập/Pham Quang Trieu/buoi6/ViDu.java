package com.t3h.src.buoi6;

import java.util.Scanner;

public class ViDu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //nhap so luong phan tu cua mang
        System.out.println("Nhap so luong phan tu cua mang  : ");
        int n = sc.nextInt();
        // khoi tao mang
        int [] mang = new int[n];
       // nhap cac phan tu  cua mang va cho phep nhap so lon hon 0
        for (int i = 0; i < n; i++) {
            while(true) {
                    System.out.println("nhap phan tu thu "+(i+1)+";");
                    int phanTu = sc.nextInt();
                    if(phanTu > 0){
                        mang[i] = phanTu;
                        break;
                    }else{
                        System.out.println("vui long nhap so lon hon 0 : ");
                    }
                    }
        }
        // hien thi danh sach da nhap
            System.out.println("danh sach da nhap la ");
            hienThiMang(mang);
        //tinh tong phan tu la
        int tongLe=tinhTongLe(mang);
        System.out.println(" \n tong cac phan tu le la "+tongLe);
        //so lan xuat hien
        System.out.println("nhap so bat ki ");
        int soNhap=sc.nextInt();
        int soLanXuatHien=demSoLanXuatHien(mang,soNhap);
        System.out.println("so lan xuat hien cuar so "+soNhap+" trong danh sach "+soLanXuatHien);
    }
    public static void hienThiMang(int[] mang){
        for (int i = 0; i< mang.length; i++) {
            System.out.print(mang[i]+" ");
        }
    }
    public static  int tinhTongLe(int[] mang){
        int tongLe=0;
        for (int i = 0; i < mang.length; i++) {
            if(mang[i]%2!=0){
                tongLe+=mang[i];
            }
        }
        return  tongLe;
    }
    public static int demSoLanXuatHien(int[] mang,int soNhap){
        int soLanXuatHien=0;
        for (int i=0;i< mang.length;i++)
            if(mang[i]==soNhap){
                soLanXuatHien++;
            }
        return soLanXuatHien;
    }

}
